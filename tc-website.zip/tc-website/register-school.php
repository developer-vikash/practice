<?php 
	session_start();
 ?>
 <?php

/*$url = 'http://52.90.39.26/talking_classes/schooladmin/schools/manage?flag=get_all_schools';
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$data = curl_exec($ch);
curl_close($ch);
//echo $data;
$data1 = json_decode($data);


$resp = $data1->response;
$response_data = $resp->response_data;

//Class data End
$school = "[";
for ($i = 0; $i < sizeof($response_data); $i++) {
    $commas = "";
    if ($i < sizeof($response_data) - 1) {
        $commas = ",";

    }
    $school .= '"' . $response_data[$i]->name . '"' . $commas;
}
$school .= "]";
*/
//Class data End

?>
<!DOCTYPE html>
<html lang="en">
    <!--
    Bent - Bootstrap Landing Page Template by Dcrazed
    Site: https://dcrazed.com/bent-app-landing-page-template/
    Free for personal and commercial use under GNU GPL 3.0 license.
    -->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Talking Classes | School Registration.</title>
        <!-- Google Font -->
        <link href='https://fonts.googleapis.com/css?family=Raleway:500,600,700,800,900,400,300' rel='stylesheet'
            type='text/css'>
            <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,900,300italic,400italic'
                rel='stylesheet' type='text/css'>
                <!-- Bootstrap -->
                <link href="css/bootstrap.min.css" rel="stylesheet">
                <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
                <!-- Owl Carousel Assets -->
                <link href="css/owl.carousel.css" rel="stylesheet">
                <link href="css/owl.theme.css" rel="stylesheet">
                <!-- Pixeden Icon Font -->
                <link rel="stylesheet" href="css/Pe-icon-7-stroke.css">
                <!-- Font Awesome -->
                <link href="css/font-awesome.min.css" rel="stylesheet">
                <!-- PrettyPhoto -->
                <link href="css/prettyPhoto.css" rel="stylesheet">
                <!-- Favicon -->
                <link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
                <!-- Style -->
                <link href="css/style.css" rel="stylesheet">
                <link href="css/animate.css" rel="stylesheet">
                <!-- Responsive CSS -->
                <link href="css/responsive.css" rel="stylesheet">
				<link href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.css' rel='stylesheet'
          type='text/css'>
                <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
                <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
                <!--[if lt IE 9]>
                <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
                <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
                <![endif]-->

                <style>
        .ui-autocomplete {
            max-height: 100px;
            overflow-y: auto;
            /* prevent horizontal scrollbar */
            overflow-x: hidden;
        }

        /* IE 6 doesn't support max-height
         * we use height instead, but this forces the menu to always be this tall
         */
        * html .ui-autocomplete {
            height: 100px;
        }

        ul.ui-autocomplete {
            z-index: 1100;
        }
    </style>

                <style type="text/css">
                .full-width {
                width: 100%;
                }
                .custom-button {
                background-color: #f39c12;
                }
                .custom-button:hover {
                background-color: #db8c0e;
                }
                .custom-button1 {
                background-color: #3b4e5f !important;
                border-color: #3b4e5f !important;
                }
                .custom-button1:hover {
					background-color: #2b4e2f;
					border-color: #2b4e2f;
                }
				.custom-button2 {
                background-color: #4C99CC;
                border-color: #4C99CC;
                }
                .custom-button2:hover {
                background-color: #3C89BC;
                }
                </style>
				
				<style>
				.demo{ background: #f2f2f2;padding:30px; }
				.pricingTableFreeSubcrib{
    margin: 0 15px;
    text-align: center;
    border-radius: 15px;
    overflow: hidden;
}
.pricingTable{
    padding-bottom: 30px;
    margin: 0 15px;
    background: #fff;
    text-align: center;
    border-radius: 15px;
    overflow: hidden;
}
.pricingTable:hover{ box-shadow: 0 0 10px rgba(195, 67, 67, 0.3) inset,0 0 20px -5px rgba(0,0,0,0.8); }
.pricingTable .pricingTable-header{
    padding: 5px 15px 30px;
    background: #66ce04;
    -webkit-clip-path: polygon(50% 100%, 100% 60%, 100% 0, 0 0, 0 60%);
    clip-path: polygon(50% 100%, 100% 60%, 100% 0, 0 0, 0 60%);
    position: relative;
}
.pricingTable .pricingTable-header:before{
    content: "";
    width: 400px;
    height: 400px;
    border-radius: 50%;
    position: absolute;
    right: -50%;
    top: -130%;
    background: repeating-radial-gradient(rgba(255,255,255,0.05), rgba(255,255,255,0.2) 20%);
    transition: all 0.5s ease 0s;
}
.pricingTable:hover .pricingTable-header:before{ right: 50%; }
.pricingTable .title{
    font-size: 37px;
    color: #fff;
    margin: 0;
}
.pricingTable .price-value{
    display: block;
    font-size: 23px;
    color: #000;
   /* margin: 0 0 20px 0; */
    transition: all 0.3s ease 0s;
}
.pricingTable .pricing-content{
    padding: 13px 25px 0;
    margin: 0;
    list-style: none;
}
.pricingTable .pricing-content li{
    font-size: 18px;
    color: #909090;
    line-height: 40px;
    letter-spacing: 1px;
    text-transform: capitalize;
    border-bottom: 2px solid rgba(0,0,0,0.15);
    margin-bottom: 10px;
    position: relative;
}
.pricingTable .pricing-content li:last-child{ border-bottom: none; }
.pricingTable .pricing-content li i{ color: #66ce04; }
.pricingTable .pricingTable-signup{
    display: block;
    padding: 10px 0;
    margin: 0 25px;
    border-radius: 10px;
    background: #66ce04;
    font-size: 20px;
    color: #fff;
    letter-spacing: 1px;
    text-transform: uppercase;
    overflow: hidden;
    position: relative;
    transition: all 0.3s ease 0s;
}
.pricingTable .pricingTable-signup:hover{
    letter-spacing: 2px;
    box-shadow: 0 0 10px rgba(0,0,0,0.7) , 0 0 0 7px rgba(255,255,255,0.5) inset;
}
.pricingTable .pricingTable-signup:before{
    content: "";
    width: 230px;
    height: 230px;
    border-radius: 50%;
    background: repeating-radial-gradient(rgba(255,255,255,0.05), rgba(255,255,255,0.2) 20%);
    position: absolute;
    top: -180%;
    right: -40%;
    transition: all 0.8s ease 0s;
}
.pricingTable .pricingTable-signup:hover:before{ right: 40%; }
.pricingTable.blue .pricingTable-header,
.pricingTable.blue .pricingTable-signup{ background: #15b8f3; }
.pricingTable.blue .pricing-content li i{ color: #15b8f3; }
.pricingTable.pink .pricingTable-header,
.pricingTable.pink .pricingTable-signup{ background: #f03c79; }
.pricingTable.pink .pricing-content li i{ color: #f03c79; }
@media only screen and (max-width: 990px){
    .pricingTable{ margin-bottom: 30px; }
}
@media only screen and (max-width: 479px){
    .pricingTable{ margin: 0; }
    .pricingTable .pricing-content li{ font-size: 15px; }
}

.pricingTableFreeSubcrib .pricingTable-signup{
    display: block;
    padding: 10px 0;
    margin: 0 25px;
    border-radius: 10px;
    background: #DE8E0E;
    font-size: 20px;
    color: #fff;
    letter-spacing: 1px;
    text-transform: uppercase;
    overflow: hidden;
    position: relative;
    transition: all 0.3s ease 0s;
}
.pricingTableFreeSubcrib .pricingTable-signup:hover{
    letter-spacing: 2px;
    box-shadow: 0 0 10px rgba(0,0,0,0.7) , 0 0 0 7px rgba(255,255,255,0.5) inset;
}
.pricingTableFreeSubcrib .pricingTable-signup:before{
    content: "";
    width: 230px;
    height: 230px;
    border-radius: 50%;
    background: repeating-radial-gradient(rgba(255,255,255,0.05), rgba(255,255,255,0.2) 20%);
    position: absolute;
    top: -180%;
    right: -3%;
    transition: all 0.8s ease 0s;
}
.pricingTableFreeSubcrib .pricingTable-signup:hover:before{ right: 60%; }
.pricingTableFreeSubcrib.pink .pricingTable-signup{ background: #DE8E0E; }

.pricingTableFreeSubcrib.blue .pricingTable-signup{ background: #DE8E0E; }
				</style>
				
				<style>
				.custom-input-box{
					background-color:#e5e8e8;
					border:1px solid #ccd1d1;
					border-radius:3px;
					padding:5px 15px 5px 25px;
				}
				</style>
				<style>
					
.avatar-upload {
  position: relative;
  max-width: 205px;
  margin: 0px auto;
}
.avatar-upload .avatar-edit {
  position: absolute;
  right: 12px;
  z-index: 1;
  top: 10px;
}
.avatar-upload .avatar-edit input {
  display: none;
}
.avatar-upload .avatar-edit input + label {
  display: inline-block;
  width: 34px;
  height: 34px;
  margin-bottom: 0;
  border-radius: 100%;
  background: #ffffff;
  border: 1px solid transparent;
  box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.12);
  cursor: pointer;
  font-weight: normal;
  transition: all 0.2s ease-in-out;
}
.avatar-upload .avatar-edit input + label:hover {
  background: #f1f1f1;
  border-color: #d6d6d6;
}
.avatar-upload .avatar-edit input + label:after {
  content: "\f040";
  font-family: "FontAwesome";
  color: #757575;
  position: absolute;
  top: 10px;
  left: 0;
  right: 0;
  text-align: center;
  margin: auto;
}
.avatar-upload .avatar-preview {
  width: 192px;
  height: 192px;
  position: relative;
  border-radius: 100%;
  border: 6px solid #f8f8f8;
  box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.1);
}
.avatar-upload .avatar-preview > div {
  width: 100%;
  height: 100%;
  border-radius: 100%;
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
}

				</style>
            </head>
            <body>
                <!-- PRELOADER -->
                <div class="spn_hol">
                    <div class="spinner">
                        <div class="bounce1"></div>
                        <div class="bounce2"></div>
                        <div class="bounce3"></div>
                    </div>
                </div>
                <!-- END PRELOADER -->
                <!-- =========================
                START ABOUT US SECTION
                ============================== -->
                <section class="header parallax home-parallax page" id="HOME" style="background:none;">
                    <h2></h2>
                    <div class="section_overlay">
                        <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
                            <div class="container">
                                <!-- Brand and toggle get grouped for better mobile display -->
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                    data-target="#bs-example-navbar-collapse-1">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    </button>
                                    <a class="navbar-brand" href="#">
                                        <img src="images/logo-transparent.png" alt="Logo">
                                    </a>
                                </div>
                                <!-- Collect the nav links, forms, and other content for toggling -->
                                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                    <ul class="nav navbar-nav navbar-right">
                                        <!-- NAV -->
                                        <!--<li><a href="#HOME">..............</a></li>
                                        <li><a href="#SCHOOL_ZONE">.............. </a></li>
                                        <li><a href="#ABOUT">..............</a></li>
                                        <li><a href="#FEATURES">..............</a></li>
                                        <li><a href="#SCREENS">..............</a></li>
                                        <li><a href="#DOWNLOAD">.............. </a></li>
                                        <li><a href="#CONTACT">.............. </a></li>-->
                                    </ul>
                                </div>
                                <!-- /.navbar-collapse -->
                            </div>
                            <!-- /.container- -->
                        </nav>
                        <div class="container home-container" style="margin-top:50px;">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="logo text-center" style="padding-top: 10px;padding-bottom: 10px;margin-bottom:10px;text-transform:uppercase;">
                                        <!-- LOGO -->
                                        <h2> Register Your School </h2>
                                        
                                    </div>
                                </div>
                            </div>
							<center><hr width="100%" style="border:1px solid  #4C99CC ;" /></center>
							<div style="padding:10px;">
							<form id="registrationForm" name="registrationForm" action="#">
								<div class="row">
									<div class="col-md-4 col-sm-6">
										<div class="form-group">
											<label for="exampleFormControlInput1">School Name</label>
											<input type="text" class="form-control custom-input-box schoolInput" id="schoolName" name="schoolName" placeholder="School Name" required>
										  </div>
									</div>
									<div class="col-md-4 col-sm-6">
										<div class="form-group">
											<label for="exampleFormControlInput1">School Type</label>
											<select class="form-control custom-input-box" id="schoolType" name="schoolType" disabled>
												<option value="1" selected >School</option>
											</select>
										  </div>
									</div>
									<div class="col-md-4 col-sm-6">
										<div class="form-group">
											<label for="exampleFormControlInput1">School URL</label>
											<input type="text" class="form-control  custom-input-box" id="schoolURL" name="schoolURL" placeholder="School URL">
										  </div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-md-4 col-sm-6">
										<div class="form-group">
											<label for="exampleFormControlInput1">Branch Name</label>
											<input type="text" class="form-control  custom-input-box branchInput" id="branchName" name="branchName" placeholder="Branch Name">
										  </div>
									</div>
									<div class="col-md-4 col-sm-6">
										<div class="form-group">
											<label for="exampleFormControlInput1">Country </label>
											<select class="form-control custom-input-box" id="country" name="country" disabled>
											
											</select>
										  </div>
									</div>
									<div class="col-md-4 col-sm-6">
										<div class="form-group">
											<label for="exampleFormControlInput1">State </label>
											<select class="form-control custom-input-box" id="state" name="state">
                                                <option value="" selected>Please select State</option>
												
											</select>
										  </div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-md-4 col-sm-6">
										<div class="form-group">
											<label for="exampleFormControlInput1">City </label>
											
                                            <select class="form-control custom-input-box" id="city" name="city">
                                                <option value="" selected>Please Select City</option>
                                                
                                            </select>
										  </div>
									</div>
									<div class="col-md-8 col-sm-6">
										<div class="form-group">
											<label for="exampleFormControlInput1">School Address</label>
											<input type="text" class="form-control custom-input-box" id="schoolAddress" name="schoolAddress" placeholder="School Address">
										  </div>
									</div>
									
								</div>
								
								<div class="panel panel-default">

									<div class="panel-heading">Principal</div>
									<div class="panel-body">

										<div class="row">
											<div class="col-md-4 col-sm-6">
												<div class="form-group">
													<label for="exampleFormControlInput1">Name</label>
													<input type="text" class="form-control custom-input-box" id="principleName" name="principleName" placeholder="Name">
												  </div>
											</div>
											<div class="col-md-4 col-sm-6">
												<div class="form-group">
													<label for="exampleFormControlInput1"> Email</label>
													<input type="text" class="form-control  custom-input-box" id="principleEmail" name="principleEmail" placeholder="Email">
												  </div>
											</div>
											
											<div class="col-md-4 col-sm-6">
												<div class="form-group">
													<label for="exampleFormControlInput1">Password</label>
													<input type="password" class="form-control  custom-input-box" id="principlePassword" name="principlePassword" placeholder="Password">
												  </div>
											</div>
										</div>
												

										<div class="clearfix"></div>
									</div>

								</div>
								
								<div class="panel panel-default">

									<div class="panel-heading">Admin</div>
									<div class="panel-body">

										<div class="row">
											<div class="col-md-4 col-sm-6">
												<div class="form-group">
													<label for="exampleFormControlInput1">Name</label>
													<input type="text" class="form-control  custom-input-box" id="adminName" name="adminName" placeholder="Name">
												  </div>
											</div>
											<div class="col-md-4 col-sm-6">
												<div class="form-group">
													<label for="exampleFormControlInput1"> Email</label>
													<input type="text" class="form-control  custom-input-box" id="adminEmail" name="adminEmail" placeholder="Email">
												  </div>
											</div>
											<div class="col-md-4 col-sm-6">
												<div class="form-group">
													<label for="exampleFormControlInput1">Password</label>
													<input type="password" class="form-control  custom-input-box" id="adminPassword" name="adminPassword" placeholder="Password">
												  </div>
											</div>
										</div>
												

										<div class="clearfix"></div>
									</div>

								</div>
	
								<div class="panel panel-default">

									<div class="panel-heading">Another Authorized Users</div>
									<div class="panel-body">

										<div class="row">
											<div class="col-md-4 col-sm-6">
												<div>
													<input type="text" name="otherAdminEmail[]"  class="form-control custom-input-box" placeholder="Email Id" />
												</div>
												<div style="margin-top:10px;">
													<input type="password" name="otherAdminPassword[]" class="form-control custom-input-box" placeholder="Password" />
												</div>
											</div>
											<div class="col-md-4 col-sm-6">
												<div>
													<input type="text" name="otherAdminEmail[]" class="form-control custom-input-box" placeholder="Email Id" />
												</div>
												<div style="margin-top:10px;">
													<input type="password" name="otherAdminPassword[]" class="form-control custom-input-box" placeholder="Password" />
												</div>
											</div>
											<div class="col-md-4 col-sm-6">
												<div>
													<input type="text" name="otherAdminEmail[]" class="form-control custom-input-box" placeholder="Email Id" />
												</div>
												<div style="margin-top:10px;">
													<input type="password" name="otherAdminPassword[]" class="form-control custom-input-box" placeholder="Password" />
												</div>
											</div>
										</div>
												

										<div class="clearfix"></div>
									</div>

								</div>
								
								<div class="row">
									<div class="col-md-4 col-sm-12">
										
												<label>School Logo</label>
											
											<div class="avatar-upload">
												<div class="avatar-edit">
													<input type='file' id="imageUpload" name="schoolLogo" accept=".png, .jpg, .jpeg" />
													<label for="imageUpload"></label>
												</div>
												<div class="avatar-preview">
													<div id="imagePreview" style="background-image: url(images/logo-transparent.png);">
													</div>
												</div>
											</div>
									</div>
									<div class="col-md-8 col-sm-12">
										<div style="margin-top:20px;">
										  <div class="row">
											<div class="col-md-3 col-sm-6" style="padding:30px;">
												<label for="exampleFormControlInput1">School Phone</label>
											</div>
											<div class="col-md-9 col-sm-6">
												<div class="form-group">
													<span style="color:#DB8C0E">e.g.: +91-11-XXXXXXX </span>
													<input type="text" class="form-control custom-input-box" id="schoolPhone" name="schoolPhone" placeholder="School Phone">
												</div>
											</div>
										  </div>

										  <div class="row">
											<div class="col-md-3 col-sm-6" style="padding:30px;">
												<label for="exampleFormControlInput1">Mobile Phone</label>
											</div>
											<div class="col-md-9 col-sm-6">
												<div class="form-group">
													<span style="color:#DB8C0E">e.g.: +91-XXXXXXXXXX </span>
													<input type="text" class="form-control custom-input-box" id="schoolMobile" name="schoolMobile" placeholder="Mobile Phone">
												</div>
											</div>
										  </div>
										 </div>
									</div>
									
								</div>
								
								
								<!--<div class="panel panel-default">

									<div class="panel-heading">Select Plans</div>
									<div class="panel-body">

										<div class="row">
											<div class="col-md-12 col-sm-6">
												<label class="radio-inline">
												  <input type="radio" name="optradio" checked>For 1 year Rs. 18000 /- 
												</label>
												<label class="radio-inline">
												  <input type="radio" name="optradio">For 2 years Rs. 34000 /- 
												</label>
												<label class="radio-inline">
												  <input type="radio" name="optradio">	For 3 years Rs. 48600 /- 
												</label>
												<label class="radio-inline">
												  <input type="radio" name="optradio">	For 5 years Rs. 80000 /-  
												</label>
											</div>
										</div>
												

										<div class="clearfix"></div>
									</div>

								</div>-->
	
								<div class="row">
									<div class="col-md-12 col-sm-6">
										<div class="checkbox">
											<label>
												<input type="checkbox" name="userTermsAgreement" id="userTermsAgreement" value="agree" />I Have read and understood the  <a href="#" style="color:#427DBD;">terms and condition, </a> Agreed to it.
											</label>
										</div>
											<!-- TITLE AND DESC -->
																			
											<div style="padding-top: 10px;">
												<div style="display: inline-block;vertical-align: middle;width: 100%;" >
													<button type="submit" class="btn home-btn custom-button full-width" id="nextBtn" > Next</button>
												</div>
											</div>
										
									</div>
								</div>
								</form>
                            </div>
                            
                           
                        </div>
                    </div>
                </section>
                <!-- END HEADER SECTION -->
            </div>
        </div>
    </div>
</div>
</section>

<!-- =========================
     START CONTCT FORM AREA
============================== -->

<section class="subscribe parallax subscribe-parallax" data-stellar-background-ratio="0.6"
         data-stellar-vertical-offset="20" id="SCHOOL_ZONE">
    <div class="section_overlay wow lightSpeedIn">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">

                    <!-- Start Subscribe Section Title -->
                    <div class="section_title">
                        <h2>Contact Form For Schools</h2>
                    </div>
                    <!-- End Subscribe Section Title -->
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row  wow lightSpeedIn">
                <div class="col-md-6 col-md-offset-3">
                    <!-- SUBSCRIPTION SUCCESSFUL OR ERROR MESSAGES -->
                    <div class="subscription-success"></div>
                    <div class="subscription-error"></div>
                    <!-- Check this topic on how to add email subscription list, http://kb.mailchimp.com/lists/signup-forms/host-your-own-signup-forms -->
                    <form id="mc-form" action="#" method="POST" class="subscribe_form">
                        <input type="hidden" name="u" value="6908378c60c82103f3d7e8f1c">
                        <input type="hidden" name="id" value="8c5074025d">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="text" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="Your Name"
                                           value="" required>
                                </div>
                                <div class="col-md-6">
                                    <input type="text" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="Designation"
                                           value="" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="text" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="School Name"
                                           value="" required>
                                </div>
                                <div class="col-md-6">
                                    <select autocapitalize="off" autocorrect="off" name="MERGE0"
                                            class="required form-control" id="mce-EMAIL">
                                        <option value="0">Select Country</option>
                                        <option value="India">India</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="text" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="City Name"
                                           value="" required>
                                </div>
                                <div class="col-md-6">
                                    <input type="text" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="Branch Name"
                                           value="" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="email" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="School Email"
                                           value="" required>
                                </div>
                                <div class="col-md-6">
                                    <input type="text" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="School Contact No."
                                           value="" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <input type="text" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL"
                                           placeholder="School Website" value="" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <input type="text" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="Your Message"
                                           value="" required>
                                </div>
                            </div>
                        </div>
                        <!-- SUBSCRIBE BUTTON -->
                        <button type="submit" class="btn btn-default subs-btn">Submit</button>
                    </form>


                </div>
            </div>
        </div>
    </div>
</section>
<!-- END CONTACT -->



<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Membership Plans</h4>
        </div>
        <div class="modal-body">
          <p></p>
		  
		  <div class="demo">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6">
                <div class="pricingTable">
                    <div class="pricingTable-header">
                        <h3 class="title">30 Days Trial</h3>
                        <div class="price-value">Rs. Free </div>
                    </div>
                    <ul class="pricing-content">
                        <li><i class="fa fa-check"></i> 50 Users</li>
                        <!--<li><i class="fa fa-times"></i> 50 Email Accounts</li>-->
                    </ul>
                    <a href="#" id="1" class="pricingTable-signup submitregistration">Subscribe Now</a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="pricingTable blue">
                    <div class="pricingTable-header">
                        <h3 class="title"> For 3 Months </h3>
                        <div class="price-value">Rs. 15000 /-</div>
                    </div>
                    <ul class="pricing-content">
                        <li><i class="fa fa-check"></i> 500 Users</li>
                        <!--<li><i class="fa fa-check"></i> 60 Email Accounts</li>-->
                    </ul>
                    <a href="#" id="2" class="pricingTable-signup submitregistration">Subscribe Now</a>
                </div>
            </div>
        </div>
		<br/>
		<div class="row">
            
            <div class="col-md-4 col-sm-6">
                <div class="pricingTable blue">
                    <div class="pricingTable-header">
						<h3 class="title">For 6 Months</h3>
                        <div class="price-value">Rs. 30000 /-</div>
                    </div>
                    <ul class="pricing-content">
                        <li><i class="fa fa-check"></i> 500 Users </li>
                        <!--<li><i class="fa fa-check"></i> 60 Email Accounts</li>-->
                    </ul>
                    <a href="#" id="3" class="pricingTable-signup submitregistration">Subscribe Now</a>
                </div>
            </div>
			<div class="col-md-4 col-sm-6">
                <div class="pricingTable">
                    <div class="pricingTable-header">
                        <h3 class="title">For 12 Months</h3>
                        <div class="price-value">Rs. 60000 /- </div>
                    </div>
                    <ul class="pricing-content">
                        <li><i class="fa fa-check"></i> 500 Users</li>
                        <!--<li><i class="fa fa-times"></i> 50 Email Accounts</li>-->
                    </ul>
                    <a href="#" id="4" class="pricingTable-signup submitregistration">Subscribe Now</a>
                </div>
            </div>
        </div>
		<br/>
		<!--<div class="row">
            <div class="col-md-8 col-sm-8">
                <div class="pricingTableFreeSubcrib">
                    <a href="#" id="30 days trial" class="pricingTable-signup submitregistration">Subscribe For 30 Days Trial</a>
                </div>
            </div>
        </div>-->
		
    </div>
	
	<!--<div class="container">
        <div class="row">
		<div class="col-md-2 col-sm-6">
		</div>
            <div class="col-md-4 col-sm-6">
                <div class="pricingTable">
                    <div class="pricingTable-header">
                        <h3 class="title">30 Days Trial</h3>
                        <div class="price-value">50 Users </div>
                    </div>
                    <ul class="pricing-content">
                        <li><i class="fa fa-check"></i> Limited Access*</li>
                    </ul>
                    <a href="#" id="for 1 year" class="pricingTable-signup submitregistration">Subscribe Now</a>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
			</div>
        </div>
		
    </div>-->
	
</div>
		  
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        </div>
      </div>
      
    </div>
  </div>
  


<!-- =========================
FOOTER
============================== -->
<section class="copyright">
<h2></h2>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="copy_right_text">
                <!-- COPYRIGHT TEXT -->
                <p>Copyright &copy; 2018. All Rights Reserved.</p>
                <p><a href="#">Talking Classes</a></p>
            </div>
        </div>
        <div class="col-md-6">
            <div class="scroll_top">
                <a href="#HOME"><i class="fa fa-angle-up"></i></a>
            </div>
        </div>
    </div>
</div>
</section>
<!-- END FOOTER -->
<!-- =========================
SCRIPTS
============================== -->
<script src="js/jquery.min.js"></script>
<script src="js/jquery.validate.js"></script>
<script src="js/jquery.session.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script>
var schoolBaseImage="";
$(document).ready(function(){
    
	function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            $('#imagePreview').css('background-image', 'url('+e.target.result +')');
            $('#imagePreview').hide();
            $('#imagePreview').fadeIn(650);
            //alert(e.target.result);
            schoolBaseImage = e.target.result;
        }
        reader.readAsDataURL(input.files[0]);
    }
}
$("#imageUpload").change(function() {
	
    readURL(this);
});
});
</script>
<script>
    var schoolList =[];
    var schoolJsonData = "";
    var responseMessage = "";
    var data = "";
    //alert(schoolList);
    //console.log(schoolJsonData);


$(document).ready(function(){

    $.ajax({
        url: "http://52.90.39.26/talking_classes/schooladmin/schools/manage",
        type: "GET",
        async: false,
        data: {"flag": "get_all_schools"},
        datatype: 'htlm',
        success: function (result) {
            //data = result
         // console.log(result);
            var decodedJson = jQuery.parseJSON(result);
             responseMessage = decodedJson.response.response_message;
            var responseStatus = decodedJson.response.response_status;
                schoolJsonData = decodedJson.response.response_data;
                data = decodedJson.response.response_data;
            
            $.each(schoolJsonData, function (i, currProgram) { 
                //console.log(currProgram.item_name);
                schoolList.push(currProgram.name);
            });
        }
    });

    //alert(data);

    $(".schoolInput").autocomplete({
        source: schoolList
    });
console.log(schoolList);

    $(".schoolInput").change(function(){
        var branchSchoolId = "";
       
        var schoolName = $('.schoolInput').val();
        //alert(schoolName);
        
       $.each(data, function (i, currProgram) { 
            
            if(currProgram.name===schoolName){
               // alert(currProgram.id);
                branchSchoolId = currProgram.id;

            }

        });

               // alert(branchSchoolId);
        var branchList = [];
        $.ajax({
            url: "http://52.90.39.26/talking_classes/schooladmin/schools/manage",
            type: "GET",
            async: false,
            data: {"flag": "get_school_branches", "school_id": branchSchoolId},
            datatype: 'html',
            success: function (result) {
                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var branchData = decodedJson.response.response_data;
    
                var len = branchData.length;
                $.each(branchData, function (i, currProgram) { 
                    var commas="";
                    if(i<(len-1)){
                        commas = ",";
                    }
        
                   var bName =  currProgram.name;

                    branchList.push(bName);
                }); 
            }
        });
    
        console.log(branchList);
        $(".branchInput").autocomplete({
            source: branchList
        });
    }); 

    $.ajax({
        url: "http://52.90.39.26/talking_classes/schooladmin/schools/manage",
        type: "GET",
        async: false,
        data: {"flag": "get_country"},
        datatype: 'html',
        success: function (result) {
            //console.log(result);
            var decodedJson = jQuery.parseJSON(result);
            var responseMessage = decodedJson.response.response_message;
            var branchData = decodedJson.response.response_data;

            $.each(branchData, function (i, currProgram) { 
                //alert(currProgram.country_name);
                $('#country').append('<option value="'+currProgram.id+'">'+currProgram.country_name+'</option>');
                
            }); 
        }
    });

 $.ajax({
        url: "http://52.90.39.26/talking_classes/schooladmin/schools/manage",
        type: "GET",
        async: false,
        data: {"flag": "get_state","country_id":"6"},
        datatype: 'html',
        success: function (result) {
            
            var decodedJson = jQuery.parseJSON(result);
            var responseMessage = decodedJson.response.response_message;
            var branchData = decodedJson.response.response_data;
            $('#state').html('');
            $('#state').append('<option value="">Please select state</option>');
            $.each(branchData, function (i, currProgram) { 
                
                $('#state').append('<option value="'+currProgram.id+'">'+currProgram.state_name+'</option>');
                
            }); 
        }
    });

  $('#country').change(function(){
    var countryId =  $(this).val();
    $.ajax({
        url: "http://52.90.39.26/talking_classes/schooladmin/schools/manage",
        type: "GET",
        async: false,
        data: {"flag": "get_state","country_id":countryId},
        datatype: 'html',
        success: function (result) {
            
            var decodedJson = jQuery.parseJSON(result);
            var responseMessage = decodedJson.response.response_message;
            var branchData = decodedJson.response.response_data;
            $('#state').html('');
            $('#state').append('<option value="">Please select state</option>');
            $.each(branchData, function (i, currProgram) { 
                
                $('#state').append('<option value="'+currProgram.id+'">'+currProgram.state_name+'</option>');
                
            }); 
        }
    });

  });

  $('#state').change(function(){
    var stateId =  $(this).val();
    $.ajax({
        url: "http://52.90.39.26/talking_classes/schooladmin/schools/manage",
        type: "GET",
        async: false,
        data: {"flag": "get_cities","state_id":stateId},
        datatype: 'html',
        success: function (result) {
            console.log(result);
            var decodedJson = jQuery.parseJSON(result);
            var responseMessage = decodedJson.response.response_message;
            var branchData = decodedJson.response.response_data;
            $('#city').html('');
            $('#city').append('<option value="">PLEASE SELECT CITY</option>');
            $.each(branchData, function (i, currProgram) { 
                
                $('#city').append('<option value="'+currProgram.id+'">'+currProgram.city_name+'</option>');
                
            }); 
        }
    });

  });
  
  
  $('#nextBtn').click(function(){
	//alert('vikash');
	
	$("#registrationForm").validate({
		rules: {
         "schoolName":{
            "required": true
         },
		 "schoolType":{
            "required": true
         },
         "branchName": {
           // "email": true,
		   "required": true
         },
		 "schoolURL": {
		   "required": true,
            "url": true
         },
		 "country": {
		   "required": true
         },
		 "state": {
		   "required": true
         },
		 "city": {
		   "required": true
         },
		 "schoolAddress": {
		   "required": true
         },
		 "principleName": {
		   "required": true
         },
		 "principleEmail": {
		   "required": {
				"depends":function(){
					$(this).val($.trim($(this).val()));
					return true;
				}
			},
			"email": true,
            "remote": {
                    url: "http://52.90.39.26/talking_classes/schooladmin/schools/manage?flag=check_email_exist_for_principal",
                    type: "GET"
                 }
         },
		 "principlePassword": {
		  "required": {
				"depends":function(){
					$(this).val($.trim($(this).val()));
					return true;
				}
			}
         },
		 "adminName": {
		   "required": true
         },
		 "adminEmail": {
		   "required": {
				"depends":function(){
					$(this).val($.trim($(this).val()));
					return true;
				}
			},
			"email": true,
            "remote": {
                    url: "http://52.90.39.26/talking_classes/schooladmin/schools/manage?flag=check_email_exist_for_admin",
                    type: "GET"
                 }
         },
		 "adminPassword": {
		   "required": {
				"depends":function(){
					$(this).val($.trim($(this).val()));
					return true;
				}
			}
         },
         "schoolPhone": {
            "required": true,
			"number": true,
			"minlength": 10,
            "maxlength": 12
         },
         "schoolMobile": {
            "required": true,
			"number": true,
			"minlength": 10,
            "maxlength": 12
         },
		 "userTermsAgreement": {
            "required": true,
         }
	}, //             	  
			messages: {
				schoolName: "Please enter your School Name",
				branchName: "Please enter your Branch Name",
				schoolType: "Please enter your School Type",
				schoolURL:  {
                    required: "Please enter School URL",
                    url: "Enter valid URL",
                },
				country: "Please Select Country",
				state: "Please Select state",
				city: "Please Select city",
				schoolAddress: "Please enter your School Address",
				principleName: "Please enter your Principle Name",
				principleEmail:  {
					required: "Please enter Principle Email",
					email: "Please enter Valid Email",
                    remote: "Email Id Exist!",
				},
				principlePassword: "Please enter your Principle Password",
				adminName: "Please enter your Admin Name",
				adminEmail: {
					required: "Please enter Admin Email",
					email: "Please enter Valid Email",
                    remote: "Email Id Exist!",
				},
				adminPassword: "Please enter your Admin Password",
				schoolPhone: {
					required: "Please enter a School Phone",
					number: "Please Enter Only Number",
					minlength: "School Phone must consist of at least 10 number",
					maxlength: "School Mobile not more than 12 number"
				},
				schoolMobile: {
					required: "Please enter a School Mobile",
					number: "Please Enter Only Number",
					minlength: "School Mobile must consist of at least 10 number",
					maxlength: "School Mobile not more than 12 number"
				},
				userTermsAgreement: {
					required: "Please check Terms Agreement"
				}
			},
			  submitHandler: function(form) {
				$('#myModal').modal('show');
			  }

			            	  
	});
  });
  


	$(".submitregistration").click(function(){
        //alert("Vikash");
        //alert(schoolBaseImage);
		var subscribe_plan = $(this).attr('id');
				
			console.log(schoolBaseImage);
		 
			var schoolName = $.trim($('#schoolName').val());
			var schoolType = $('#schoolType').val();
			var schoolURL = $('#schoolURL').val();
			var branchName = $.trim($('#branchName').val());
			var country = $('#country').val();
			var state = $('#state').val();
			var city = $('#city').val();
			var schoolAddress = $.trim($('#schoolAddress').val());
			var principleName = $.trim($('#principleName').val());
			var principleEmail = $.trim($('#principleEmail').val());
			var principlePassword = $('#principlePassword').val();
			var adminName = $.trim($('#adminName').val());
			var adminEmail = $.trim($('#adminEmail').val());
			var adminPassword = $('#adminPassword').val();
			var otherAdminUser = $('#otherAdminUser').val();
			var schoolLogo = $('#schoolLogo').val();
			var schoolPhone = $('#schoolPhone').val();
			var schoolMobile = $('#schoolMobile').val();
			var otherAdminEmail = [];
			$("input[name='otherAdminEmail[]']").each(function() {
				if($(this).val()!=""){
					otherAdminEmail.push($.trim($(this).val()));
				}
			});
			
			var otherAdminPassword = [];
			$("input[name='otherAdminPassword[]']").each(function() {
				if($(this).val()!=""){
					$.trim(otherAdminPassword.push($(this).val()));
				}
			});

			
			$.ajax({
				url: "http://52.90.39.26/talking_classes/schooladmin/schools/manage",
				type: "GET",
				async: false,
				data: {"flag":"add_school","schoolName":schoolName,"schoolType":schoolType,"schoolURL":schoolURL,"branchName":branchName,"country":country,"state":state,"city":city,"schoolAddress":schoolAddress,"principleName":principleName,"principleEmail":principleEmail,"principlePassword":principlePassword,"adminName":adminName,"adminEmail":adminEmail,"adminPassword":adminPassword,"otherAdminEmail":otherAdminEmail,"otherAdminPassword":otherAdminPassword,"schoolPhone":schoolPhone,"schoolMobile":schoolMobile,"subscribePlan":subscribe_plan},
				dataType: "html",
				success: function(result){		
				var decodedJson = jQuery.parseJSON(result);
				console.log(result);
				if(decodedJson.response.response_status){
					$('#myModal').modal('hide');
					//alert('Register successfull');
					var school_idss = decodedJson.response.response_data.school_id;
					var branch_idss = decodedJson.response.response_data.branch_id;
					//alert(school_idss);
					//alert(branch_idss);
					if(schoolBaseImage!=""){
						$.ajax({
							url: "http://52.90.39.26/talking_classes/schooladmin/schools/manage?flag=upload_school_image",
							type:"post",
							async: false,
							data: {
								"school_base_image":schoolBaseImage,'school_idss':school_idss,'branch_idss':branch_idss
							},
							success: function(response){
								//swal("Thank You!", "For Registration", "success");
								setTimeout(function(){ 
									window.location.replace("http://52.90.39.26/tc-website/school-success.php");
								}, 3000);
							},
							error:function(xhr, ajaxOptions, thrownError){alert(xhr.responseText); ShowMessage("??? ?? ?????? ??????? ????","fail");}
						});
					}else{
						//swal("Thank You!", "For Registration", "success");
						setTimeout(function(){ 
							window.location.replace("http://52.90.39.26/tc-website/school-success.php");
						}, 5000);
						
					}

				}else{
					alert("Error");
				}
	//{"response":{"response_status":true,"response_message":"success","response_data":""}}
			  }
			});	
		  
	});
});
</script>

<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/jquery.fitvids.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/jquery.parallax-1.1.3.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/jquery.ajaxchimp.min.js"></script>
<script src="js/jquery.ajaxchimp.langs.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/waypoints.min.js"></script>
<script src="js/jquery.counterup.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>