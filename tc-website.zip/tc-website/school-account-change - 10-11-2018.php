<?php session_start(); ?>
<?php
/* echo "<pre>";
print_r($_SESSION);
echo "</pre>";  */
if (!isset($_SESSION['userId'])) {
    header('Location:school-zone.php');
    exit;
} else {
    $userIds = $_SESSION['userId'];
    $userName = $_SESSION['userName'];
    $schoolId = $_SESSION['schoolId'];
    $schoolBranchId = $_SESSION['schoolBranch'];
}
?>

<!DOCTYPE html>
<html lang="en">
<!--
Bent - Bootstrap Landing Page Template by Dcrazed
Site: https://dcrazed.com/bent-app-landing-page-template/
Free for personal and commercial use under GNU GPL 3.0 license.
-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Talking Classes | School Account.</title>
    <!-- Google Font -->
    <link href='https://fonts.googleapis.com/css?family=Raleway:500,600,700,800,900,400,300' rel='stylesheet'
          type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,900,300italic,400italic'
          rel='stylesheet' type='text/css'>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap -->

    <link href="css/styles.imageuploader.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/datepicker.css" rel="stylesheet">

    <!-- Owl Carousel Assets -->
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">
    <!-- Pixeden Icon Font -->
    <link rel="stylesheet" href="css/Pe-icon-7-stroke.css">
    <!-- Font Awesome -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- PrettyPhoto -->
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
    <!-- Style -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <!-- Responsive CSS -->
    <link href="css/responsive.css" rel="stylesheet">
    <link href="css/bootstrap-toggle.css" rel="stylesheet">
    <link href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.css' rel='stylesheet'
          type='text/css'>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
    <link href="css/bootstrap-multiselect.css" rel="stylesheet">
    <style>
        .table-header-background {
            background-color: #F39C12;
            color: #ffffff;
        }
		#HOME button{outline:none;}
    </style>
    <style>
        .ui-autocomplete {
            max-height: 100px;
            overflow-y: auto;
            /* prevent horizontal scrollbar */
            overflow-x: hidden;
        }

        /* IE 6 doesn't support max-height
         * we use height instead, but this forces the menu to always be this tall
         */
        * html .ui-autocomplete {
            height: 100px;
        }

        ul.ui-autocomplete {
            z-index: 1100;
        }
    </style>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style>
        #taw a {
            text-decoration: none;
            cursor: pointer;
			outline:none;
			margin-top:12px;
        }
        .VM9Z5b {
            height: 48px;
            margin-right: 8px;
        }

        .dgdd6c, .dgdd6c div, .dgdd6c span {
            display: inline-block;
        }

        .dgdd6c {
            margin-bottom: 6px;
            margin-top: 2px;
        }

        .mR2gOd {
            white-space: nowrap;
        }

        .dgdd6c, .dgdd6c div, .dgdd6c span {
            display: inline-block;
        }

        .Mw2I7 {
            box-shadow: 0 1px 6px rgba(32, 33, 36, 0.28);
            background-color: white;
            border-radius: 48px;
            box-sizing: border-box;
            overflow: hidden;
            padding: 2px 28px;
        }

        .mR2gOd {
            white-space: nowrap;
        }

        .Mw2I7 span.dtviD {
            color: #3C4043;
            font-size: 14px;
            font-weight: 400;
            line-height: 30px;
            text-decoration: none;
            white-space: nowrap;
        }

        .dgdd6c, .dgdd6c div, .dgdd6c span {
            display: inline-block;
        }

        .btnActive {
            background-color: #F39C12;
            border-color: #D2E3FC;
            color: #fff !important;
        }

        .btnActive span {

            color: #fff !important;
        }

        .btnActiveNB {
            background-color: #F39C12;
            border-color: #D2E3FC;
            color: #fff !important;
        }

        .btnActiveNB span {

            color: #fff !important;
        }

        .btnActiveVT {
            background-color: #F39C12;
            border-color: #D2E3FC;
            color: #fff !important;
        }

        .btnActiveVT span {

            color: #fff !important;
        }

        .btnActiveMessage {
            background-color: #F39C12;
            border-color: #D2E3FC;
            color: #fff !important;
        }

        .btnActiveMessage span {

            color: #fff !important;
        }

        .btnActivePL {
            background-color: #F39C12;
            border-color: #D2E3FC;
            color: #fff !important;
        }

        .btnActivePL span {

            color: #fff !important;
        }

        .btnActiveRP {
            background-color: #F39C12;
            border-color: #D2E3FC;
            color: #fff !important;
        }

        .btnActiveRP span {

            color: #fff !important;
        }

        .btnActiveSetting {
            background-color: #F39C12;
            border-color: #D2E3FC;
            color: #fff !important;
        }

        .btnActiveSetting span {

            color: #fff !important;
        }

        .btnActiveGallery {
            background-color: #F39C12;
            border-color: #D2E3FC;
            color: #fff !important;
        }

        .btnActiveGallery span {

            color: #fff !important;
        }

        /* Style the tab content */
        .tabcontent {
            display: none;
            padding: 6px 12px;
            border-top: none;
        }
    </style>
    <style>
        .profile-header-container {
            margin: 0 auto;
        }

        .profile-header-img {
            padding: 10px 0px 0px 25px;
        }

        .profile-header-img > img.img-circle {
            width: 100px;
            height: 100px;
            border: 2px solid #4C99CC;
        }

        .profile-header {
            /* margin-top: 50px;*/
        }

        /**
         * Ranking component
         */
        .rank-label-container {
            margin-top: -19px;
            /* z-index: 1000; */
            text-align: center;
        }

        .label.label-default.rank-label {
            background-color: rgb(81, 210, 183);
            padding: 5px 10px 5px 10px;
            border-radius: 27px;
        }
    </style>
    <style>
        .navbar {
            border-bottom: 2px solid #F0F0F0;
        }
        .sweet-alert .sa-icon{
            height: 87px;
        }
    </style>
    <style>
        .custom-input-box {
            background-color: #e5e8e8;
            border: 1px solid #ccd1d1;
            border-radius: 3px;
            padding: 5px 15px 5px 25px;
        }
    </style>

    <style>
        * {
            box-sizing: border-box;
        }

        /* .myInput {
            background-image: url('https://www.w3schools.com/css/searchicon.png');
            background-position: 10px 10px;
            background-repeat: no-repeat;
            width: 100%;
            font-size: 16px;
            padding: 12px 20px 12px 40px;
            border: 1px solid #ddd;
            margin-bottom: 12px;
        } */

        .myTable {
            border-collapse: collapse;
            width: 100%;
            border: 1px solid #ddd;
            font-size: 15px;
        }

        .myTable th, .myTable td {
            text-align: left;
            padding: 5px;
        }

        .myTable tr {
            border-bottom: 1px solid #ddd;
        }

        .myTable tr.header {
            background-color: #F39C12;
            color: #ffffff;
        }
    </style>
    <style>

        .avatar-upload {
            position: relative;
            max-width: 205px;
            margin: 0px auto;
        }

        .avatar-upload .avatar-edit {
            position: absolute;
            right: 12px;
            z-index: 1;
            top: 10px;
        }

        .avatar-upload .avatar-edit input {
            display: none;
        }

        .avatar-upload .avatar-edit input + label {
            display: inline-block;
            width: 34px;
            height: 34px;
            margin-bottom: 0;
            border-radius: 100%;
            background: #ffffff;
            border: 1px solid transparent;
            box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.12);
            cursor: pointer;
            font-weight: normal;
            transition: all 0.2s ease-in-out;
        }

        .avatar-upload .avatar-edit input + label:hover {
            background: #f1f1f1;
            border-color: #d6d6d6;
        }

        .avatar-upload .avatar-edit input + label:after {
            content: "\f040";
            font-family: "FontAwesome";
            color: #757575;
            position: absolute;
            top: 10px;
            left: 0;
            right: 0;
            text-align: center;
            margin: auto;
        }

        .avatar-upload .avatar-preview {
            width: 192px;
            height: 192px;
            position: relative;
            border-radius: 100%;
            border: 6px solid #f8f8f8;
            box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.1);
        }

        .avatar-upload .avatar-preview > div {
            width: 100%;
            height: 100%;
            border-radius: 100%;
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }

    </style>
    <style>
        * {
            box-sizing: border-box;
        }

        .myInput {
            background-image: url('https://www.w3schools.com/css/searchicon.png');
            background-position: 10px 10px;
            background-repeat: no-repeat;
            /*width: 100%;*/
            font-size: 16px;
            padding: 8px 10px 6px 40px;
            border: 1px solid #ddd;
            margin-bottom: 12px;
            border-radius: 50px;
        }

        .teacherTable {
            border-collapse: collapse;
            width: 100%;
            border: 1px solid #ddd;
            font-size: 16px;
        }

        .teacherTable th, .teacherTable td {
            text-align: left;
            padding: 5px;
        }

        .teacherTable tr {
            border-bottom: 1px solid #ddd;
        }

        .teacherTable tr.header {
            background-color: #F39C12;
            color: #ffffff;
        }

        .parentTable {
            border-collapse: collapse;
            width: 100%;
            border: 1px solid #ddd;
            font-size: 16px;
        }

        .parentTable th, .parentTable td {
            text-align: left;
            padding: 5px;
        }

        .parentTable tr {
            border-bottom: 1px solid #ddd;
        }

        .parentTable tr.header {
            background-color: #F39C12;
            color: #ffffff;
        }
    </style>
    <style>
        .grey {
            color: #000000;
        }

        .custom-button-default {
            background-color: #F39C12;
            border: 1px solid #F39C12;
            color: #ffffff;
        }

        .custom-button-default:hover {
            background-color: #ed930b;
            border: 1px solid #F39C12;
            color: #ffffff;
        }
    </style>

    <style>
        * {
            box-sizing: border-box;
        }

        .autocomplete {
            /*the container must be positioned relative:*/
            position: relative;
            display: inline-block;
        }

        .autocomplete-items {
            position: absolute;
            border: 1px solid #d4d4d4;
            border-bottom: none;
            border-top: none;
            z-index: 99;
            /*position the autocomplete items to be the same width as the container:*/
            top: 66%;
            left: 15px;
            right: 15px;
        }

        .autocomplete-items div {
            padding: 10px;
            cursor: pointer;
            background-color: #fff;
            border-bottom: 1px solid #d4d4d4;
        }

        .autocomplete-items div:hover {
            /*when hovering an item:*/
            background-color: #e9e9e9;
        }

        .autocomplete-active {
            /*when navigating through the items using the arrow keys:*/
            background-color: DodgerBlue !important;
            color: #ffffff;
        }

        .tableitems {
            font-size: 16px;;
        }
    </style>

    <style type="text/css">
        .ole, .elo {
            /*background: rgb(200,240,255);
            padding: 6px 36px;*/
            display: inline-block;
            font-size: 1.0em;
            border-radius: 4px;
            border: 0;
            cursor: pointer;
        }

        .ct {
            text-align: center
        }

        .ole:hover,
        .elo:hover {
            /*background: dodgerblue;*/
            /* color: #fff;*/
            /* text-shadow: 1px 1px 1px #000;*/
            /* box-shadow: 0 0 0 #555;*/
        }

        .multiple_elements {
            /* padding: 30px 0 10px 0;
             text-align: center;*/
        }

        /*customizing tooltip color*/
        /*right tooltip*/
        .tooltip.right > .tooltip-arrow {
            border-right-color: dodgerblue;
        }

        /*bottom tooltip*/
        .tooltip.bottom > .tooltip-arrow {
            border-bottom-color: dodgerblue;
        }

        /*top tooltip*/
        .tooltip.top > .tooltip-arrow {
            border-top-color: dodgerblue;
        }

        /*left tooltip*/
        .tooltip.left > .tooltip-arrow {
            border-left-color: dodgerblue;
        }

        /*tooltip inner*/
        .tooltip > .tooltip-inner {
            background-color: dodgerblue;
            text-shadow: 0 1px 1px #000;
            font-weight: normal;
        }

        code {
            color: royalblue;
            background-color: azure;
        }

        @media (max-width: 640px) {
            .ole,
            .elo {
                padding: 6px 12px;
                font-size: 12px;
            }
        }
    </style>

    <!--<style>
        .demo{ background: #e2e2e2; }
    .serviceBox{
        color: #606060;
        padding: 0 10px 60px;
        background-color: #F9A11C;
        border: 1px solid transparent;
        border-radius: 20px;
        margin: 80px 0 30px;
        position: relative;
     }
     .serviceBox .service-content{
       text-align: center;
        padding: 15px 20px 30px;
        margin-top: -80px;
        border-radius: 25px;
        background-color: #fff;
        position: relative;
        transition:all 0.3s;
     }
     .serviceBox .service-content:hover{
       box-shadow: 0 0 20px -5px #000;
     }
     .serviceBox .service-content:after{
        content: '';
        height: 50px;
        width: 50px;
        border: 25px solid transparent;
        border-top: 25px solid #fff;
        transform:translateX(-50%);
        position: absolute;
        bottom: -50px;
        left: 50%;
    }
    .serviceBox .service-icon{
        color: #F9A11C;
        font-size: 90px;
        margin-bottom: 10px;
        transition: all 0.3s ease 0s;
        border: 2px solid;
    border-radius: 5%;
    overflow: hidden;
    }
    .serviceBox:hover .service-icon{
        transform:rotateX(360deg);
    }
    .serviceBox .title{
        font-size: 18px;
        font-weight: 600;
        text-transform: uppercase;
        margin:50px 0px 12px 0px;
    }
    .serviceBox .description{
        font-size: 15px;
        line-height: 25px;
        margin: 0;
    }
    .serviceBox .read-more{
        display: block;
        width: 60%;
        font-size: 15px;
        font-weight: 600;
        text-transform: uppercase;
        text-align: center;
        color: #fff;
        padding: 10px 0;
        background-color: #6D4D42;
        border-radius: 15px;
        transform:translateX(-50%);
        transition:all 0.3s ease 0s;
        position: absolute;
        left: 50%;
        bottom: -20px;
    }
    .serviceBox .read-more:hover{
        text-decoration: none;
        letter-spacing: 2px;
        box-shadow: 0 0 10px #000;
    }
    .serviceBox.green{background-color: #44BB85;}
    .serviceBox.green .service-icon{color: #44BB85;}
    .serviceBox.green .read-more{background-color: #007A6D;}
    .serviceBox.blue{background-color: #36BFC5;}
    .serviceBox.blue .service-icon{color: #36BFC5;}
    .serviceBox.blue .read-more{background-color: #015F65;}
    .serviceBox.red{background-color: #f23d3a;}
    .serviceBox.red .service-icon{color: #f23d3a;}
    .serviceBox.red .read-more{background-color: #ad0e0c;}
    @media only screen and (max-width:990px){
        .serviceBox{ margin-bottom: 60px; }
        .serviceBox .service-content{padding: 20px 15px 30px;}
    }
    @media only screen and (max-width:767px){
        .serviceBox{ margin-bottom: 130px; }
    }
    </style>-->

    <!-- Chat Message Css-->

    <style class="cp-pen-styles">

        #frame {
            width: 100%;
            min-width: 360px;
            max-width: 100%;
            height: 92vh;
            min-height: 300px;
            max-height: 720px;
            background: #E6EAEA;
        }

        @media screen and (max-width: 360px) {
            #frame {
                width: 100%;
                height: 100vh;
            }
        }

        #frame #sidepanel {
            float: left;
            min-width: 280px;
            max-width: 340px;
            width: 40%;
            height: 100%;
            background: #2c3e50;
            color: #f5f5f5;
            overflow: hidden;
            position: relative;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel {
                width: 58px;
                min-width: 58px;
            }
        }

        #frame #sidepanel #profile {
            width: 80%;
            margin: 25px auto;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #profile {
                width: 100%;
                margin: 0 auto;
                padding: 5px 0 0 0;
                background: #32465a;
            }
        }

        #frame #sidepanel #profile.expanded .wrap {
            height: 210px;
            line-height: initial;
        }

        #frame #sidepanel #profile.expanded .wrap p {
            margin-top: 20px;
        }

        #frame #sidepanel #profile.expanded .wrap i.expand-button {
            -moz-transform: scaleY(-1);
            -o-transform: scaleY(-1);
            -webkit-transform: scaleY(-1);
            transform: scaleY(-1);
            filter: FlipH;
            -ms-filter: "FlipH";
        }

        #frame #sidepanel #profile .wrap {
            height: 60px;
            line-height: 60px;
            overflow: hidden;
            -moz-transition: 0.3s height ease;
            -o-transition: 0.3s height ease;
            -webkit-transition: 0.3s height ease;
            transition: 0.3s height ease;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #profile .wrap {
                height: 55px;
            }
        }

        #frame #sidepanel #profile .wrap img {
            width: 50px;
            border-radius: 50%;
            padding: 3px;
            border: 2px solid #e74c3c;
            height: auto;
            float: left;
            cursor: pointer;
            -moz-transition: 0.3s border ease;
            -o-transition: 0.3s border ease;
            -webkit-transition: 0.3s border ease;
            transition: 0.3s border ease;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #profile .wrap img {
                width: 40px;
                margin-left: 4px;
            }
        }

        #frame #sidepanel #profile .wrap img.online {
            border: 2px solid #2ecc71;
        }

        #frame #sidepanel #profile .wrap img.away {
            border: 2px solid #f1c40f;
        }

        #frame #sidepanel #profile .wrap img.busy {
            border: 2px solid #e74c3c;
        }

        #frame #sidepanel #profile .wrap img.offline {
            border: 2px solid #95a5a6;
        }

        #frame #sidepanel #profile .wrap p {
            float: left;
            margin-left: 15px;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #profile .wrap p {
                display: none;
            }
        }

        #frame #sidepanel #profile .wrap i.expand-button {
            float: right;
            margin-top: 23px;
            font-size: 0.8em;
            cursor: pointer;
            color: #435f7a;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #profile .wrap i.expand-button {
                display: none;
            }
        }

        #frame #sidepanel #profile .wrap #status-options {
            position: absolute;
            opacity: 0;
            visibility: hidden;
            width: 150px;
            margin: 70px 0 0 0;
            border-radius: 6px;
            z-index: 99;
            line-height: initial;
            background: #435f7a;
            -moz-transition: 0.3s all ease;
            -o-transition: 0.3s all ease;
            -webkit-transition: 0.3s all ease;
            transition: 0.3s all ease;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #profile .wrap #status-options {
                width: 58px;
                margin-top: 57px;
            }
        }

        #frame #sidepanel #profile .wrap #status-options.active {
            opacity: 1;
            visibility: visible;
            margin: 75px 0 0 0;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #profile .wrap #status-options.active {
                margin-top: 62px;
            }
        }

        #frame #sidepanel #profile .wrap #status-options:before {
            content: '';
            position: absolute;
            width: 0;
            height: 0;
            border-left: 6px solid transparent;
            border-right: 6px solid transparent;
            border-bottom: 8px solid #435f7a;
            margin: -8px 0 0 24px;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #profile .wrap #status-options:before {
                margin-left: 23px;
            }
        }

        #frame #sidepanel #profile .wrap #status-options ul {
            overflow: hidden;
            border-radius: 6px;
        }

        #frame #sidepanel #profile .wrap #status-options ul li {
            padding: 15px 0 30px 18px;
            display: block;
            cursor: pointer;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #profile .wrap #status-options ul li {
                padding: 15px 0 35px 22px;
            }
        }

        #frame #sidepanel #profile .wrap #status-options ul li:hover {
            background: #496886;
        }

        #frame #sidepanel #profile .wrap #status-options ul li span.status-circle {
            position: absolute;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin: 5px 0 0 0;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #profile .wrap #status-options ul li span.status-circle {
                width: 14px;
                height: 14px;
            }
        }

        #frame #sidepanel #profile .wrap #status-options ul li span.status-circle:before {
            content: '';
            position: absolute;
            width: 14px;
            height: 14px;
            margin: -3px 0 0 -3px;
            background: transparent;
            border-radius: 50%;
            z-index: 0;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #profile .wrap #status-options ul li span.status-circle:before {
                height: 18px;
                width: 18px;
            }
        }

        #frame #sidepanel #profile .wrap #status-options ul li p {
            padding-left: 12px;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #profile .wrap #status-options ul li p {
                display: none;
            }
        }

        #frame #sidepanel #profile .wrap #status-options ul li#status-online span.status-circle {
            background: #2ecc71;
        }

        #frame #sidepanel #profile .wrap #status-options ul li#status-online.active span.status-circle:before {
            border: 1px solid #2ecc71;
        }

        #frame #sidepanel #profile .wrap #status-options ul li#status-away span.status-circle {
            background: #f1c40f;
        }

        #frame #sidepanel #profile .wrap #status-options ul li#status-away.active span.status-circle:before {
            border: 1px solid #f1c40f;
        }

        #frame #sidepanel #profile .wrap #status-options ul li#status-busy span.status-circle {
            background: #e74c3c;
        }

        #frame #sidepanel #profile .wrap #status-options ul li#status-busy.active span.status-circle:before {
            border: 1px solid #e74c3c;
        }

        #frame #sidepanel #profile .wrap #status-options ul li#status-offline span.status-circle {
            background: #95a5a6;
        }

        #frame #sidepanel #profile .wrap #status-options ul li#status-offline.active span.status-circle:before {
            border: 1px solid #95a5a6;
        }

        #frame #sidepanel #profile .wrap #expanded {
            padding: 100px 0 0 0;
            display: block;
            line-height: initial !important;
        }

        #frame #sidepanel #profile .wrap #expanded label {
            float: left;
            clear: both;
            margin: 0 8px 5px 0;
            padding: 5px 0;
        }

        #frame #sidepanel #profile .wrap #expanded input {
            border: none;
            margin-bottom: 6px;
            background: #32465a;
            border-radius: 3px;
            color: #f5f5f5;
            padding: 7px;
            width: calc(100% - 43px);
        }

        #frame #sidepanel #profile .wrap #expanded input:focus {
            outline: none;
            background: #435f7a;
        }

        #frame #sidepanel #search {
            border-top: 1px solid #32465a;
            border-bottom: 1px solid #32465a;
            font-weight: 300;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #search {
                display: none;
            }
        }

        #frame #sidepanel #search label {
            position: absolute;
            margin: 10px 0 0 20px;
        }

        #frame #sidepanel #search input {
            font-family: "proxima-nova", "Source Sans Pro", sans-serif;
            padding: 10px 0 10px 46px;
            width: calc(100% - 25px);
            border: none;
            background: #32465a;
            color: #f5f5f5;
        }

        #frame #sidepanel #search input:focus {
            outline: none;
            background: #435f7a;
        }

        #frame #sidepanel #search input::-webkit-input-placeholder {
            color: #f5f5f5;
        }

        #frame #sidepanel #search input::-moz-placeholder {
            color: #f5f5f5;
        }

        #frame #sidepanel #search input:-ms-input-placeholder {
            color: #f5f5f5;
        }

        #frame #sidepanel #search input:-moz-placeholder {
            color: #f5f5f5;
        }

        #frame #sidepanel #contacts {
            height: calc(100% - 177px);
            overflow-y: scroll;
            overflow-x: hidden;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #contacts {
                height: calc(100% - 149px);
                overflow-y: scroll;
                overflow-x: hidden;
            }

            #frame #sidepanel #contacts::-webkit-scrollbar {
                display: none;
            }
        }

        #frame #sidepanel #contacts.expanded {
            height: calc(100% - 334px);
        }

        #frame #sidepanel #contacts::-webkit-scrollbar {
            width: 8px;
            background: #2c3e50;
        }

        #frame #sidepanel #contacts::-webkit-scrollbar-thumb {
            background-color: #243140;
        }

        #frame #sidepanel #contacts ul li.contact {
            position: relative;
            padding: 10px 0 15px 0;
            font-size: 0.9em;
            cursor: pointer;
            background: transparent;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #contacts ul li.contact {
                padding: 6px 0 46px 8px;
            }
        }

        #frame #sidepanel #contacts ul li.contact:hover {
            background: #32465a;
        }

        #frame #sidepanel #contacts ul li.contact.active {
            background: #32465a;
            border-right: 5px solid #435f7a;
        }

        #frame #sidepanel #contacts ul li.contact.active span.contact-status {
            border: 2px solid #32465a !important;
        }

        #frame #sidepanel #contacts ul li.contact .wrap {
            width: 88%;
            margin: 0 auto;
            position: relative;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #contacts ul li.contact .wrap {
                width: 100%;
            }
        }

        #frame #sidepanel #contacts ul li.contact .wrap span {
            position: absolute;
            left: 0;
            margin: -2px 0 0 -2px;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            border: 2px solid #2c3e50;
            background: #95a5a6;
        }

        #frame #sidepanel #contacts ul li.contact .wrap span.online {
            background: #2ecc71;
        }

        #frame #sidepanel #contacts ul li.contact .wrap span.away {
            background: #f1c40f;
        }

        #frame #sidepanel #contacts ul li.contact .wrap span.busy {
            background: #e74c3c;
        }

        #frame #sidepanel #contacts ul li.contact .wrap img {
            width: 40px;
            border-radius: 50%;
            float: left;
            margin-right: 10px;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #contacts ul li.contact .wrap img {
                margin-right: 0px;
            }
        }

        #frame #sidepanel #contacts ul li.contact .wrap .meta {
            padding: 5px 0 0 0;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #contacts ul li.contact .wrap .meta {
                display: none;
            }
        }

        #frame #sidepanel #contacts ul li.contact .wrap .meta .name {
            font-weight: 600;
        }

        #frame #sidepanel #contacts ul li.contact .wrap .meta .preview {
            margin: 5px 0 0 0;
            padding: 0 0 1px;
            font-weight: 400;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            -moz-transition: 1s all ease;
            -o-transition: 1s all ease;
            -webkit-transition: 1s all ease;
            transition: 1s all ease;
        }

        #frame #sidepanel #contacts ul li.contact .wrap .meta .preview span {
            position: initial;
            border-radius: initial;
            background: none;
            border: none;
            padding: 0 2px 0 0;
            margin: 0 0 0 1px;
            opacity: .5;
        }

        #frame #sidepanel #bottom-bar {
            position: absolute;
            width: 100%;
            bottom: 0;
        }

        #frame #sidepanel #bottom-bar button {
            float: left;
            border: none;
            width: 100%;
            padding: 10px 0;
            background: #32465a;
            color: #f5f5f5;
            cursor: pointer;
            /*font-size: 0.85em;*/
            font-family: "proxima-nova", "Source Sans Pro", sans-serif;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #bottom-bar button {
                float: none;
                width: 100%;
                padding: 15px 0;
            }
        }

        #frame #sidepanel #bottom-bar button:focus {
            outline: none;
        }

        #frame #sidepanel #bottom-bar button:nth-child(1) {
            border-right: 1px solid #2c3e50;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #bottom-bar button:nth-child(1) {
                border-right: none;
                border-bottom: 1px solid #2c3e50;
            }
        }

        #frame #sidepanel #bottom-bar button:hover {
            background: #435f7a;
        }

        #frame #sidepanel #bottom-bar button i {
            margin-right: 3px;
            font-size: 1em;
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #bottom-bar button i {
                font-size: 1.3em;
            }
        }

        @media screen and (max-width: 735px) {
            #frame #sidepanel #bottom-bar button span {
                display: none;
            }
        }

        #frame .content {
            float: right;
            width: 60%;
            height: 100%;
            overflow: hidden;
            position: relative;
        }

        @media screen and (max-width: 735px) {
            #frame .content {
                width: calc(100% - 58px);
                min-width: 300px !important;
            }
        }

        @media screen and (min-width: 900px) {
            #frame .content {
                width: calc(100% - 340px);
            }
        }

        #frame .content .contact-profile {
            width: 100%;
            height: 60px;
            line-height: 60px;
            background: #f5f5f5;
        }

        #frame .content .contact-profile img {
            width: 40px;
            border-radius: 50%;
            float: left;
            margin: 18px 12px 0 9px;
        }

        #frame .content .contact-profile p {
            float: left;
        }

        #frame .content .contact-profile .social-media {
            float: right;
        }

        #frame .content .contact-profile .social-media i {
            margin-left: 14px;
            cursor: pointer;
        }

        #frame .content .contact-profile .social-media i:nth-last-child(1) {
            margin-right: 20px;
        }

        #frame .content .contact-profile .social-media i:hover {
            color: #435f7a;
        }

        #frame .content .messages {
            height: auto;
            min-height: calc(100% - 93px);
            max-height: calc(100% - 93px);
            overflow-y: scroll;
            overflow-x: hidden;
        }

        @media screen and (max-width: 735px) {
            #frame .content .messages {
                max-height: calc(100% - 105px);
            }
        }

        #frame .content .messages::-webkit-scrollbar {
            width: 8px;
            background: transparent;
        }

        #frame .content .messages::-webkit-scrollbar-thumb {
            background-color: rgba(0, 0, 0, 0.3);
        }

        #frame .content .messages ul li {
            display: inline-block;
            clear: both;
            float: left;
            margin: 15px 15px 5px 15px;
            width: calc(100% - 25px);
            font-size: 0.9em;
        }

        #frame .content .messages ul li:nth-last-child(1) {
            margin-bottom: 20px;
        }

        #frame .content .messages ul li.sent img {
            margin: 6px 8px 0 0;
        }

        #frame .content .messages ul li.sent p {
            background: #435f7a;
            color: #f5f5f5;
        }

        #frame .content .messages ul li.replies img {
            float: right;
            margin: 6px 0 0 8px;
        }

        #frame .content .messages ul li.replies p {
            background: #f5f5f5;
            float: right;
        }

        #frame .content .messages ul li img {
            width: 22px;
            border-radius: 50%;
            float: left;
        }

        #frame .content .messages ul li p {
            display: inline-block;
            padding: 10px 15px;
            border-radius: 20px;
            max-width: 205px;
            line-height: 130%;
        }

        @media screen and (min-width: 735px) {
            #frame .content .messages ul li p {
                max-width: 300px;
            }
        }

        #frame .content .message-input {
            position: absolute;
            bottom: 0;
            width: 100%;
            z-index: 99;
        }

        #frame .content .message-input .wrap {
            position: relative;
        }

        #frame .content .message-input .wrap input {
            font-family: "proxima-nova", "Source Sans Pro", sans-serif;
            float: left;
            border: none;
            width: calc(100% - 90px);
            padding: 11px 32px 10px 8px;
            font-size: 0.8em;
            color: #32465a;
        }

        @media screen and (max-width: 735px) {
            #frame .content .message-input .wrap input {
                padding: 15px 32px 16px 8px;
            }
        }

        #frame .content .message-input .wrap input:focus {
            outline: none;
        }

        #frame .content .message-input .wrap .attachment {
            position: absolute;
            right: 60px;
            z-index: 4;
            margin-top: 10px;
            font-size: 1.1em;
            color: #435f7a;
            opacity: .5;
            cursor: pointer;
        }

        @media screen and (max-width: 735px) {
            #frame .content .message-input .wrap .attachment {
                margin-top: 17px;
                right: 65px;
            }
        }

        #frame .content .message-input .wrap .attachment:hover {
            opacity: 1;
        }

        #frame .content .message-input .wrap button {
            float: right;
            border: none;
            width: 50px;
            padding: 12px 0;
            cursor: pointer;
            background: #32465a;
            color: #f5f5f5;
        }

        @media screen and (max-width: 735px) {
            #frame .content .message-input .wrap button {
                padding: 16px 0;
            }
        }

        #frame .content .message-input .wrap button:hover {
            background: #435f7a;
        }

        #frame .content .message-input .wrap button:focus {
            outline: none;
        }
    </style>

    <!-- Chat Message Css-->
</head>
<body>
<!-- PRELOADER -->
<div class="spn_hol">
    <div class="spinner">
        <div class="bounce1"></div>
        <div class="bounce2"></div>
        <div class="bounce3"></div>
    </div>
</div>
<!-- END PRELOADER -->
<!-- =========================
START ABOUT US SECTION
============================== -->
<section class="header parallax home-parallax page" id="HOME" style="background:none;">
    <h2></h2>
    <div class="section_overlay">
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                            data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">
                        <img src="images/logo-transparent.png" alt="Logo">
                    </a>
                </div>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <!-- NAV -->
                       <!-- <li><a href="#HOME">..............</a></li>
                        <li><a href="#SCHOOL_ZONE">.............. </a></li>
                        <li><a href="#ABOUT">..............</a></li>
                        <li><a href="#FEATURES">..............</a></li>
                        <li><a href="#SCREENS">..............</a></li>
                        <li><a href="#DOWNLOAD">.............. </a></li>
                        <li><a href="#CONTACT">.............. </a></li>-->
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
            <!-- /.container- -->
        </nav>

    </div>
</section>
<!-- END HEADER SECTION -->
</div>
</div>
</div>
</div>
</section>


<!-- Modal -->
<div class="modal fade" id="editProfile" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Edit Profile</h4>
            </div>
            <div class="modal-body">
                <div>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <form id="registrationForm" name="registrationForm">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label for="exampleFormControlInput1">First Name </label>
                                                <input type="text" class="form-control custom-input-box" id="firstName"
                                                       name="firstName" placeholder="First Name">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-6">
                                            <div class="form-group">
                                                <label for="exampleFormControlInput1">Last Name </label>
                                                <input type="text" class="form-control custom-input-box"
                                                       id="lastName" name="lastName" placeholder="Last Name">
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label for="exampleFormControlInput1">Designation</label>
                                                <input type="text" class="form-control custom-input-box"
                                                       id="userDesignation" name="userDesignation"
                                                       placeholder="Designation">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-6">
                                            <div class="form-group">
                                                <label for="exampleFormControlInput1">Password</label>
                                                <input type="password" class="form-control custom-input-box"
                                                       id="newPassword" name="newPassword" placeholder="Password">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-12">

                                            <label>Profile Image</label>

                                            <div class="avatar-upload">
                                                <div class="avatar-edit">
                                                    <input type="hidden" id="userImages" name="userImages">
                                                    <input type='file' id="imageUpload1" name="schoolLogo"
                                                           accept=".png, .jpg, .jpeg"/>
                                                    <label for="imageUpload1"></label>
                                                </div>
                                                <div class="avatar-preview">
                                                    <div id="imagePreview1"
                                                         style="background-image: url(images/logo-transparent.png);">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-12">
                                            <div style="margin-top:20px;">
                                                <div class="row">

                                                    <div class="col-md-12 col-sm-6">
                                                        <div class="form-group">
                                                            <label for="exampleFormControlInput1">Mobile Phone</label>
                                                            <input type="text" class="form-control custom-input-box"
                                                                   id="userMobile" name="userMobile"
                                                                   placeholder="School Phone">
                                                            <span style="color:#DB8C0E">e.g.: +91-XXXXXXXXXX </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="button" id="editProfileUpdateClick" class="btn btn-primary" value="Update"/>
                <button type="button" class="btn btn-default custom-button full-width" data-dismiss="modal">Cancel
                </button>
            </div>
        </div>

    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="editTeacherData" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Update Teacher Information</h4>
            </div>
            <div class="modal-body">
                <div>
                    <form name="editTeacherClassSectionForm" id="editTeacherClassSectionForm">

                        <div class="container">
                            <div class="row">
                                <div class="col-md-3">

                                    <div class="row">
                                        <div class="col-md-3">
                                            <img src='http://localhost/talking_classes_staging/assets/user_images/users/user-defaul-image.png' alt='Teacher Image'
                                                 class='img-circle img-responsive' id="teacherProfileImage" style='width:55px;height:55px;'>
                                        </div>
                                        <div class="col-md-9">
                                            <h4 id="madalUserName">Tushar Singh</h4>
                                            <h5 id="modalUserEmail">Tusharsingh44@gmail.com</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <p><span><b>Signed On : </b></span> <span id="modalUserSignedOn"> </span>
                                    </p>
                                    <p><span><b>Status : </b></span> <span id="modalUserStatu"
                                                                           style='color:green;'></span></p>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="exampleFormControlInput1">Teacher Id No.</label>
                                        <input type="text" class="form-control custom-input-box" id="teacherIdNumb"
                                               name="teacherIdNumb" placeholder="Teacher Id Number">
                                        <input type="hidden" class="form-control custom-input-box" id="teacheIds"
                                               name="teacheIds">

                                    </div>
                                </div>
                            </div>
                            <br/>
                            <div id="editClassSectionData">


                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default custom-button full-width" data-dismiss="modal">Close
                </button>
                <button type="button" class="btn btn-default custom-button-default full-width updateClassSectionInfo">
                    Save
                </button>
                <button type="button" class="btn btn-default custom-button full-width removeTeacherFromSchool">Remove
                    From School
                </button>
            </div>
        </div>

    </div>
</div>
<!-- *************** Edit Profile Form Start Here ************ -->
<div class="modal fade" id="editPostData" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Update Post Information</h4>
            </div>
            <div class="modal-body">
                <div>
                    <div class="row">
                        <div class="col-md-8">
                            <div><label>Post Category</label></div>
                            <div><select id="select_updatepost_category" class="form-control"></select></div>
                            <div style="marign-top:10px;"><label>Post Content</label></div>
                            <div>
                                <textarea id="updatepost_content_text" class="form-control"></textarea>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div>Post Preview</div>
                            <br/>
                            <div style="border:1px solid #d1d1d1;padding:10px;border-radius:4px;">
                                <div style="background-color:#FFF;padding:10px;">
                                    <div>
                        <span class="updatepost_postview_category"
                              style="padding:4px 5px;border:1px solid #c3c3c3;border-radius:4px;">General</span>
                                    </div>
                                    <center>
                                        <div class="updatepost_postimagecontainer"
                                             style="display: none;padding-top:20px;"><img class="postthumb_image" src=""
                                                                                          alt=""
                                                                                          style="width:200px;height:200px;margin: auto auto;">
                                        </div>
                                    </center>
                                    <div style="padding: 10px 0px;">
                                        <div class="updatepost_postview_content"></div>
                                    </div>
                                    <div style="padding: 10px 0px;">
                                        <div class="updatepost_postview_username"><?php echo $userName ?></div>
                                    </div>
                                </div>
                            </div>

                            <div>
                                <center>
                                    <div style="margin-top:10px;width:200px;display: none;"
                                         class="updatepost_uploadimagecontainer">
                                        <input type="file" class="updatepost_filepostimage"
                                               style="position: absolute;width: 200px;opacity:0;height: 35px;cursor: pointer;"
                                               name="">
                                        <div class="btn btn-pirmary"
                                             style="border:1px solid #c3c3c3;width:200px;">Select Image to
                                            upload
                                        </div>
                                    </div>
                                    <div style="margin-top:10px;width:200px;display:none;"
                                         class="updatepost_uploadpdfcontainer">
                                        <input type="file" class="filepostpdf"
                                               style="position: absolute;width: 200px;opacity:0;height: 35px;cursor: pointer;"
                                               name="">
                                        <div class="btn btn-pirmary"
                                             style="border:1px solid #c3c3c3;width:200px;">Select PDF to upload
                                        </div>
                                    </div>
                                </center>
                            </div>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-md-8"></div>

                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default custom-button full-width" data-dismiss="modal">Close
                </button>
                <button type="button" class="btn btn-default custom-button-default full-width updatePostInformation">
                    Update
                </button>
            </div>
        </div>

    </div>
</div>

<div class="modal fade" id="addNewAlbumItem" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Select image to add in Album</h4>
            </div>
            <div class="modal-body">
                <section role="main" class="l-main" style="margin-top:50px;">
                        <div class="uploader__box js-uploader__box l-center-box">
                            <form action="#" method="POST">
                                <div class="uploader__contents">
                                    <label class="button button--secondary" for="fileinput">Select Files</label>
                                    <input id="fileinput" class="uploader__file-input" type="file" multiple value="Select Files">
                                </div>
                                <input class="button button--big-bottom" type="submit" value="Upload Selected Files">
                            </form>
                        </div>
                    </section>
            </div>
        </div>

    </div>
</div>
<div class="modal fade" id="addNewGallery" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Create New Gallery</h4>
            </div>
            <div class="modal-body">
                <div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div>Album Name</div>
                            <div><input type="text" class="form-control" id="album_name" /></div>
                            <div class="alert-danger albumnameerror" style="padding:10px;display: none;">Name cannot be left blank!</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default custom-button full-width" data-dismiss="modal">Close
                </button>
                <button type="button" class="btn btn-default custom-button-default full-width btnCreateAlbum">
                    Create Album
                </button>
            </div>
        </div>

    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="viewSchoolUserDetails" role="dialog">
    <div class="modal-dialog  modal-lg">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Admin Details</h4>
            </div>
            <div class="modal-body">
                <div>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <form id="editProfileForm" name="editProfileForm">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label for="schoolUserFirstName">First Name </label>
                                                <input type="text" class="form-control custom-input-box" id="schoolUserFirstName" name="schoolUserFirstName" placeholder="First Name">
                                                <input type="hidden" id="clickSchoolUserId" name="clickSchoolUserId" />
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-6">
                                            <div class="form-group">
                                                <label for="schoolUserLastName">Last Name </label>
                                                <input type="text" class="form-control custom-input-box"
                                                       id="schoolUserLastName" name="schoolUserLastName" placeholder="Last Name">
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label for="schoolUserDesignation">Designation</label>
                                                <input type="text" class="form-control custom-input-box"
                                                       id="schoolUserDesignation" name="schoolUserDesignation"
                                                       placeholder="Designation">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-6">
                                            <div class="form-group">
                                                <label for="schoolUserNewPassword">Password</label>
                                                <input type="password" class="form-control custom-input-box"
                                                       id="schoolUserNewPassword" name="schoolUserNewPassword" placeholder="Password">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-12">

                                            <label>Profile Image</label>

                                            <div class="avatar-upload">
                                                <div class="avatar-edit">
                                                    <input type="hidden" id="schoolUserImages" name="schoolUserImages">
                                                    <input type='file' id="schoolUserLogo" name="schoolUserLogo"
                                                           accept=".png, .jpg, .jpeg"/>
                                                    <label for="schoolUserLogo"></label>
                                                </div>
                                                <div class="avatar-preview">
                                                    <div id="schoolUserImagePreview"
                                                         style="background-image: url(images/logo-transparent.png);">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-12">
                                            <div style="margin-top:20px;">
                                                <div class="row">

                                                    <div class="col-md-12 col-sm-6">
                                                        <div class="form-group">
                                                            <label for="schoolUserMobile">Mobile Phone</label>
                                                            <input type="text" class="form-control custom-input-box"
                                                                   id="schoolUserMobile" name="schoolUserMobile"
                                                                   placeholder="School Phone">
                                                            <span style="color:#DB8C0E">e.g.: +91-XXXXXXXXXX </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="button" id="schooUserProfileUpdateClick" class="btn btn-primary" value="Update"/>
                <button type="button" class="btn btn-default custom-button full-width" data-dismiss="modal">Close
                </button>
            </div>
        </div>

    </div>
</div> 

<!-- Modal -->
<!-- Modal -->
<div class="modal fade" id="viewReviewPostClick" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Post Details</h4>
            </div>
            <div class="modal-body">
                <div>
                    <div class="container">
                        <div class="row">

                            <div class="col-md-6 ">
                                <div class="panel panel-default">
                                    <div class="panel-body">
                                        <div class="row" style="border-bottom: 1px solid #e1d9d9">
                                            <div class="col-md-4">
                                                <span
                                                    style="border:1px solid #555 !important;border-radius:45% !important;padding:6px;"
                                                    class="categoryTitleClassDetails"></span>
                                            </div>
                                            <div class="col-md-8">
                                                <p class="pull-right"><span class="viewDetailsName"></span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <p class="paddingImgPtag" id="viewDetailsImg"
                                                   style="text-align: center;">

                                                </p>
                                                <div style="text-align: center;" id="viewDetailsContent">

                                                    <div class="clearfix"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    </form>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default custom-button full-width" data-dismiss="modal">Close
                </button>
            </div>
        </div>

    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="editParentData" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Update Parent/Child Information</h4>
            </div>
            <div class="modal-body">
                <div>
                    <form name="editTeacherClassSectionForm" id="editTeacherClassSectionForm">

                        <div class="container">
                            <div class="row">
                                <div class="col-md-3">

                                    <div class="row">
                                        <div class="col-md-3">
                                            <img id="parentProfileImage" src='' alt='Parent Image'
                                                 class='img-circle img-responsive'
                                                 style='width:47px;height:47px;margin-top: 9px;'>
                                        </div>
                                        <div class="col-md-9">
                                            <h4 id="madalParentName"></h4>
                                            <h5 id="madalParentEmail"></h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <p><span><b>Contact No. : </b></span> <span id="modalParentContactNumber"></span>
                                    </p>
                                    <p><span><b>Relation : </b></span> <span id="modalParentRelation"
                                                                             style='color:green;'></span></p>

                                </div>
                                <div class="col-md-3">
                                    <p><span><b>Signed On : </b></span> <span id="modalParentSignedOn"></span></p>
                                    <p><span><b>Status : </b></span> <span id="modalParentStatus"><span
                                                style="color:green;">verified</span></span></p>


                                    <!--<div class="form-group">
                                        <label for="exampleFormControlInput1">Teacher Id No.</label>
                                        <input type="text" class="form-control custom-input-box" id="teacherIdNumb"
                                               name="teacherIdNumb" placeholder="Teacher Id Number">
                                        <input type="hidden" class="form-control custom-input-box" id="teacheIds" name="teacheIds">
    
                                    </div>-->
                                </div>
                            </div>
                            <br/>
                            <div id="editParentChildData">


                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default custom-button full-width" data-dismiss="modal">Close
                </button>
                <button type="button" class="btn btn-default custom-button-default full-width updateChildClassSection">
                    Save
                </button>
            </div>
        </div>

    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Edit School Profile</h4>
            </div>
            <div class="modal-body">
                <div>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <form id="registrationForm" name="registrationForm">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label for="exampleFormControlInput1">School Name</label>
                                                <input type="text" class="form-control custom-input-box" id="schoolName"
                                                       name="schoolName" placeholder="School Name" disabled="">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label for="exampleFormControlInput1">School Type</label>
                                                <select class="form-control custom-input-box" id="schoolType"
                                                        name="schoolType" disabled>
                                                    <option value="1" selected>School</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-6">
                                            <div class="form-group">
                                                <label for="exampleFormControlInput1">School URL</label>
                                                <input type="text" class="form-control  custom-input-box" id="schoolURL"
                                                       placeholder="School URL">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-6">
                                            <div class="form-group">
                                                <label for="exampleFormControlInput1">Branch Name</label>
                                                <input type="text" class="form-control  custom-input-box"
                                                       id="branchName" name="branchName" placeholder="Branch Name"
                                                       disabled="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-6">
                                            <div class="form-group">
                                                <label for="exampleFormControlInput1">Country </label>
                                                <select class="form-control custom-input-box" id="country"
                                                        name="country" disabled>
                                                    <option value="" selected>Please Select Country</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-6">
                                            <div class="form-group">
                                                <label for="exampleFormControlInput1">State </label>
                                                <select class="form-control custom-input-box" id="state" id="state">
                                                    <option value="">Please Select State</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-6">
                                            <div class="form-group">
                                                <label for="exampleFormControlInput1">City </label>
                                                <select class="form-control custom-input-box" id="city" id="city">
                                                    <option value="" selected>Please Select City</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-6">
                                            <div class="form-group">
                                                <label for="exampleFormControlInput1">School Address</label>
                                                <input type="text" class="form-control custom-input-box"
                                                       id="schoolAddress" name="schoolAddress"
                                                       placeholder="School Address">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-12">

                                            <label>School Logo</label>

                                            <div class="avatar-upload">
                                                <div class="avatar-edit">
                                                    <input type="hidden" id="schoolHiddenImage"
                                                           name="schoolHiddenImage">
                                                    <input type='file' id="imageUpload" name="schoolLogo"
                                                           accept=".png, .jpg, .jpeg"/>
                                                    <label for="imageUpload"></label>
                                                </div>
                                                <div class="avatar-preview">
                                                    <div id="imagePreview"
                                                         style="background-image: url(images/logo-transparent.png);">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-12">
                                            <div style="margin-top:20px;">
                                                <div class="row">

                                                    <div class="col-md-12 col-sm-12">
                                                        <div class="form-group">

                                                            <label for="exampleFormControlInput1">School Phone</label>
                                                            <input type="text" class="form-control custom-input-box"
                                                                   id="schoolPhone" name="schoolPhone"
                                                                   placeholder="School Phone">
                                                           <!-- <span style="color:#DB8C0E">e.g.: +91-11-XXXXXXX </span>-->
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row">

                                                    <div class="col-md-12 col-sm-6">
                                                        <div class="form-group">
                                                            <label for="exampleFormControlInput1">Mobile Phone</label>
                                                            <input type="text" class="form-control custom-input-box"
                                                                   id="schoolMobile" name="schoolMobile"
                                                                   placeholder="School Mobile">
                                                            <!--<span style="color:#DB8C0E">e.g.: +91-XXXXXXXXXX </span>-->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="button" id="updateSchoolProfileData" class="btn btn-primary" value="Update"/>
                <button type="button" class="btn btn-default custom-button full-width" data-dismiss="modal">Cancel
                </button>
            </div>
        </div>

    </div>
</div>


<!-- *************** Edit Profile Form End Here ************** -->


<!-- Modal -->
<div class="modal fade" id="addGroupModal" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add Group</h4>
            </div>
            <div class="modal-body">
                <div>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <form id="registrationForm" name="registrationForm">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label for="exampleFormControlInput1">Group Name</label>
                                                <input type="text" class="form-control custom-input-box" id="groupName"
                                                       name="groupName" placeholder="Group Name">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <div class="form-group">
                                                <label for="exampleFormControlInput1">Group Member</label>

                                                <select class="form-control custom-input-box" id="demogroupParentName"
                                                        name="demogroupParentName" multiple="multiple">

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer" >
                <input type="button" class="btn btn-primary" id="addGroupSubmit" value="Add Group"/>
                <button type="button" class="btn btn-default custom-button full-width" data-dismiss="modal">Cancel
                </button>
            </div>
        </div>

    </div>
</div>


<!-- *************** Edit Profile Form End Here ************** -->

<!-- =========================
     START CONTCT FORM AREA
============================== -->
<section class="header parallax home-parallax page" id="HOME"
         style="background:none;border-bottom: 1.5px solid #4C99CC;">
    <div class="section_overlay">
        <div class="container">
            <div class="row" style="margin-top: 50px;">
                <div class="col-md-2">
                    <div style="margin:22px 0px -50px 125px"><i style="font-size:24px;z-index:-1;cursor: pointer;"
                                                                class="fa"
                                                                data-toggle="modal" data-target="#myModal">&#xf044;</i>
                    </div>
                    <div class="profile-header-container">
                        <div class="profile-header-img">
                            <img id="topSchoolImage" class="img-circle"
                                 src="http://lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120"
                                 alt="School Image"/>

                        </div>
                    </div>

                </div>

                <div class="col-md-4">
                    <h4 id="topSchoolName" style="color: #3B4E5F !important;padding:10px 0px 0px 0px;"></h4>
                    <h5 id="topBranchName" style="color: #4C99CC !important;"></h5>

                    <!--<span style="padding: 0px 0px 0px 10px;"><button  class="btn btn-primary" style="" >Edit Profile</button></span>-->
                </div>

                <div class="col-md-3">
                    <?php
                    if (isset($_SESSION['userName']) && empty($_SESSION['userName'])) {

                    } else {
                        ?>
                       <!-- <p style="color:red;padding: 15px 0px 0px 10px;">
                            <span>* </span><span>Membership Not Active </span>
                        </p>-->
                        <!--<p style="color:red;padding: 0px 0px 0px 10px;">
                            <span>* </span><span> Membership Not Active</span>
                        </p>-->
                    <?php } ?>

                </div>

                <div class="col-md-3">
                    <div class="panel panel-default" style="margin-top:15px;">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-xs-12 col-sm-4 text-center">
                                    <div style="margin:-5px 0px -25px 58px;">
                                        <i style="font-size:15px;z-index:-1;cursor: pointer;" class="fa"
                                           id="editProfileClick">&#xf044;</i>
                                    </div>
                                    <img id="userProfileImage" style="height: 50px;width: 50px;overflow: hidden;border: 1px solid #c3c3c3;" src="http://localhost/talking_classes_staging/assets/user_images/users/user-defaul-image.png"
                                         alt=""
                                         class="center-block img-circle img-responsive">
                                    <!--<ul class="list-inline ratings text-center" title="Ratings">
                                      <li><a href="#"><span class="fa fa-star fa-lg"></span></a></li>
                                      <li><a href="#"><span class="fa fa-star fa-lg"></span></a></li>
                                      <li><a href="#"><span class="fa fa-star fa-lg"></span></a></li>
                                      <li><a href="#"><span class="fa fa-star fa-lg"></span></a></li>
                                      <li><a href="#"><span class="fa fa-star fa-lg"></span></a></li>
                                    </ul>-->
                                </div><!--/col-->
                                <div class="col-xs-12 col-sm-8">
                                    <!--<a href="logout.php" style="float: right;color:#000000;" title="Logout"><i style="font-size:15px;z-index:-1" class="fa">&#xf08b;</i></a>-->
                                    <a href="logout.php" style="float: right;color:#000000;margin-top: -6px;" title="Logout"><i class="fa fa-power-off" style="font-size:20px"></i></a>
                                    <h4 style="padding:0px 0px 0px 0px;display: inline-block;font-size: 14px;margin-left: -10px;"
                                        id="guestUsername"><?php if (isset($_SESSION['userName']) && !empty($_SESSION['userName'])) {
                                            echo $_SESSION['userName'];
                                        } else {
                                            echo "Guest User";
                                        } ?> &nbsp; </h4>
                                    
                                </div><!--/col-->
                                <div class="clearfix"></div>

                            </div><!--/row-->
                        </div><!--/panel-body-->
                    </div><!--/panel-->
                </div>
            </div>
            <!--<center><hr width="100%" style="border:1px solid  #4C99CC ;" /></center>-->

            <div class="row">
                <div class="col-md-12 wow bounceIn">
                    <!-- Start Contact Section Title-->

                    <center>
                        <div id="taw">
                            <a class="dgdd6c VM9Z5b btnAct" href="#" id="defaultOpen"
                               onclick="openTab(event, 'NoticeBoard')">
                                <div class="Mw2I7 btnActive"><span class="dtviD">Notice Board</span></div>
                            </a>
                            <a class="dgdd6c VM9Z5b btnAct" href="#" onclick="openTab(event, 'Myclass')">
                                <div class="Mw2I7"><span class="dtviD">My Classes</span></div>
                            </a>
                            <a class="dgdd6c VM9Z5b btnAct" href="#" onclick="openTab(event, 'VerifyTeacher')">
                                <div class="Mw2I7"><span class="dtviD">Teachers List</span></div>
                            </a>
                            <a class="dgdd6c VM9Z5b btnAct" href="#" onclick="openTab(event, 'Message')">
                                <div class="Mw2I7"><span class="dtviD">Messages</span></div>
                            </a>
                            <a class="dgdd6c VM9Z5b btnAct" href="#" onclick="openTab(event, 'ParentList')">
                                <div class="Mw2I7"><span class="dtviD">Parent List</span></div>
                            </a>
                            <a class="dgdd6c VM9Z5b btnAct" href="#" onclick="openTab(event, 'ReviewPost')">
                                <div class="Mw2I7"><span class="dtviD">Review Posts</span></div>
                            </a>
                            <a class="dgdd6c VM9Z5b btnAct" href="#" onclick="openTab(event, 'Setting')">
                                <div class="Mw2I7"><span class="dtviD">Settings</span></div>
                            </a>
                            <a class="dgdd6c VM9Z5b btnAct" href="#" onclick="openTab(event, 'Gallery')">
                                <div class="Mw2I7"><span class="dtviD">Gallery</span></div>
                            </a>
                        </div>
                    </center>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- END CONTACT -->

<section class="header parallax home-parallax page" id="HOME" style="background:none;border-bottom: 2px solid #4C99CC;">
    <div class="section_overlay">
        <div class="container">
            <div class="row" style="margin-bottom:200px;">
                <div class="col-md-12">
                    <div id="NoticeBoard" class="tabcontent">

                        <div id="taw">
                            <a class="dgdd6c VM9Z5b btnActiveNBClick" href="#" id="defaultOpenNB"
                               onclick="openNB(event, 'View')">
                                <div class="Mw2I7 btnActiveNB"><span class="dtviD">View</span></div>
                            </a>
                            <a class="dgdd6c VM9Z5b btnActiveNBClick" href="#" onclick="openNB(event, 'Post')">
                                <div class="Mw2I7"><span class="dtviD">Post</span></div>
                            </a>

                        </div>
                        <div id="View" class="tabcontentNB">
                            <table class="myTable">
                                <thead style="font-size: 16px;padding:0px 10px;">
                                <th style="background-color: #F39C12;color:#ffffff;font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif">Content</th>
                                <th style="background-color: #F39C12;color:#ffffff;font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif">Category</th>
                                <th style="background-color: #F39C12;color:#ffffff;font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif">Post For</th>
                                <th style="background-color: #F39C12;color:#ffffff;font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif">Posted Date</th>
                                <th style="background-color: #F39C12;color:#ffffff;font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif">Image</th>
                                <th style="background-color: #F39C12;color:#ffffff;font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif">Pdf</th>
                                <th style="background-color: #F39C12;color:#ffffff;font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif">Action</th>
                                </thead>
                                <tbody class="postslist">

                                </tbody>
                            </table>
                        </div>

                        <div id="Post" class="tabcontentNB">
                            <div class="row">
                                <div class="col-lg-8"  style="background-color:#FFF;padding: 10px;">
                                    <div style="padding: 10px 0px;">
                                        <select class="form-control select-post-category">

                                        </select>
                                    </div>
                                    <div><textarea class="form-control edit_postcontent" name="edit_postcontent" placeholder="Post Content"></textarea></div>

                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div style="padding:10px 0px;font-size:14px;font-weight: bold;">Post For :
                                            </div>
                                            <ul type="none">
                                                <li><input type="radio" value="school" class="postparam" name="postparam" checked>&nbsp;&nbsp;&nbsp;Entire school
                                                </li>
                                                <li><input type="radio" value="class" class="postparam" name="postparam">&nbsp;&nbsp;&nbsp;Selected Class, Section
                                                </li>
                                                <li><input type="radio" value="custom" class="postparam" name="postparam">&nbsp;&nbsp;&nbsp;For particular user
                                                </li>
                                                <li><input type="radio" value="teacher" class="postparam" name="postparam">&nbsp;&nbsp;&nbsp;For Teacher
                                                </li>
                                                <li><input type="radio" value="parent" class="postparam" name="postparam">&nbsp;&nbsp;&nbsp;For Parent
                                                </li>
                                            </ul>
                                            <div style="padding:10px 0px;font-size:14px;font-weight: bold;">Select file
                                                to upload :
                                            </div>
                                            <ul type="none">
                                                <li>
                                                    <input type="radio" class="postfiletype" value="nofile" name="postfiletype" checked>&nbsp;&nbsp;Post without image
                                                </li>
                                                <li>
                                                    <input type="radio" class="postfiletype" value="image"  name="postfiletype">&nbsp;&nbsp;Select image for post
                                                </li>
                                                <li>
                                                    <input type="radio" class="postfiletype" value="pdf" name="postfiletype">&nbsp;&nbsp;Select PDF file for post
                                                </li>
                                            </ul>

                                            <div style="padding:10px;">
                                                <center>
                                                    <div class="btn btn-default post-noticeboard">Post on Noticeboard</div>
                                                </center>
                                            </div>
                                        </div>

                                        <div class="col-lg-8">
                                            <div class="classparam-container"
                                                 style="display:none;margin-top:20px;background-color:#FFF;border:1px solid #c3c3c3;padding: 10px;">
                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <div>
                                                            Select Class
                                                        </div>
                                                        <div>
                                                            <select class="form-control post-preview-selectclass">
                                                                <?php
                                                                for($dataCntr = 0;$dataCntr < sizeof($app_school_classes); $dataCntr++) {
                                                                    echo "<option>".$app_school_classes[$dataCntr]->item_name."</option>";
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <div>
                                                            Select Section
                                                        </div>
                                                        <div>
                                                            <select class="form-control post-preview-sections">
                                                                <?php
                                                                for($dataCntr = 0;$dataCntr < sizeof($app_school_class_sections); $dataCntr++) {
                                                                    echo "<option>".$app_school_class_sections[$dataCntr]->item_name."</option>";
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="searchparam-container" style="display:none;margin-top:20px;background-color:#FFF;border:1px solid #c3c3c3;padding: 10px;">
                                                <center><input type="text" placeholder="Enter email or name to search" class="form-control post-preview-customsearch"/></center>
                                            </div>
                                            <div class="teacherparam-container" style="display:none;margin-top:20px;background-color:#FFF;border:1px solid #c3c3c3;padding: 10px;">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <ul type="none">
                                                            <li style="display: inline-block;vertical-align: middle"><input type="radio" value="allteacher" class="teacherpostparam" name="teacherpostparam" checked>&nbsp;&nbsp;&nbsp;All Teachers</li>
                                                            <li style="display: inline-block;vertical-align: middle">&nbsp;&nbsp;&nbsp;<input type="radio" value="selectedteacher" class="teacherpostparam" name="teacherpostparam">&nbsp;&nbsp;&nbsp;Selected Teacher</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="row teachernameparam-container" style="display: none;">
                                                    <div class="col-lg-12">
                                                        <div>
                                                            <center><input type="text" placeholder="Enter email to search" class="form-control post-nb-teachername"/></center>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="parentparam-container" style="display:none;margin-top:20px;background-color:#FFF;border:1px solid #c3c3c3;padding: 10px;">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <ul type="none">
                                                            <li style="display: inline-block;vertical-align: middle"><input type="radio" value="allparent" class="parentpostparam" name="parentpostparam" checked>&nbsp;&nbsp;&nbsp;All Parents</li>
                                                            <li style="display: inline-block;vertical-align: middle">&nbsp;&nbsp;&nbsp;<input type="radio" value="selectedparent" class="parentpostparam" name="parentpostparam">&nbsp;&nbsp;&nbsp;Selected Parents</li>
                                                        </ul>
                                                    </div>
                                                </div>

                                                <div class="row parentnameparam-container" style="display: none;">
                                                    <div class="col-lg-12">
                                                        <div>
                                                            <center><input type="text" placeholder="Enter email to search" class="form-control post-nb-parentname"/></center>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                    </div>
                                    <div>

                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div>Post Preview</div><br/>
                                    <div style="border:1px solid #d1d1d1;padding:10px;border-radius:4px;">
                                        <div style="background-color:#FFF;padding:10px;word-wrap: break-word;">
                                            <div>
                                            <span class="postview_category"
                                                  style="padding:4px 5px;border:1px solid #c3c3c3;border-radius:4px;">General</span>
                                            </div>
                                            <center>
                                                <div class="postimagecontainer" style="display: none;padding-top:20px;"><img class="postthumb_image" src="" alt=""  style="width:200px;height:200px;margin: auto auto;">
                                                </div>
                                            </center>
                                            <div style="padding: 10px 0px;">
                                                <div class="postview_content"></div>
                                            </div>
                                            <div style="padding: 10px 0px;">
                                                <div class="postview_username">Guest User</div>
                                            </div>
                                        </div>
                                    </div>

                                    <div>
                                        <center>
                                            <div style="margin-top:10px;width:200px;display: none;"
                                                 class="uploadimagecontainer">
                                                <input type="file" class="filepostimage"
                                                       style="position: absolute;width: 200px;opacity:0;height: 35px;cursor: pointer;"
                                                       name="">
                                                <div class="btn btn-pirmary"
                                                     style="border:1px solid #c3c3c3;width:200px;">Select Image to
                                                    upload
                                                </div>
                                            </div>
                                            <div style="margin-top:10px;width:200px;display:none;"
                                                 class="uploadpdfcontainer">
                                                <input type="file" class="filepostpdf"
                                                       style="position: absolute;width: 200px;opacity:0;height: 35px;cursor: pointer;"
                                                       name="">
                                                <div class="btn btn-pirmary"
                                                     style="border:1px solid #c3c3c3;width:200px;">Select PDF to upload
                                                </div>
                                            </div>
                                        </center>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
					
					<div id="Myclass" class="tabcontent">
						<div class="container">
							<div> My class </div>
						</div>
					</div>
					
                    <div id="VerifyTeacher" class="tabcontent">

                        <div id="taw">
                            <div style="float:left;">
                                <a class="dgdd6c VM9Z5b btnActiveVTClick " href="#" id="defaultOpenVT"
                                   onclick="openVT(event, 'AllTeacherList')">
                                    <div class="Mw2I7 btnActiveVT"><span class="dtviD">All </span></div>
                                </a>
                                <a class="dgdd6c VM9Z5b btnActiveVTClick " href="#"
                                   onclick="openVT(event, 'unVerifiedList')">
                                    <div class="Mw2I7"><span class="dtviD">Unverified</span></div>
                                </a>
                                <a class="dgdd6c VM9Z5b btnActiveVTClick" href="#"
                                   onclick="openVT(event, 'verifiedList')">
                                    <div class="Mw2I7"><span class="dtviD">Verified</span></div>
                                </a>
                                <a class="dgdd6c VM9Z5b btnActiveVTClick" href="#"
                                   onclick="openVT(event, 'inactiveTeacher')">
                                    <div class="Mw2I7"><span class="dtviD">Inactive Teacher</span></div>
                                </a>
                                <a class="dgdd6c VM9Z5b btnActiveVTClick" href="#"
                                   onclick="openVT(event, 'addTeacher')">
                                    <div class="Mw2I7"><span class="dtviD">Add Teacher</span></div>
                                </a>
                            </div>
                            <div style="float:right;">
                                <input type="text" class="myInput teacherListSearch" placeholder="Search......." title="Type in a name">
                            </div>
                        </div>

                        <div id="AllTeacherList" class="tabcontentVT">

                            <table class="teacherTable" >
								<thead>
									<tr class="header">
										<th style="width:8%;" class="table-header-background">Image</th>
										<th style="width:25%;" class="table-header-background">Name</th>
										<th style="width:25%;" class="table-header-background">Email</th>
										<th style="width:15%;" class="table-header-background">Phone</th>
										<!--<th style="width:7%;" class="table-header-background">Class</th>
										<th style="width:7%;" class="table-header-background">Section</th>
										<th style="width:17%;" class="table-header-background">Subject</th>-->
										<th style="width:12%;" class="table-header-background">Status</th>
										<th style="width:15%;" class="table-header-background">Action</th>
									</tr>
								</thead>
								<tbody id="allTeacherRow">
					
								</tbody>
                            </table>
                        </div>
                        <div id="unVerifiedList" class="tabcontentVT">

                            <table class="teacherTable">
								<thead>
									<tr class="header">
										<th style="width:8%;" class="table-header-background">Image</th>
										<th style="width:25%;" class="table-header-background">Name</th>
										<th style="width:25%;" class="table-header-background">Email</th>
										<th style="width:15%;" class="table-header-background">Phone</th>
										<!--<th style="width:7%;" class="table-header-background">Class</th>
										<th style="width:7%;" class="table-header-background">Section</th>
										<th style="width:17%;" class="table-header-background">Subject</th>-->
										<th style="width:12%;" class="table-header-background">Status</th>
										<th style="width:15%;" class="table-header-background">Action</th>
									</tr>
								</thead>
								<tbody id="allTeacherRowUnverified">
								</tbody>
                            </table>
							
                        </div>
                        <div id="verifiedList" class="tabcontentVT">

                            <table class="teacherTable" >
								<thead>
									<tr>
										<th style="width:8%;" class="table-header-background">Image</th>
										<th style="width:25%;" class="table-header-background">Name</th>
										<th style="width:25%;" class="table-header-background">Email</th>
										<th style="width:15%;" class="table-header-background">Phone</th>
										<!--<th style="width:7%;" class="table-header-background">Class</th>
										<th style="width:7%;" class="table-header-background">Section</th>
										<th style="width:17%;" class="table-header-background">Subject</th>-->
										<th style="width:12%;" class="table-header-background">Status</th>
										<th style="width:15%;" class="table-header-background">Action</th>
									</tr>
								</thead>
								<tbody id="allTeacherRowVerified">

								</tbody>
                            </table>
                        </div>

                        <div id="inactiveTeacher" class="tabcontentVT">

                           <table class="teacherTable" >
								<thead>	
									<tr>                                
										<th style="width:8%;" class="table-header-background">Image</th>
										<th style="width:25%;" class="table-header-background">Name</th>
										<th style="width:25%;" class="table-header-background">Email</th>
										<th style="width:15%;" class="table-header-background">Phone</th>
										<!--<th style="width:7%;" class="table-header-background">Class</th>
										<th style="width:7%;" class="table-header-background">Section</th>
										<th style="width:17%;" class="table-header-background">Subject</th>-->
										<th style="width:12%;" class="table-header-background">Status</th>
										<th style="width:15%;" class="table-header-background">Action</th>
									</tr>
								</thead>
								<tbody id="allTeacherRowInactive">
								</tbody>
                            </table>
                        </div>

                        <div id="addTeacher" class="tabcontentVT container">

                            <?php /* <div class="row">
                                <div class="col-md-12">

                                    <form id="registrationForm" name="registrationForm">
                                        <div class="row">

                                            <div class="col-md-4 col-sm-6">
                                                <div class="form-group">
                                                    <label for="exampleFormControlInput1">Class</label>
                                                    <select class="form-control custom-input-box" id="schoolType"
                                                            name="schoolType">
                                                        <option value="1" selected="">School</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="form-group">
                                                    <label for="exampleFormControlInput1">Section</label>
                                                    <input class="form-control  custom-input-box" id="schoolURL"
                                                           placeholder="School URL" type="text">
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="form-group">
                                                    <label for="exampleFormControlInput1">Branch Name</label>
                                                    <input class="form-control  custom-input-box" id="branchName"
                                                           name="branchName" placeholder="Branch Name" type="text">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">

                                            <div class="col-md-4 col-sm-6">
                                                <div class="form-group">
                                                    <label for="exampleFormControlInput1">Country </label>
                                                    <select class="form-control custom-input-box" id="country"
                                                            name="country">
                                                        <option value="1" selected="">India</option>
                                                        <option value="2">USA</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="form-group">
                                                    <label for="exampleFormControlInput1">State </label>
                                                    <select class="form-control custom-input-box" id="state">
                                                        <option value="1" selected="">Delhi</option>
                                                        <option value="2">Bihar</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="form-group">
                                                    <label for="exampleFormControlInput1">City </label>
                                                    <input class="form-control custom-input-box" id="city" name="city"
                                                           placeholder="City Name" type="text">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">

                                            <div class="col-md-12 col-sm-12">
                                                <div class="form-group">
                                                    <label for="exampleFormControlInput1">Address</label>
                                                    <input class="form-control custom-input-box" id="schoolAddress"
                                                           name="schoolAddress" placeholder="School Address"
                                                           type="text">
                                                </div>
                                            </div>

                                        </div>

                                        <div class="panel panel-default">

                                            <div class="panel-heading">Teacher</div>
                                            <div class="panel-body">

                                                <div class="row">
                                                    <div class="col-md-4 col-sm-6">
                                                        <div class="form-group">
                                                            <label for="exampleFormControlInput1">Name</label>
                                                            <input class="form-control custom-input-box"
                                                                   id="principleName" name="principleName"
                                                                   placeholder="Name" type="text">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 col-sm-6">
                                                        <div class="form-group">
                                                            <label for="exampleFormControlInput1"> Email</label>
                                                            <input class="form-control  custom-input-box"
                                                                   id="principleEmail" name="principleEmail"
                                                                   placeholder="Email" type="text">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 col-sm-6">
                                                        <div class="form-group">
                                                            <label for="exampleFormControlInput1">Password</label>
                                                            <input class="form-control  custom-input-box"
                                                                   id="principlePassword" name="principlePassword"
                                                                   placeholder="Password" type="text">
                                                        </div>
                                                    </div>
                                                </div>


                                                <div class="clearfix"></div>
                                            </div>

                                        </div>

                                        <div class="row">
                                            <div class="col-md-12 col-sm-6">
                                                <!--<div class="checkbox">
                                                    <label>
                                                        <input name="userTermsAgreement" id="userTermsAgreement" value="agree" type="checkbox">   I have read and understood the <a href="#" style="color:#427DBD;">terms and condition </a>and agree to it.
                                                    </label>
                                                </div>-->
                                                <!-- TITLE AND DESC -->

                                                <div style="padding-top: 10px;">
                                                    <div style="display: inline-block;vertical-align: middle;width: 100%;">
                                                        <input class="btn home-btn custom-button full-width"
                                                               value="Submit" type="button">
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div> */ ?>
                        </div>
                    </div>

                    <div id="Message" class="tabcontent">

                        <div id="taw">
                            <!--<a class="dgdd6c VM9Z5b btnActiveMessageClick" href="#" id="defaultOpenMessage"
                               onclick="openMessage(event, 'MessageAll')">
                                <div class="Mw2I7 btnActiveMessage"><span class="dtviD">All</span></div>
                            </a>
                            <a class="dgdd6c VM9Z5b btnActiveMessageClick" href="#"
                               onclick="openMessage(event, 'MessageNew')">
                                <div class="Mw2I7"><span class="dtviD">New</span></div>
                            </a>-->

                        </div>
                        <div id="MessageAll" class="tabcontentMessage">
                            <br/>
                            <div id="frame">
                                <div id="sidepanel">
                                    <div id="profile">
                                        <div class="wrap">
                                            <img id="profile-img" src="http://emilcarlsson.se/assets/mikeross.png"
                                                 style="border-color: transparent;" alt=""/>
                                            <p>Mike Ross</p>
                                            <i class="fa fa-chevron-down expand-button" aria-hidden="true"
                                               style="display: none;"> </i>
                                            <div id="status-options">
                                                <ul>
                                                    <li id="status-online" class="active"><span
                                                            class="status-circle"></span>
                                                        <p>Online</p></li>
                                                    <li id="status-away"><span class="status-circle"></span>
                                                        <p>Away</p></li>
                                                    <li id="status-busy"><span class="status-circle"></span>
                                                        <p>Busy</p></li>
                                                    <li id="status-offline"><span class="status-circle"></span>
                                                        <p>Offline</p></li>
                                                </ul>
                                            </div>
                                            <div id="expanded">
                                                <label for="twitter"><i class="fa fa-facebook fa-fw"
                                                                        aria-hidden="true"></i></label>
                                                <input name="twitter" type="text" value="mikeross"/>
                                                <label for="twitter"><i class="fa fa-twitter fa-fw"
                                                                        aria-hidden="true"></i></label>
                                                <input name="twitter" type="text" value="ross81"/>
                                                <label for="twitter"><i class="fa fa-instagram fa-fw"
                                                                        aria-hidden="true"></i></label>
                                                <input name="twitter" type="text" value="mike.ross"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="search">
                                        <label for=""><i class="fa fa-search" aria-hidden="true"></i></label>
                                        <input id="contactsearch" type="text" placeholder="Search contacts..."/>
                                    </div>
                                    <div id="contacts">
                                        <ul id="allContactList">


                                            <!--<li class="contact active">
                                                 <div class="wrap">
                                                     <span class="contact-status away"></span>
                                                     <img src="http://emilcarlsson.se/assets/rachelzane.png" alt="" />
                                                     <div class="meta">
                                                         <p class="name">Rachel Zane</p>
                                                         <p class="preview">I was thinking that we could have chicken tonight, sounds good?</p>
                                                     </div>
                                                 </div>
                                             </li>
                                              <li class="contact">
                                                 <div class="wrap">
                                                     <span class="contact-status online"></span>
                                                     <img src="http://emilcarlsson.se/assets/donnapaulsen.png" alt="" />
                                                     <div class="meta">
                                                         <p class="name">Donna Paulsen</p>
                                                         <p class="preview">Mike, I know everything! I'm Donna..</p>
                                                     </div>
                                                 </div>
                                             </li>
                                             <li class="contact">
                                                 <div class="wrap">
                                                     <span class="contact-status busy"></span>
                                                     <img src="http://emilcarlsson.se/assets/jessicapearson.png" alt="" />
                                                     <div class="meta">
                                                         <p class="name">Jessica Pearson</p>
                                                         <p class="preview">Have you finished the draft on the Hinsenburg deal?</p>
                                                     </div>
                                                 </div>
                                             </li>
                                             <li class="contact">
                                                 <div class="wrap">
                                                     <span class="contact-status"></span>
                                                     <img src="http://emilcarlsson.se/assets/haroldgunderson.png" alt="" />
                                                     <div class="meta">
                                                         <p class="name">Harold Gunderson</p>
                                                         <p class="preview">Thanks Mike! :)</p>
                                                     </div>
                                                 </div>
                                             </li>
                                             <li class="contact">
                                                 <div class="wrap">
                                                     <span class="contact-status"></span>
                                                     <img src="http://emilcarlsson.se/assets/danielhardman.png" alt="" />
                                                     <div class="meta">
                                                         <p class="name">Daniel Hardman</p>
                                                         <p class="preview">We'll meet again, Mike. Tell Jessica I said 'Hi'.</p>
                                                     </div>
                                                 </div>
                                             </li>
                                             <li class="contact">
                                                 <div class="wrap">
                                                     <span class="contact-status busy"></span>
                                                     <img src="http://emilcarlsson.se/assets/katrinabennett.png" alt="" />
                                                     <div class="meta">
                                                         <p class="name">Katrina Bennett</p>
                                                         <p class="preview">I've sent you the files for the Garrett trial.</p>
                                                     </div>
                                                 </div>
                                             </li>
                                             <li class="contact">
                                                 <div class="wrap">
                                                     <span class="contact-status"></span>
                                                     <img src="http://emilcarlsson.se/assets/charlesforstman.png" alt="" />
                                                     <div class="meta">
                                                         <p class="name">Charles Forstman</p>
                                                         <p class="preview">Mike, this isn't over.</p>
                                                     </div>
                                                 </div>
                                             </li>
                                             <li class="contact">
                                                 <div class="wrap">
                                                     <span class="contact-status"></span>
                                                     <img src="http://emilcarlsson.se/assets/jonathansidwell.png" alt="" />
                                                     <div class="meta">
                                                         <p class="name">Jonathan Sidwell</p>
                                                         <p class="preview"><span>You:</span> That's bullshit. This deal is solid.</p>
                                                     </div>
                                                 </div>
                                             </li>-->
                                        </ul>
                                    </div>
                                    <div id="bottom-bar">
                                        <button id="addGroupContact"><i class="fa fa-user" aria-hidden="true"></i>
                                            <span>Add Group</span></button>
                                        <!--<button id="settings"><i class="fa fa-cog fa-fw" aria-hidden="true"></i> <span>Settings</span>
                                        </button>-->
                                    </div>
                                </div>
                                <div class="content">
                                    <div class="contact-profile" style="display:none;">
                                        <img id="clickmessageProfileSrc"
                                             src="http://emilcarlsson.se/assets/harveyspecter.png" alt=""/>
                                        <p id="clickmessageProfileName">Harvey Specter</p>
                                        <!--<div class="social-media">
                                            <i class="fa fa-facebook" aria-hidden="true"></i>
                                            <i class="fa fa-twitter" aria-hidden="true"></i>
                                            <i class="fa fa-instagram" aria-hidden="true"></i>
                                        </div>-->
                                    </div>
                                    <div class="messages">
                                        <ul id="chatMessageCommunication">
                                            <center><h4 style="line-height: 400px;vertical-align: middle"> Please select member to start conversation </h4></center>
                                        </ul>
                                    </div>
                                    <div class="message-input" style="display:none;">
                                        <div class="wrap">
                                            <input type="text" placeholder="Write your message..."/>
                                            <i class="fa fa-paperclip attachment" aria-hidden="true"></i>
                                            <button class="submit"><i class="fa fa-paper-plane" aria-hidden="true"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div id="MessageNew" class="tabcontentMessage">
                            <!--<h3>New</h3>
                            <p>Post Content</p> -->
                        </div>

                    </div>

                    <div id="ParentList" class="tabcontent">

                        <div id="taw">
                            <div style="float:left;">
                                <a class="dgdd6c VM9Z5b btnActivePLClick" href="#" id="defaultOpenPL"
                                   onclick="openPL(event, 'PLAll')">
                                    <div class="Mw2I7 btnActivePL"><span class="dtviD">All</span></div>
                                </a>
                                <a class="dgdd6c VM9Z5b btnActivePLClick" href="#"
                                   onclick="openPL(event, 'PLUnverified')">
                                    <div class="Mw2I7"><span class="dtviD">Unverified</span></div>
                                </a>
                                <a class="dgdd6c VM9Z5b btnActivePLClick" href="#"
                                   onclick="openPL(event, 'PLVerified')">
                                    <div class="Mw2I7"><span class="dtviD">Verified</span></div>
                                </a>
                                <a class="dgdd6c VM9Z5b btnActivePLClick" href="#" onclick="openPL(event, 'AddParent')">
                                    <div class="Mw2I7"><span class="dtviD">Add Parent</span></div>
                                </a>
                            </div>

                            <div style="float:right;">
                                <input type="text" class="myInput parentListSearch" placeholder="Search......." title="Type in a name">
                            </div>
                        </div>
                        <div id="PLAll" class="tabcontentPL">
                            <table class="parentTable" >
								<thead>
									<tr class="header">
										<th style="width:8%;" class="table-header-background">Image</th>
										<th style="width:15%;" class="table-header-background">Name</th>
										<th style="width:15%;" class="table-header-background">No. Of Child</th>
										<th style="width:15%;" class="table-header-background">Signed On</th>
										<th style="width:15%;" class="table-header-background">Status</th>
										<th style="width:12%;" class="table-header-background">Relation</th>
										<th style="width:15%;" class="table-header-background">Action</th>
									</tr>
								</thead>
								<tbody id="allParentRow">
								
								</tbody>
                            </table>
                        </div>
                        <div id="PLUnverified" class="tabcontentPL">
                            <table class="parentTable" >
                                </thead>
									<tr class="header">
										<th style="width:8%;" class="table-header-background">Image</th>
										<th style="width:15%;" class="table-header-background">Name</th>
										<th style="width:15%;" class="table-header-background">No. Of Child</th>
										<th style="width:15%;" class="table-header-background">Signed On</th>
										<th style="width:15%;" class="table-header-background">Status</th>
										<th style="width:12%;" class="table-header-background">Relation</th>
										<th style="width:15%;" class="table-header-background">Action</th>
									</tr>
									
								</thead>
								<tbody id="allParentRowUnverified">
								
								</tbody>
                            </table>
                        </div>
                        <div id="PLVerified" class="tabcontentPL">
                            <table class="parentTable">
                                <thead>
									<tr class="header">
										<th style="width:8%;" class="table-header-background">Image</th>
										<th style="width:15%;" class="table-header-background">Name</th>
										<th style="width:15%;" class="table-header-background">No. Of Child</th>
										<th style="width:15%;" class="table-header-background">Signed On</th>
										<th style="width:15%;" class="table-header-background">Status</th>
										<th style="width:12%;" class="table-header-background">Relation</th>
										<th style="width:15%;" class="table-header-background">Action</th>
									</tr>
									
								</thead>
								<tbody id="allParentRowVerified">
								
								</tbody>
                            </table>
                        </div>
                        <div id="AddParent" class="tabcontentPL">
                            <!--<h3>Add Parent</h3>
                            <p>Post Content</p> -->
                        </div>
                    </div>

                    <div id="ReviewPost" class="tabcontent">

                        <div id="taw">


                            <div style="float:left;">

                                <a class="dgdd6c VM9Z5b btnActiveRPClick" href="#" id="defaultOpenRP"
                                   onclick="openRP(event, 'AllPost')">
                                    <div class="Mw2I7 btnActiveRP"><span class="dtviD">All</span></div>
                                </a>
                                <a class="dgdd6c VM9Z5b btnActiveRPClick" href="#"
                                   onclick="openRP(event, 'blockedReviewPost')">
                                    <div class="Mw2I7 "><span class="dtviD">Blocked</span></div>
                                </a>

                            </div>

                            <div style="float:right;padding: 8px;">
                                <input type="text" class="myInput" id="teacherSearchInput" placeholder="Search By Teacher" title="Search By Teacher">
                                <input type="text" class="myInput" id="parentSearchInput" placeholder="Search By Parent" title="Search By Parent">
                                <input type="text" class="myInput" id="categorySearchInput" placeholder="Search By Category" title="Search By Category">
                                <!--<input type="text" class="myInput" id="dp6" data-date="12-02-2012"
                                       data-date-format="dd-mm-yyyy" onkeyup="myFunction()" placeholder="Search By Date"
                                       title="Search By Date">-->
                            </div>

                        </div>
                        <div class="clearfix"></div>
                        <div id="AllPost" class="tabcontentRP">

                            <div class="container">
                                <div class="row" id="reviewvPostContentDiv">

                                    <!--<div class="col-md-3 col-sm-6">
                                      <div class="serviceBox">
                                          <div class="service-content">
                                              <div><span style="float: left;border: 1px solid #5DBFE9;border-radius: 25%;padding: 5px;">Generalsss</span><span style="float: right;border: 1px solid #5DBFE9;border-radius: 25%;padding: 5px;">Block</span></div>
                                              <h3 class="title">Vikash Kashyap</h3>
                                            <div class="service-icon">
                                                <image src="images/anupam.jpg" style="width: 200px;" />
                                            </div>
                                              
                                              <p class="description">
                                                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui quaerat fugit quas veniam perferendis repudiandae sequi, dolore quisquam illum.
                                              </p>
                                          </div>
                                          <a class="read-more" href="">Read More</a>
                                      </div>
                                    </div>
                                      <div class="col-md-3 col-sm-6">
                                          <div class="serviceBox">
                                              <div class="service-content">
                                                  <div><span style="float: left;border: 1px solid #5DBFE9;border-radius: 25%;padding: 5px;">Generalsss</span><span style="float: right;border: 1px solid #5DBFE9;border-radius: 25%;padding: 5px;">Block</span></div>
                                                  <h3 class="title">Vikash Kashyap</h3>
                                                <div class="service-icon">
                                                    <image src="images/anupam.jpg" style="width: 200px;" />
                                                </div>
                                                  
                                                  <p class="description">
                                                      Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui quaerat fugit quas veniam perferendis repudiandae sequi, dolore quisquam illum.
                                                  </p>
                                              </div>
                                              <a class="read-more" href="">Read More</a>
                                          </div>
                                      </div>
                                      <div class="col-md-3 col-sm-6">
                                          <div class="serviceBox">
                                              <div class="service-content">
                                                  <div><span style="float: left;border: 1px solid #5DBFE9;border-radius: 25%;padding: 5px;">Generalsss</span><span style="float: right;border: 1px solid #5DBFE9;border-radius: 25%;padding: 5px;">Block</span></div>
                                                  <h3 class="title">Vikash Kashyap</h3>
                                                <div class="service-icon">
                                                    <image src="images/anupam.jpg" style="width: 200px;" />
                                                </div>
                                                  
                                                  <p class="description">
                                                      Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui quaerat fugit quas veniam perferendis repudiandae sequi, dolore quisquam illum.
                                                  </p>
                                              </div>
                                              <a class="read-more" href="">Read More</a>
                                          </div>
                                      </div>
                                      <div class="col-md-3 col-sm-6">
                                          <div class="serviceBox">
                                              <div class="service-content">
                                                  <div><span style="float: left;border: 1px solid #5DBFE9;border-radius: 25%;padding: 5px;">Generalsss</span><span style="float: right;border: 1px solid #5DBFE9;border-radius: 25%;padding: 5px;">Block</span></div>
                                                  <h3 class="title">Vikash Kashyap</h3>
                                                <div class="service-icon">
                                                    <image src="images/anupam.jpg" style="width: 200px;" />
                                                </div>
                                                  
                                                  <p class="description">
                                                      Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui quaerat fugit quas veniam perferendis repudiandae sequi, dolore quisquam illum.
                                                  </p>
                                              </div>
                                              <a class="read-more" href="">Read More</a>
                                          </div>
                                      </div>
                                      <div class="col-md-3 col-sm-6">
                                          <div class="serviceBox">
                                              <div class="service-content">
                                                <div class="service-icon">
                                                    <i class="fa fa-globe"></i>
                                                </div>
                                                  <h3 class="title">Web Design</h3>
                                                  <p class="description">
                                                      Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui quaerat fugit quas veniam perferendis repudiandae sequi, dolore quisquam illum.
                                                  </p>
                                              </div>
                                              <a class="read-more" href="">Read More</a>
                                          </div>
                                      </div>
                                      <div class="col-md-3 col-sm-6">
                                        <div class="serviceBox green">
                                            <div class="service-content">
                                              <div class="service-icon">
                                                  <i class="fa fa-users"></i>
                                              </div>
                                                <h3 class="title">Web Development</h3>
                                                <p class="description">
                                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui quaerat fugit quas veniam perferendis repudiandae sequi, dolore quisquam illum.
                                                </p>
                                            </div>
                                            <a class="read-more" href="">Read More</a>
                                        </div>
                                      </div>
                                  </div>-->


                                </div>

                                <style>
                                    .reviewPostImg {
                                        width: 100%;
                                        border: 2px solid #F39C12;
                                        border-radius: 10px;
                                        overflow: hidden;
                                    }

                                    .paddingImgPtag {
                                        padding: 10px;
                                    }
                                </style>
                            </div>
                            

                        </div>

						<div id="blockedReviewPost" class="tabcontentRP">
							<div class="container">
								<div class="row" id="reviewvPostContentDivBlock">
								
								</div>
							</div>
                        </div>
							
                    </div>

                    <div id="Setting" class="tabcontent">
                        <div id="taw">
                            <!--<a class="dgdd6c VM9Z5b btnActiveSettingClick" href="#" id="defaultOpenSetting"
                               onclick="openSetting(event, 'AllAdmin')">
                                <div class="Mw2I7 btnActiveSetting"><span class="dtviD">All Admin</span></div>
                            </a>-->
                            <!--<a class="dgdd6c VM9Z5b btnActiveSettingClick" href="#"
                               onclick="openSetting(event, 'SchoolMembership')">
                                <div class="Mw2I7"><span class="dtviD">Membership Plan</span></div>
                            </a>-->

                        </div>
                        <div id="AllAdmin" class="tabcontentSetting">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="panel panel-primary">
                                        <div class="panel-heading">List Of Admin</div>
                                            <div class="panel-body">
                                                <table class="myTable">
                                                    <thead style="font-size: 16px;padding:0px 10px;">
                                                        <tr>
                                                            <th style="background-color: #F39C12;color:#ffffff;font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif">Image</th>
                                                            <th style="background-color: #F39C12;color:#ffffff;font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif">Name</th>
                                                            <th style="background-color: #F39C12;color:#ffffff;font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif">Email</th>
                                                            <th style="background-color: #F39C12;color:#ffffff;font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif">Designation</th>
                                                            
                                                            <th style="background-color: #F39C12;color:#ffffff;font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif">Created On</th>
                                                            <th style="background-color: #F39C12;color:#ffffff;font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="adminList">
                                                        
                                                    </tbody>
                                                </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="panel panel-primary">
                                        <div class="panel-heading">Membership Details</div>
                                        <div class="panel-body">
                                            <p><span><b>Your Membership : </b></span>   <span id="yourMembership"> </span></p>
                                            <p><span><b> From : </b></span>  <span id="membershipFrom"> </span></p>
                                            <p><span><b>Your Membership Expire On : </b></span> <span id="yourMembershipExpireOn">  </span></p>
                                            <p><span><b>Membership Status : </b></span>   <span id="membershipStatus" > <span class="text-success">  </span> </span></p>
                                            <center><!--<button class="btn btn-warning">View Previous Membership</button>--></center>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--<div id="SchoolMembership" class="tabcontentSetting">
                            <h3>Post</h3>
                            <p>Post School Membership</p> 
                        </div>-->
                    </div>
                    
                    <div id="Gallery" class="tabcontent">

                        <div id="taw">
                            <a class="dgdd6c VM9Z5b btnActiveGalleryClick" href="#" id="defaultOpenGallery"
                               onclick="openGallery(event, 'ViewGallery')">
                                <div class="Mw2I7 btnActiveGallery"><span class="dtviD">Add New Gallery</span></div>
                            </a>
                        </div>
                        <div id="ViewGallery" class="tabcontentGallery">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="album-container">
                                    </div>
                                    <div class="album-items-container" style="display: none;">
                                        <div>
                                            <div class="back-to-album" style="cursor:pointer;font-size:14px;display:inline-block;vertical-align:middle;width:38%;"> <u>Back to gallery</u></div>
                                            <div class="item-container-album-name" style="font-size:20px;display:inline-block;vertical-align:middle;text-align:center;"></div>
                                            <div style="font-size:20px;display:inline-block;vertical-align:middle;text-align:center;"><img src="images/addbutton.png" style="margin-left:20px;height:50px;width:50px;cursor:pointer;" class="add-album-item-button" /></div>
                                        </div>    
                                        <div class="album-items">
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
</section>
<!-- =========================
FOOTER
============================== -->
<section class="copyright">
    <h2></h2>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="copy_right_text">
                    <!-- COPYRIGHT TEXT -->
                    <p>Copyright &copy; 2018. All Rights Reserved.</p>
                    <p><a href="#">Talking Classes</a></p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="scroll_top">
                    <a href="#HOME"><i class="fa fa-angle-up"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- END FOOTER -->
<!-- =========================
SCRIPTS
============================== -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<script src="js/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.js"></script>
<script src="js/bootstable.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="js/bootstrap-multiselect.js"></script>
<script src="js/jquery.base64.min.js"></script>
<style type="text/css">
    .multiselect-container {
        width: 100% !important;
    }
</style>
<script type="text/javascript">


    //var quotations = 

</script>
<script type="text/javascript">
    var postCategory = "na"
    var postContent = "na";
    var postFor = "school";
    var postSubFor = "na";
    var postForClass = "na";
    var postForSection = "na";
    var postFileType = "";
    var postForValue = "na";
    var postIsImage = false;
    var postIsPdf = false;

    var userSessionId = <?php echo $userIds;  ?>;
    var schoolSessionId = <?php echo $schoolId; ?>;
    var schoolSessionBranchId = <?php echo $schoolBranchId; ?>;
    var teacherIdNumList = [];
	var childAdmissionNumList = [];
    var classJson = [];
    var subjectJson = [];
    var sectionJson = [];
    var schoolImage = "";
    //alert(schoolSessionBranchId);
    var userProfileImage = 'http://localhost/talking_classes_staging/assets/users/images/file-' + userSessionId + '.jpg';
    var defaultImage = 'http://localhost/talking_classes_staging/assets/user_images/users/user-defaul-image.png';
    var isGroupStatus = false;
    var chatGroupIds = "";
    var friendIds = "";
    // alert(schoolSessionId);


    check(userProfileImage)
        .on("error", function (e) {
            console.log(e.type, this.src)
            $('#userProfileImage').attr('src', defaultImage);
        })
        .on("load", function (e) {
            $('#userProfileImage').attr('src', userProfileImage);
        })


    function check(src) {
        return $("<img>").attr('src', src);
    }

    // alert("schoolSessionId : "+schoolSessionId);

    $(document).ready(function () {
		$.ajax({
			url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
			type: "GET",
			async: true,
			data: {"flag": "get_child_admission_no", "school_id": schoolSessionId, "branch_id":schoolSessionBranchId},
			datatype: 'html',
			success: function (result) {   
				console.log("Get Child Admission Number");
				//console.log(result);
				var decodedJson = jQuery.parseJSON(result);
				var responseMessage = decodedJson.response.response_message;
				var responseStatus = decodedJson.response.response_status;
				var teacherIdNumbRespData = decodedJson.response.response_data;
				if(responseStatus){
					//
					$.each(teacherIdNumbRespData, function (i, currProgram) {
						childAdmissionNumList.push(currProgram.admission_number);
					});
				}
			}
		});
		console.log(childAdmissionNumList);

        $.ajax({
            url: "http://localhost/talking_classes_staging/schooladmin/schools/manage?flag=",
            type: "GET",
            async: true,
            data: {
                "flag": "get_class_section_subject",
                "user_id": userSessionId,
                'branch_id': schoolSessionBranchId,
                'school_id': schoolSessionId
            },
            datatype: 'htlm',
            success: function (result) {

                // console.log(result);
                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var responseStatus = decodedJson.response.response_status;
                var data = decodedJson.response.response_data;
                var app_school_classes = data.app_school_classes;
                var app_subjects = data.app_subjects;
                var app_school_class_sections = data.app_school_class_sections;

                $.each(app_school_classes, function (i, currProgram) {
                    //console.log(currProgram.item_name);
                    classJson.push(currProgram.item_name);
                    var newOption = $('<option value="' + currProgram.item_value + '">' + currProgram.item_name + '</option>');
                    $('.post-preview-selectclass').append(newOption);
                });

                $.each(app_subjects, function (i, currProgram) {
                    //console.log(currProgram.item_name);
                    subjectJson.push(currProgram.item_name);
                });

                $.each(app_school_class_sections, function (i, currProgram) {
                    //console.log(currProgram.item_name);
                    sectionJson.push(currProgram.item_name);
                    var newOption = $('<option value="' + currProgram.item_value + '">' + currProgram.item_name + '</option>');
                    $('.post-preview-sections').append(newOption);
                });
            }
        });

        $('#profile img').attr('src', userProfileImage);
        $('#profile p').text($('#guestUsername').text());

        $('#clickmessageProfileSrc').attr('src', userProfileImage);
        $('#clickmessageProfileName').text($('#guestUsername').text());

        var school_country = "";
        var school_states = "";
        var school_city = "";

        /************** Get Specific School Data Start*****************/
        $.ajax({
            url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
            type: "GET",
            async: true,
            data: {
                "flag": "get_specific_school_data",
                "user_id": userSessionId,
                'branch_id': schoolSessionBranchId,
                'school_id': schoolSessionId
            },
            datatype: 'htlm',
            success: function (result) {

                console.log("Get Specific Result Data");
                console.log(result);
                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var responseStatus = decodedJson.response.response_status;
                var data = decodedJson.response.response_data;
                if (responseStatus) {

                    /*   alert(data.school_type);

                     alert(data.branch_city);
                     alert(data.school_address);
                     alert(data.school_contactno);*/

                    schoolImage = data.school_image;
                    $('#imagePreview').css('background-image', 'url(' + schoolImage + ')');
                    // alert('topSchoolName');
                    // alert(data.school_name);
                    $('#topSchoolName').text(data.school_name);
                    $('#topBranchName').text(data.branch_name);
                    $('#topSchoolImage').attr('src', data.school_image);

                    // School Edit Form Data Fill Start
                    $('#schoolName').val(data.school_name);
                    // $('#schoolType').val(data.school_type);
                    $('#branchName').val(data.branch_name);
                    $('#schoolURL').val(data.school_url);
                    $('#schoolPhone').val(data.school_contactno);
                    $('#schoolMobile').val(data.school_mobile_no);
                    $('#schoolAddress').val(data.school_address);

                    school_country = data.country_id;
                    school_states = data.state_id;
                    school_city = data.branch_city;
                }
            }
        });
        /************** Get Specific School Data End *****************/

        /************** Get School Country state city Start *****************/
        $.ajax({
            url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
            type: "GET",
            async: true,
            data: {"flag": "get_country"},
            datatype: 'html',
            success: function (result) {
                console.log(result);
                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var branchData = decodedJson.response.response_data;

                $.each(branchData, function (i, currProgram) {
                    //alert(currProgram.country_name);
                    if (parseInt(school_country) == parseInt(currProgram.id)) {
                        $('#country').append('<option value="' + currProgram.id + '" selected>' + currProgram.country_name + '</option>');
                    } else {
                        $('#country').append('<option value="' + currProgram.id + '">' + currProgram.country_name + '</option>');
                    }

                });
            }
        });


        $.ajax({
            url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
            type: "GET",
            async: true,
            data: {"flag": "get_state", "country_id": school_country},
            datatype: 'html',
            success: function (result) {

                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var branchData = decodedJson.response.response_data;
                $('#state').html('');
                $('#state').append('<option value="">PLEASE SELECT STATE</option>');
                $.each(branchData, function (i, currProgram) {

                    if (parseInt(school_states) == parseInt(currProgram.id)) {
                        $('#state').append('<option value="' + currProgram.id + '" selected>' + currProgram.state_name + '</option>');
                    } else {
                        $('#state').append('<option value="' + currProgram.id + '">' + currProgram.state_name + '</option>');
                    }

                });
            }
        });

        $.ajax({
            url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
            type: "GET",
            async: true,
            data: {"flag": "get_cities", "state_id": school_states},
            datatype: 'html',
            success: function (result) {
                console.log(result);
                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var branchData = decodedJson.response.response_data;
                $('#city').html('');
                $('#city').append('<option value="">PLEASE SELECT CITY</option>');
                $.each(branchData, function (i, currProgram) {

                    if (parseInt(school_city) == parseInt(currProgram.id)) {
                        $('#city').append('<option value="' + currProgram.id + '" selected>' + currProgram.city_name + '</option>');
                    } else {
                        $('#city').append('<option value="' + currProgram.id + '">' + currProgram.city_name + '</option>');
                    }


                });
            }
        });

	
        $('#country').change(function () {

            var countryId = $(this).val();
            //alert(countryId);
            $.ajax({
                url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
                type: "GET",
                async: true,
                data: {"flag": "get_state", "country_id": countryId},
                datatype: 'html',
                success: function (result) {

                    var decodedJson = jQuery.parseJSON(result);
                    var responseMessage = decodedJson.response.response_message;
                    var branchData = decodedJson.response.response_data;
                    $('#state').html('');
                    $('#state').append('<option value="">PLEASE SELECT STATE</option>');
                    $.each(branchData, function (i, currProgram) {

                        $('#state').append('<option value="' + currProgram.id + '">' + currProgram.state_name + '</option>');

                    });
                }
            });

        });

        $('#state').change(function () {
            var stateId = $(this).val();
            $.ajax({
                url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
                type: "GET",
                async: true,
                data: {"flag": "get_cities", "state_id": stateId},
                datatype: 'html',
                success: function (result) {
                    console.log(result);
                    var decodedJson = jQuery.parseJSON(result);
                    var responseMessage = decodedJson.response.response_message;
                    var branchData = decodedJson.response.response_data;
                    $('#city').html('');
                    $('#city').append('<option value="">PLEASE SELECT CITY</option>');
                    $.each(branchData, function (i, currProgram) {

                        $('#city').append('<option value="' + currProgram.id + '">' + currProgram.city_name + '</option>');

                    });
                }
            });

        });
        /************** Get School Country state city End *****************/


    });

    $('#updateSchoolProfileData').click(function () {

        // School Edit Form Data Fill Start
        var schoolName = $('#schoolName').val();
        // $('#schoolType').val(data.school_type);
        var branchName = $('#branchName').val();
        var schoolURL = $('#schoolURL').val();
        var schoolPhone = $('#schoolPhone').val();
        var schoolType = $('#schoolType').val();
        var schoolMobile = $('#schoolMobile').val();
        var school_address = $('#schoolAddress').val();
        var country = $('#country').val();
        var state = $('#state').val();
        var city = $('#city').val();
        var schoolHiddenImage = $('#schoolHiddenImage').val();

        $.ajax({
            url: "http://localhost/talking_classes_staging/schooladmin/schools/manage?flag=update_school_Profile_data",
            type: "post",
            async: true,
            data: {
                "user_id": userSessionId,
                'branch_id': schoolSessionBranchId,
                'school_id': schoolSessionId,
                "schoolName": schoolName,
                "branchName": branchName,
                "schoolURL": schoolURL,
                "schoolPhone": schoolPhone,
                "schoolType": schoolType,
                "schoolMobile": schoolMobile,
                "school_address": school_address,
                "country": country,
                "state": state,
                "city": city,
                "schoolHiddenImage": schoolHiddenImage
            },
            datatype: 'htlm',
            success: function (result) {

                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var responseStatus = decodedJson.response.response_status;
                var responseSchoolData = decodedJson.response.response_data;
                if (responseStatus) {
						
						$('#topSchoolImage').attr('src', responseSchoolData.school_image +"?"+$.now() );
                    swal("", "Your information is successfully updated", "success");
                }
            }
        });


    });

    $(function () {
        $(".classInput").autocomplete({
            source: classJson
        });
    });

	$("#contactsearch").on("keyup", function () {
		var value = $(this).val().toLowerCase();
		$(".contact").filter(function () {
			$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	});
	String.prototype.unquoted = function (){return this.replace (/(^")|("$)/g, '')}
    function openTab(evt, cityName) {
		
		if(cityName == "VerifyTeacher"){
			alert('VerifyTeacher');
			document.getElementById("defaultOpenVT").click();
		}
		
		if(cityName == "ParentList"){
			document.getElementById("defaultOpenPL").click();
		}
		
		if(cityName == "ReviewPost"){
			//alert('ReviewPost');
			document.getElementById("defaultOpenRP").click();
		}
		
        if (cityName == "Message") {
            // alert('Message Tab Clicked');
            //alert(userSessionId);
			
			$(".spn_hol").fadeIn('slow');

            $('#addGroupSubmit').click(function () {
                //alert('addGroupSubmit');
                //     
                //alert(userSessionId);
                var addGroupName = $('#groupName').val();
                var group_members = $('#demogroupParentName').val();

                var groupMemberString = group_members.toString();

                //?flag=&=932&=Test%20group&=868,867
                $.ajax({
                    url: "http://localhost/talking_classes_staging/mobile/messages/manage",
                    type: "GET",
                    async: true,
                    data: {
                        "flag": "new_school_group",
                        "user_id": userSessionId,
                        'group_name': addGroupName,
                        'group_members': groupMemberString,
                        'branch_id': schoolSessionBranchId,
                        'school_id': schoolSessionId
                    },
                    datatype: 'html',
                    success: function (result) {
                        // alert('aaaa');
                        console.log(result);
						var decodedJson = jQuery.parseJSON(result);
                        var response_status = decodedJson.response.response_status;
                        var response_message = decodedJson.response.response_message;
                        var data = decodedJson.response.response_data;
						if(response_status){
							swal('',response_message,'success');
							var mUrl = 'http://localhost/talking_classes_staging/mobile/messages/manage?flag=get_messages&user_id='+userSessionId+'&room_id=' + data.room_id + '&is_group=true&group_id=' + data.group_id;
                                var chatList = '<li id=' + data.room_id + ' onClick="chatApiCall(\'' + mUrl + '\',this.id);" class="contact ' + data.room_id + '"><div class="wrap"><span class="contact-status online"></span><img src="http://localhost/talking_classes_staging/assets/system_images/default_groupimage.png" alt="" /><div class="meta"><p class="name">' + addGroupName + '</p><p class="preview" style="display:none"></p></div></div></li>';
									$('#addGroupModal').modal('hide');
								$('#allContactList').prepend(chatList);
								
						}else{
							swal('',response_message,'error');
						}
                    }
                });


            });
            $('#addGroupContact').click(function () {

                //alert(userSessionId);

                $.ajax({
                    url: "http://localhost/talking_classes_staging/mobile/contacts/manage",
                    type: "GET",
                    async: true,
                    data: {
                        "flag": "get_contacts",
                        "user_id": schoolSessionId,
                        'child_class': 'na',
                        'child_class_section': 'na',
                        'child_id': 'na',
                        'filter_for': 'lounge'
                    },
                    datatype: 'html',
                    success: function (result) {

                        var decodedJson = jQuery.parseJSON(result);
                        var response_status = decodedJson.response.response_status;
                        var data = decodedJson.response.response_data;
                        if (response_status) {
                            //var parents = data.parents;
                            var parents = data[1].parents;
                            //  data[1].parents
                            $.each(parents, function (i, currProgram) {
                                $('#demogroupParentName').append('<option value="' + currProgram.user_id + '">' + currProgram.user_firstname + ' ' + currProgram.user_lastname + '</option>');
                            });
                        }
                    }
                });


                $('#demogroupParentName').multiselect(
                    {
                        includeSelectAllOption: true,
                        /*onChange: function(option, checked) {
                         alert('Not triggered when clicking the select all!');
                         },*/
                        enableHTML: false,
                        buttonClass: 'form-control custom-input-box',
                        inheritClass: false,
                        buttonWidth: 'auto',
                        buttonContainer: '<div />',
                        dropRight: false,
                        enableFiltering: true,
                        nonSelectedText: 'Please Select Childs',
                    }
                );

                $('#addGroupModal').modal('show');
            });

			
            $('#allContactList').html("");

            $.ajax({
                url: "http://localhost/talking_classes_staging/mobile/messages/manage",
                type: "GET",
                async: true,
                data: {"flag": "get_message_contactlist", "user_id": userSessionId},
                datatype: 'html',
                success: function (result) {
                    console.log("Get School Parent Query");
                    console.log(result);
                    var decodedJson = jQuery.parseJSON(result);
                    var response_status = decodedJson.response.response_status;
                    var data = decodedJson.response.response_data;
                    if (response_status) {
                        $.each(data, function (i, currProgram) {
                            var proImage = (currProgram.friend_profilepic != "") ? currProgram.friend_profilepic : "http://localhost/talking_classes_staging/assets/system_images/default_groupimage.png";
                            // alert(currProgram.room_id);
                            if (currProgram.is_group) {
                                // alert(currProgram.group_name);
                                var mUrl = 'http://localhost/talking_classes_staging/mobile/messages/manage?flag=get_messages&user_id=867&room_id=' + currProgram.room_id + '&is_group=true&group_id=' + currProgram.group_id;
                                var chatList = '<li id=' + currProgram.room_id + ' onClick="chatApiCall(\'' + mUrl + '\',this.id);" class="contact ' + currProgram.room_id + '"><div class="wrap"><span class="contact-status online"></span><img src="' + proImage + '" alt="" /><div class="meta"><p class="name">' + currProgram.group_name + '</p><p class="preview" style="display:none">' + currProgram.last_messagetime + '</p></div></div></li>';
                            } else {
                                // alert(currProgram.friend_name);
                                var mUrl = 'http://localhost/talking_classes_staging/mobile/messages/manage?flag=get_messages&user_id=867&room_id=' + currProgram.room_id + '&is_group=false&group_id=0';
                                var chatList = '<li id=' + currProgram.room_id + ' onClick="chatApiCall(\'' + mUrl + '\',this.id);" class="contact ' + currProgram.room_id + '"><div class="wrap"><span class="contact-status online"></span><img src="' + proImage + '" alt="" /><div class="meta"><p class="name">' + currProgram.friend_name + '</p><p class="preview"  style="display:none">' + currProgram.last_messagetime + '</p></div></div></li>';
                            }
                            $('#allContactList').append(chatList);
                        });

                    }
					
					$(".spn_hol").fadeOut('slow');
                }
            });


        }
        if (cityName == "Gallery") {
            getGalleryAlbums();
        }
		
		
		if (cityName == "Setting") {
			//alert('Setting');
			$(".spn_hol").fadeIn('slow');
			$.ajax({
            url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
            type: "GET",
            async: true,
			data:{'flag':'get_school_membership_plans','school_id':schoolSessionId,'branch_id':schoolSessionBranchId},
            dataType: "html",
            success: function (result) {
				//alert(result);
				//console.log("school membership Information");
				//console.log(result);
                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_status;
                var membershipResponseData = decodedJson.response.response_data;
				var membership = "";
				     
					 
				if(responseMessage){	 
					 $.each(membershipResponseData, function (i, currProgram) {
						 if(currProgram.plan_status == "1"){
							membership = '<span class="text-success"> Active </span>'; 
						 }else{
							 membership = '<span class="text-danger"> Inactive </span>'; 
						 }
						 $('#yourMembership').text(currProgram.plan_name);
						 $('#membershipFrom').text(currProgram.membership_start_date + " - " + currProgram.membership_end_date);
						 $('#yourMembershipExpireOn').text(currProgram.membership_end_date);
						 $('#membershipStatus').html(membership);
					 });
				}
			}
			});
			
			$.ajax({
            url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
            type: "GET",
            async: true,
			data:{'flag':'get_school_admin_list','user_id':userSessionId,'school_id':schoolSessionId,'branch_id':schoolSessionBranchId},
            dataType: "html",
            success: function (result) {
				//alert(result);
				//console.log("school admin user");
				console.log(result);
                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var adminData = decodedJson.response.response_data;
                $('.adminList').html('');
				$(".spn_hol").fadeOut('slow');
                $.each(adminData, function (i, currProgram) {
                     
                    var adminUserName = currProgram.user_firstname + ' ' +currProgram.user_lastname;
                   
                    $('.adminList').append('<tr id="adminUser_'+ currProgram.id+'"> <td ><img src="'+ currProgram.user_image +'" alt="" style="width: 40px;" /></td> <td>'+ adminUserName +'</td> <td>'+ currProgram.user_email +'</td> <td>'+ currProgram.user_designation +'</td> <td>'+ currProgram.created_date +'</td> <td><a class="grey viewUserDetailsClick" id="'+ currProgram.id +'" href="#"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td> </tr>');
                    
                });
            },error: function (error) {
                //console.log("Category Error : "+JSON.stringify(error));
                //alert(JSON.stringify(error));
            }
        });
			
		}
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }

	
    function createNewAlbum(albumName){
        $.ajax({
            url: "http://localhost/talking_classes_staging/schooladmin/schools/manage?flag=add_new_album",
            type: "GET",
            async: true,
            data: {
                "album_name" : albumName,
                "user_id": userSessionId,
                'branch_id': schoolSessionBranchId,
                'school_id': schoolSessionId
            },
            datatype: 'json',
            success: function (result) {
                $("#addNewGallery").modal("hide");
                alert("Album Created Successfully");
                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var responseStatus = decodedJson.response.response_status;
                var galleryData = decodedJson.response.response_data.gallery_items;
                if (responseStatus) {
                    $(".album-container").html("");
                    $.each(galleryData, function (i, albumItem) {
                        var albumName = albumItem.album_name;
                        var albumItems  = albumItem.total_images;
                        var albumThumbImage = albumItem.last_image  === null ? "http://localhost/tc-website/images/placeholder.png" : albumItem.last_image;
                        var albumId = albumItem.album_id;

                        $(".album-container").append("<div style='background-color: #f2f2f2;border:1px solid transparent;margin:20px;border-radus:4px;width:300px;height:350px;display: inline-block;vertical-align: middle;'><div  class='album-thumb-image' albumId='"+albumId+"' albumName='"+albumName+"'><img src='"+albumThumbImage+"' style='cursor:pointer;width:300px;height:300px;overflow: hidden;' alt=''> </div> <div style='padding: 10px;'><div><div style='display: inline-block;vertical-align: middle;width: 70%;'><span class='gallery-name'>"+albumName+"</span></div><div style='display: inline-block;vertical-align: middle;width:20%;'><div><div style='display: inline-block;vertical-align: middle;'><img src='images/galleryicon.png' style='height:20px;width:20px;'></div><div style='display: inline-block;vertical-align: middle;'><span class='total-gallery-images'>&nbsp;&nbsp;"+albumItems+"</span></div></div></div></div></div></div>");
                    });                    
                    $(".album-container").show();
                    $(".album-items-conatiner").hide();
                }
            }
        });
    }
    function getGalleryAlbums(){
        $.ajax({
            url: "http://localhost/talking_classes_staging/schooladmin/schools/manage?flag=get_school_gallery_albums",
            type: "GET",
            async: true,
            data: {
                "user_id": userSessionId,
                'branch_id': schoolSessionBranchId,
                'school_id': schoolSessionId
            },
            datatype: 'json',
            success: function (result) {

                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var responseStatus = decodedJson.response.response_status;
                var galleryData = decodedJson.response.response_data;
                if (responseStatus) {
                    $.each(galleryData, function (i, albumItem) {
                        var albumName = albumItem.album_name;
                        var albumItems  = albumItem.total_images;
                        var albumThumbImage = albumItem.last_image  === null ? "http://localhost/tc-website/images/placeholder.png" : albumItem.last_image;
                        var albumId = albumItem.album_id;

                        $(".album-container").append("<div style='background-color: #f2f2f2;border:1px solid transparent;margin:20px;border-radus:4px;width:300px;height:350px;display: inline-block;vertical-align: middle;'><div><img class='album-thumb-image'  albumId='"+albumId+"' albumName='"+albumName+"' src='"+albumThumbImage+"' style='cursor:pointer;width:300px;height:300px;overflow: hidden;' alt=''> </div> <div style='padding: 10px;'><div><div style='display: inline-block;vertical-align: middle;width: 70%;'><span class='gallery-name'>"+albumName+"</span></div><div style='display: inline-block;vertical-align: middle;width:20%;'><div><div style='display: inline-block;vertical-align: middle;'><img src='images/galleryicon.png' style='height:20px;width:20px;'></div><div style='display: inline-block;vertical-align: middle;'><span class='total-gallery-images'>&nbsp;&nbsp;"+albumItems+"</span></div></div></div></div></div></div>");
                    });
                    $(".album-container").show();
                    $(".album-items-conatiner").hide();
                }
            }
        });
    }

    $(document).on('click','.add-album-item-button',function(){
        var options = {schoolid : <?php echo $schoolId;?>,branchid : <?php echo $schoolBranchId; ?>,albumid:$(this).attr('albumid')};
        $('.js-uploader__box').uploader(options);
        $("#addNewAlbumItem").modal("show");
    });

    // Get the element with id="defaultOpen" and click on it
    document.getElementById("defaultOpen").click();

    function openNB(evt, cityName) {
        var i, tabcontentNB, tablinks;
        tabcontentNB = document.getElementsByClassName("tabcontentNB");
        for (i = 0; i < tabcontentNB.length; i++) {
            tabcontentNB[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }

    document.getElementById("defaultOpenNB").click();

    function openVT(evt, cityName) {
        var i, tabcontentVT, tablinks;
        tabcontentVT = document.getElementsByClassName("tabcontentVT");
        for (i = 0; i < tabcontentVT.length; i++) {
            tabcontentVT[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
		
		var school_id = schoolSessionId;
		var branch_id = schoolSessionBranchId;
		// All Tabs Condition Start Here 
			if(cityName == "AllTeacherList"){

				// Verify Teacher List Start Here

				$(".spn_hol").fadeIn('slow');
				
				$(".teacherListSearch").on("keyup", function () {
					//alert('Teacher');
					var value = $(this).val().toLowerCase();
					$(".teacherTable tr").filter(function () {
						$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
					});
				});
			  
				var teacherIdNumList = [];
				 $.ajax({
					url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
					type: "GET",
					async: true,
					data: {"flag": "get_teacher_unique_id_no", "school_id": school_id, "branch_id":branch_id},
					datatype: 'html',
					success: function (result) {
					   // alert(result);
						var decodedJson = jQuery.parseJSON(result);
						var responseMessage = decodedJson.response.response_message;
						var responseStatus = decodedJson.response.response_status;
						var teacherIdNumbRespData = decodedJson.response.response_data;
						if(responseStatus){
							$.each(teacherIdNumbRespData, function (i, currProgram) {
								if(currProgram.teacher_id_no != null){
									teacherIdNumList.push(currProgram.teacher_id_no);
								}
							});
						}
					},complete: function() {
						$(this).data('requestRunning', false);
					}
				 }); 
				//alert(teacherIdNumList);
				$.ajax({
					url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
					type: "GET",
					async: true,
					data: {"flag": "school_teachers", "school_id": school_id, "branch_id":branch_id},
					datatype: 'html',
					success: function (result) {
						console.log("Get Teacher Query");
						console.log(result);
						var decodedJson = jQuery.parseJSON(result);
						var responseMessage = decodedJson.response.response_message;
						var responseStatus = decodedJson.response.response_status;
						
						if(responseStatus){
							var data = decodedJson.response.response_data;
							//console.log(data);
							var allTeacherRow = "";

							var countAll = 1;
							var countUnverified = 1;
							var countVerfied = 1;
							var unverifiedData;
							var allData;
							var verifiedData;
							$.each(data, function (i, currProgram) {
								if (currProgram.is_verified == 0) {

									var allTeacherRowData = "<tr id='" + currProgram.teacher_id + "' class=''><td><img src='"+ currProgram.user_image +"' alt='' class='img-circle img-responsive' style='width:35px;height:35px;' ></td><td>" + currProgram.user_firstname + ' ' + currProgram.user_lastname + "</td><td>" + currProgram.user_email + "</td><td>" + currProgram.user_contactno + "</td><td><input data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td><a class='grey editTeacher'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> || <a class='grey deleteTeacher' href='#'><i class='fa fa-trash'></i></a></td></tr>";
									allData = allData + allTeacherRowData;
									countAll = countAll + 1;
								} else {

									var allTeacherRowData = "<tr id='" + currProgram.teacher_id + "' class=''><td><img src='"+ currProgram.user_image +"' alt='' class='img-circle img-responsive' style='width:35px;height:35px;'></td><td>" + currProgram.user_firstname + ' ' + currProgram.user_lastname + "</td><td>" + currProgram.user_email + "</td><td>" + currProgram.user_contactno + "</td><td><input checked data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td> <a class='grey editTeacher'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> || <a class='grey deleteTeacher' href='#'><i class='fa fa-trash'></i></a></td></tr>";
									allData = allData + allTeacherRowData;

									countAll = countAll + 1;
								}
							});

							$("#allTeacherRow").html(allData);
							$("[data-toggle='toggle']").bootstrapToggle('destroy');                 
							$("[data-toggle='toggle']").bootstrapToggle();
						}                
							$(".spn_hol").fadeOut('slow');
					},complete: function() {
						$(this).data('requestRunning', false);
					}
				});

				$('.removeTeacherFromSchool').click(function () {
					var teacherId = $('#teacheIds').val();
				  
					swal({
					  title: "Are you sure?", 
					  text: "You want to delete this Teacher?", 
					  type: "warning",
					  showCancelButton: true,
					  closeOnConfirm: false,
					  confirmButtonText: "Yes, delete it!",
					  confirmButtonColor: ""
					}, function() {
						$.ajax({
						url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
						type: "GET",
						async: true,
						data: {"flag": "inactive_teacher_status", "teacher_id": teacherId},
						datatype: 'html',
						success: function (result) {
							//alert('succ');
							swal("", "Record Deleted Successfully", "success");

							$('.' + teacherId).hide(1000);
							$('#editTeacherData').modal('hide');
						},complete: function() {
							$(this).data('requestRunning', false);
						}
					  });             
					});
				});

				$('.deleteTeacher').click(function () {
					var teacherId = $(this).closest('tr').attr('class');

					swal({
					  title: "Are you sure?", 
					  text: "You want to delete this teacher?", 
					  type: "warning",
					  showCancelButton: true,
					  closeOnConfirm: false,
					  confirmButtonText: "Yes, delete it!",
					  confirmButtonColor: ""
					}, function() {
						$.ajax({
						url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
						type: "GET",
						async: false,
						data: {"flag": "inactive_teacher_status", "teacher_id": teacherId},
						datatype: 'html',
						success: function (result) {
							//alert('succ');
							swal("", "Record Deleted Successfully", "success");

							$('.' + teacherId).hide(1000);

						},complete: function() {
							$(this).data('requestRunning', false);
						}
					  });             
					});
				});

				
			  
				$('.updateClassSectionInfo').click(function () {
					var teacherId = $('#teacheIds').val();
					var teacherIdNumb = $('#teacherIdNumb').val();
					//alert(teacherId);
					var classes = [];
					var sections = [];
					var subjects = [];
					var recordId = [];
					
					 //form classes data end
					$("input[name='teacherClassName[]']").map(function(){
					   //alert($(this).val());
					   classes.push($(this).val()); 
					 }).get();
					console.log(classes);
					//form classes data end
					

					//form sections data end
					$("input[name='teacherSectionName[]']").map(function(){
					   //alert($(this).val());
					   sections.push($(this).val()); 
					 }).get();
					console.log(sections);
					//form classes data end

					//form subjects data end
					$("input[name='teacherSubjectName[]']").map(function(){
					   //alert($(this).val());
					   subjects.push($(this).val()); 
					 }).get();
					console.log(subjects);
					//form classes data end

					//form subjects data end
					$("input[name='recordId[]']").map(function(){
					   //alert($(this).val());
					   recordId.push($(this).val()); 
					 }).get();
					console.log(recordId);
					//form classes data end
							  
					swal({
					  title: "Are you sure?", 
					  text: "You want to modify this teacher information?", 
					  type: "warning",
					  showCancelButton: true,
					  closeOnConfirm: false,
					  confirmButtonText: "Yes, Modify!",
					  confirmButtonColor: ""
					}, function() {
						  //alert('vikash');
						$.ajax({
						url: "http://52.90.39.26/talking_classes/mobile/teacher/manage",
						type: "GET",
						async: true,
						data: {"flag": "update_class_section", "teacher_id": teacherId,"teacherIdNumb":teacherIdNumb,"teacher_class":classes,"teacher_section":sections,"teacher_subject":subjects,"recordId":recordId},
						datatype: 'html',
						success: function (result) {
							//alert('succ');
							var decodedJson = jQuery.parseJSON(result);
							var responseMessage = decodedJson.response.response_message;
							console.log(result);
							if(responseMessage){
							  swal("", "Record Updated Successfully", "success");
							}else{
							  swal("", "Issue with updating Information", "error");
							}
							
							//$('#editTeacherData').modal('hide');
						},complete: function() {
							$(this).data('requestRunning', false);
						}
					  });        
					});
				});

				$('.editTeacher').click(function () {
					var teacherId = $(this).closest('tr').attr('id');
					//alert(teacherId);
					var currentRow = $(this).closest("tr");
					var name = currentRow.find("td:eq(1)").text();
					var email = currentRow.find("td:eq(2)").text();
					var status = currentRow.find("td:eq(4)").text();
					//var is_verified_unverified = jQuery.trim(status).substring(0, 4); 
					//alert(is_verified_unverified);
					$('#madalUserName').html(name);
					$('#modalUserEmail').html(email);

				   
					$('#teacheIds').val(teacherId);

					var school_id = schoolSessionId;
					var branch_id = schoolSessionBranchId;
				   // alert(" school_id : "+school_id);
					$('#editClassSectionData').html("");
					$.ajax({
						url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
						type: "GET",
						async: true,
						data: {"flag": "get_specific_teacher_class_section","branch_id": branch_id,"school_id": school_id, "teacher_id": teacherId},
						datatype: 'html',
						success: function (result) {
						  console.log(result);
							var decodedJson = jQuery.parseJSON(result);
							var responseStatus = decodedJson.response.response_status;
							var responseMessage = decodedJson.response.response_message;
							if(responseStatus){
								var data = decodedJson.response.response_data;
								var html = "";
								var completeHtml = "";
								var counter = 0;
								$('#teacherIdNumb').val('');
								$.each(data, function (i, currProgram) {
									
									$('#teacherIdNumb').val(currProgram.teacher_id_no);
									if(currProgram.is_email_verified=='0'){
										$('#modalUserStatu').html("<span style='color:red;'>Unverified</span>");
									}
									
									if(currProgram.is_email_verified=='1'){
										$('#modalUserStatu').html("<span style='color:green;'>Verified</span>");
									}
									//alert(currProgram.is_email_verified);

									$('#teacherProfileImage').attr('src',currProgram.user_image);
									
									var html = '<div class="row"><div class="col-md-3"><div class="form-group"><input type="hidden" name="recordId[]" value="'+currProgram.id+'"><input type="text" class="form-control custom-input-box classInput" id="classInput' + counter + '" name="teacherClassName[]" value="' + currProgram.teacher_class + '"></div></div><div class="col-md-3"><div class="form-group"><input type="text" class="form-control custom-input-box sectionInput" id="sectionInput' + counter + '" name="teacherSectionName[]" value="' + currProgram.teacher_section + '"></div></div><div class="col-md-3"><div class="form-group"><input type="text"  class="form-control custom-input-box subjectInput" id="subjectInput' + counter + '" name="teacherSubjectName[]" value="' + currProgram.teacher_subject + '"></div></div></div>';
									completeHtml = completeHtml + html;
								  //  alert(currProgram.teacher_class);
									if(counter==0){
									  $('#modalUserSignedOn').html(currProgram.created_on);
									}
									counter++;
								});
								$('#editClassSectionData').html(completeHtml);
								$('#editTeacherData').modal('show');
							}
						},complete: function() {
							$(this).data('requestRunning', false);
						}
					});
					$(".classInput").autocomplete({
						source: classJson
					});
					$(".sectionInput").autocomplete({
						source: sectionJson
					});
					$(".subjectInput").autocomplete({
						source: subjectJson
					});
					$("#teacherIdNumb").autocomplete({
						source: teacherIdNumList
					});
					
				});

 
				// Verify Teacher List End Here 
			} else if(cityName == "unVerifiedList"){
				alert('unVerifiedList');
				// Unverify Teacher Start Here
				$(".spn_hol").fadeIn('slow');
				
				$(".teacherListSearch").on("keyup", function () {
					//alert('Teacher');
					var value = $(this).val().toLowerCase();
					$(".teacherTable tr").filter(function () {
						$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
					});
				});

			   // alert(school_id);
				var teacherIdNumList = [];
				 $.ajax({
					url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
					type: "GET",
					async: true,
					data: {"flag": "get_teacher_unique_id_no", "school_id": school_id, "branch_id":branch_id},
					datatype: 'html',
					success: function (result) {
					   // alert(result);
						var decodedJson = jQuery.parseJSON(result);
						var responseMessage = decodedJson.response.response_message;
						var responseStatus = decodedJson.response.response_status;
						var teacherIdNumbRespData = decodedJson.response.response_data;
						if(responseStatus){
							$.each(teacherIdNumbRespData, function (i, currProgram) {
								if(currProgram.teacher_id_no != null){
									teacherIdNumList.push(currProgram.teacher_id_no);
								}
							});
						}
					},complete: function() {
						$(this).data('requestRunning', false);
					}
				 }); 
				//alert(teacherIdNumList);
				$.ajax({
					url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
					type: "GET",
					async: true,
					data: {"flag": "unverify_school_teachers", "school_id": school_id, "branch_id":branch_id},
					datatype: 'html',
					success: function (result) {
						console.log("Get Teacher Query");
						console.log(result);
						var decodedJson = jQuery.parseJSON(result);
						var responseMessage = decodedJson.response.response_message;
						var responseStatus = decodedJson.response.response_status;
						
						if(responseStatus){
							//console.log(data);
							var data = decodedJson.response.response_data;
							var allTeacherRow = "";

							var countAll = 1;
							var countUnverified = 1;
							var countVerfied = 1;
							var unverifiedData;
							var allData;
							var verifiedData;
							$.each(data, function (i, currProgram) {
								if (currProgram.is_verified == 0) {

								   var allTeacherRow = "<tr id='" + currProgram.teacher_id + "' class=''><td><img src='"+ currProgram.user_image +"' alt='' class='img-circle img-responsive' style='width:35px;height:35px;'></td><td>" + currProgram.user_firstname + ' ' + currProgram.user_lastname + "</td><td>" + currProgram.user_email + "</td><td>" + currProgram.user_contactno + "</td><td><input data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td><a class='grey editTeacher'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> || <a class='grey deleteTeacher' href='#'><i class='fa fa-trash'></i></a></td></tr>";

									unverifiedData = unverifiedData + allTeacherRow;

									countUnverified = countUnverified + 1; 
								} 

							});

							//$("#allTeacherRow").html(allData);
							//$("#allTeacherRowVerified").html(verifiedData);
							$("#allTeacherRowUnverified").html(unverifiedData);

							$("[data-toggle='toggle']").bootstrapToggle('destroy');                 
							$("[data-toggle='toggle']").bootstrapToggle();
						}         
							$(".spn_hol").fadeOut('slow');
					},complete: function() {
						$(this).data('requestRunning', false);
					}
				});

				$('.removeTeacherFromSchool').click(function () {
					var teacherId = $('#teacheIds').val();
				  
					swal({
					  title: "Are you sure?", 
					  text: "You want to delete this Teacher?", 
					  type: "warning",
					  showCancelButton: true,
					  closeOnConfirm: false,
					  confirmButtonText: "Yes, delete it!",
					  confirmButtonColor: ""
					}, function() {
						$.ajax({
						url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
						type: "GET",
						async: true,
						data: {"flag": "inactive_teacher_status", "teacher_id": teacherId},
						datatype: 'html',
						success: function (result) {
							//alert('succ');
							swal("", "Record Deleted Successfully", "success");

							$('.' + teacherId).hide(1000);
							$('#editTeacherData').modal('hide');
						},complete: function() {
							$(this).data('requestRunning', false);
						}
					  });             
					});
				});

				$('.deleteTeacher').click(function () {
					var teacherId = $(this).closest('tr').attr('class');

					swal({
					  title: "Are you sure?", 
					  text: "You want to delete this teacher?", 
					  type: "warning",
					  showCancelButton: true,
					  closeOnConfirm: false,
					  confirmButtonText: "Yes, delete it!",
					  confirmButtonColor: ""
					}, function() {
						$.ajax({
						url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
						type: "GET",
						async: true,
						data: {"flag": "inactive_teacher_status", "teacher_id": teacherId},
						datatype: 'html',
						success: function (result) {
							//alert('succ');
							swal("", "Record Deleted Successfully", "success");

							$('.' + teacherId).hide(1000);

						},complete: function() {
							$(this).data('requestRunning', false);
						}
					  });             
					});
				});

				
			  
				$('.updateClassSectionInfo').click(function () {
					var teacherId = $('#teacheIds').val();
					var teacherIdNumb = $('#teacherIdNumb').val();
					//alert(teacherId);
					var classes = [];
					var sections = [];
					var subjects = [];
					var recordId = [];
					
					 //form classes data end
					$("input[name='teacherClassName[]']").map(function(){
					   //alert($(this).val());
					   classes.push($(this).val()); 
					 }).get();
					console.log(classes);
					//form classes data end
					

					//form sections data end
					$("input[name='teacherSectionName[]']").map(function(){
					   //alert($(this).val());
					   sections.push($(this).val()); 
					 }).get();
					console.log(sections);
					//form classes data end

					//form subjects data end
					$("input[name='teacherSubjectName[]']").map(function(){
					   //alert($(this).val());
					   subjects.push($(this).val()); 
					 }).get();
					console.log(subjects);
					//form classes data end

					//form subjects data end
					$("input[name='recordId[]']").map(function(){
					   //alert($(this).val());
					   recordId.push($(this).val()); 
					 }).get();
					console.log(recordId);
					//form classes data end
							  
					swal({
					  title: "Are you sure?", 
					  text: "You want to modify this teacher information?", 
					  type: "warning",
					  showCancelButton: true,
					  closeOnConfirm: false,
					  confirmButtonText: "Yes, Modify!",
					  confirmButtonColor: ""
					}, function() {
						  //alert('vikash');
						$.ajax({
						url: "http://52.90.39.26/talking_classes/mobile/teacher/manage",
						type: "GET",
						async: true,
						data: {"flag": "update_class_section", "teacher_id": teacherId,"teacherIdNumb":teacherIdNumb,"teacher_class":classes,"teacher_section":sections,"teacher_subject":subjects,"recordId":recordId},
						datatype: 'html',
						success: function (result) {
							//alert('succ');
							var decodedJson = jQuery.parseJSON(result);
							var responseMessage = decodedJson.response.response_message;
							console.log(result);
							if(responseMessage){
							  swal("", "Record Updated Successfully", "success");
							}else{
							  swal("", "Issue with updating Information", "error");
							}
							
							//$('#editTeacherData').modal('hide');
						},complete: function() {
							$(this).data('requestRunning', false);
						}
					  });        
					});
				});

				$('.editTeacher').click(function () {
					var teacherId = $(this).closest('tr').attr('id');
					//alert(teacherId);
					var currentRow = $(this).closest("tr");
					var name = currentRow.find("td:eq(1)").text();
					var email = currentRow.find("td:eq(2)").text();
					var status = currentRow.find("td:eq(4)").text();
					//var is_verified_unverified = jQuery.trim(status).substring(0, 4); 
					//alert(is_verified_unverified);
					$('#madalUserName').html(name);
					$('#modalUserEmail').html(email);

				   
					$('#teacheIds').val(teacherId);

				   // alert(" school_id : "+school_id);
					$('#editClassSectionData').html("");
					$.ajax({
						url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
						type: "GET",
						async: true,
						data: {"flag": "get_specific_teacher_class_section","branch_id": branch_id,"school_id": school_id, "teacher_id": teacherId},
						datatype: 'html',
						success: function (result) {
						  console.log(result);
							var decodedJson = jQuery.parseJSON(result);
							var responseMessage = decodedJson.response.response_message;
							var data = decodedJson.response.response_data;
							var html = "";
							var completeHtml = "";
							var counter = 0;
							$('#teacherIdNumb').val('');
							$.each(data, function (i, currProgram) {
								
								$('#teacherIdNumb').val(currProgram.teacher_id_no);
								if(currProgram.is_email_verified=='0'){
									$('#modalUserStatu').html("<span style='color:red;'>Unverified</span>");
								}
								
								if(currProgram.is_email_verified=='1'){
									$('#modalUserStatu').html("<span style='color:green;'>Verified</span>");
								}
								//alert(currProgram.is_email_verified);

								$('#teacherProfileImage').attr('src',currProgram.user_image);
								
								var html = '<div class="row"><div class="col-md-3"><div class="form-group"><input type="hidden" name="recordId[]" value="'+currProgram.id+'"><input type="text" class="form-control custom-input-box classInput" id="classInput' + counter + '" name="teacherClassName[]" value="' + currProgram.teacher_class + '"></div></div><div class="col-md-3"><div class="form-group"><input type="text" class="form-control custom-input-box sectionInput" id="sectionInput' + counter + '" name="teacherSectionName[]" value="' + currProgram.teacher_section + '"></div></div><div class="col-md-3"><div class="form-group"><input type="text"  class="form-control custom-input-box subjectInput" id="subjectInput' + counter + '" name="teacherSubjectName[]" value="' + currProgram.teacher_subject + '"></div></div></div>';
								completeHtml = completeHtml + html;
							  //  alert(currProgram.teacher_class);
								if(counter==0){
								  $('#modalUserSignedOn').html(currProgram.created_on);
								}
								counter++;
							});
							$('#editClassSectionData').html(completeHtml);
							$('#editTeacherData').modal('show');                 
						},complete: function() {
							$(this).data('requestRunning', false);
						}
					});
					$(".classInput").autocomplete({
						source: classJson
					});
					$(".sectionInput").autocomplete({
						source: sectionJson
					});
					$(".subjectInput").autocomplete({
						source: subjectJson
					});
					$("#teacherIdNumb").autocomplete({
						source: teacherIdNumList
					});
					
				});


				// Unverify Teacher End Here

			} else if(cityName == "verifiedList"){
				alert('verifiedList');
					// Unverify Teacher Start Here
					$(".spn_hol").fadeIn('slow');
					
				$(".teacherListSearch").on("keyup", function () {
					//alert('Teacher');
					var value = $(this).val().toLowerCase();
					$(".teacherTable tr").filter(function () {
						$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
					});
				});

			   // alert(school_id);
				var teacherIdNumList = [];
				 $.ajax({
					url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
					type: "GET",
					async: true,
					data: {"flag": "get_teacher_unique_id_no", "school_id": school_id, "branch_id":branch_id},
					datatype: 'html',
					success: function (result) {
					   // alert(result);
						var decodedJson = jQuery.parseJSON(result);
						var responseMessage = decodedJson.response.response_message;
						var responseStatus = decodedJson.response.response_status;
						var teacherIdNumbRespData = decodedJson.response.response_data;
						if(responseStatus){
							$.each(teacherIdNumbRespData, function (i, currProgram) {
								if(currProgram.teacher_id_no != null){
									teacherIdNumList.push(currProgram.teacher_id_no);
								}
							});
						}
					},complete: function() {
						$(this).data('requestRunning', false);
					}
				 }); 
				//alert(teacherIdNumList);
				$.ajax({
					url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
					type: "GET",
					async: true,
					data: {"flag": "verify_school_teachers", "school_id": school_id, "branch_id":branch_id},
					datatype: 'html',
					success: function (result) {
						console.log("Get Teacher Query");
						console.log(result);
						var decodedJson = jQuery.parseJSON(result);
						var responseMessage = decodedJson.response.response_message;
						var responseStatus = decodedJson.response.response_status;
						var data = decodedJson.response.response_data;
						if(responseStatus){
						//console.log(data);
						var allTeacherRow = "";

						var countAll = 1;
						var countUnverified = 1;
						var countVerfied = 1;
						var unverifiedData;
						var allData;
						var verifiedData;
						$.each(data, function (i, currProgram) {
							if (currProgram.is_verified == 1) {

								var allTeacherRow = "<tr id='" + currProgram.teacher_id + "' class=''><td><img src='"+ currProgram.user_image +"' alt='' class='img-circle img-responsive' style='width:35px;height:35px;'></td><td>" + currProgram.user_firstname + ' ' + currProgram.user_lastname + "</td><td>" + currProgram.user_email + "</td><td>" + currProgram.user_contactno + "</td><td><input checked data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td><a class='grey editTeacher'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> || <a class='grey deleteTeacher' href='#'><i class='fa fa-trash'></i></a></td></tr>";
								verifiedData = verifiedData + allTeacherRow;
								countVerfied = countVerfied + 1; 
							}

						});

						//$("#allTeacherRow").html(allData);
						$("#allTeacherRowVerified").html(verifiedData);
						//$("#allTeacherRowUnverified").html(unverifiedData);

							$("[data-toggle='toggle']").bootstrapToggle('destroy');                 
							$("[data-toggle='toggle']").bootstrapToggle();
						}            
							$(".spn_hol").fadeOut('slow');
					},complete: function() {
						$(this).data('requestRunning', false);
					}
				});

				$('.removeTeacherFromSchool').click(function () {
					var teacherId = $('#teacheIds').val();
				  
					swal({
					  title: "Are you sure?", 
					  text: "You want to delete this Teacher?", 
					  type: "warning",
					  showCancelButton: true,
					  closeOnConfirm: false,
					  confirmButtonText: "Yes, delete it!",
					  confirmButtonColor: ""
					}, function() {
						$.ajax({
						url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
						type: "GET",
						async: true,
						data: {"flag": "inactive_teacher_status", "teacher_id": teacherId},
						datatype: 'html',
						success: function (result) {
							//alert('succ');
							swal("", "Record Deleted Successfully", "success");

							$('.' + teacherId).hide(1000);
							$('#editTeacherData').modal('hide');
						},complete: function() {
							$(this).data('requestRunning', false);
						}
					  });             
					});
				});

				$('.deleteTeacher').click(function () {
					var teacherId = $(this).closest('tr').attr('class');

					swal({
					  title: "Are you sure?", 
					  text: "You want to delete this teacher?", 
					  type: "warning",
					  showCancelButton: true,
					  closeOnConfirm: false,
					  confirmButtonText: "Yes, delete it!",
					  confirmButtonColor: ""
					}, function() {
						$.ajax({
						url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
						type: "GET",
						async: true,
						data: {"flag": "inactive_teacher_status", "teacher_id": teacherId},
						datatype: 'html',
						success: function (result) {
							//alert('succ');
							swal("", "Record Deleted Successfully", "success");

							$('.' + teacherId).hide(1000);

						},complete: function() {
							$(this).data('requestRunning', false);
						}
					  });             
					});
				});

				
			  
				$('.updateClassSectionInfo').click(function () {
					var teacherId = $('#teacheIds').val();
					var teacherIdNumb = $('#teacherIdNumb').val();
					//alert(teacherId);
					var classes = [];
					var sections = [];
					var subjects = [];
					var recordId = [];
					
					 //form classes data end
					$("input[name='teacherClassName[]']").map(function(){
					   //alert($(this).val());
					   classes.push($(this).val()); 
					 }).get();
					console.log(classes);
					//form classes data end
					

					//form sections data end
					$("input[name='teacherSectionName[]']").map(function(){
					   //alert($(this).val());
					   sections.push($(this).val()); 
					 }).get();
					console.log(sections);
					//form classes data end

					//form subjects data end
					$("input[name='teacherSubjectName[]']").map(function(){
					   //alert($(this).val());
					   subjects.push($(this).val()); 
					 }).get();
					console.log(subjects);
					//form classes data end

					//form subjects data end
					$("input[name='recordId[]']").map(function(){
					   //alert($(this).val());
					   recordId.push($(this).val()); 
					 }).get();
					console.log(recordId);
					//form classes data end
							  
					swal({
					  title: "Are you sure?", 
					  text: "You want to modify this teacher information?", 
					  type: "warning",
					  showCancelButton: true,
					  closeOnConfirm: false,
					  confirmButtonText: "Yes, Modify!",
					  confirmButtonColor: ""
					}, function() {
						  //alert('vikash');
						$.ajax({
						url: "http://52.90.39.26/talking_classes/mobile/teacher/manage",
						type: "GET",
						async: true,
						data: {"flag": "update_class_section", "teacher_id": teacherId,"teacherIdNumb":teacherIdNumb,"teacher_class":classes,"teacher_section":sections,"teacher_subject":subjects,"recordId":recordId},
						datatype: 'html',
						success: function (result) {
							//alert('succ');
							var decodedJson = jQuery.parseJSON(result);
							var responseMessage = decodedJson.response.response_message;
							console.log(result);
							if(responseMessage){
							  swal("", "Record Updated Successfully", "success");
							}else{
							  swal("", "Issue with updating Information", "error");
							}
							
							//$('#editTeacherData').modal('hide');
						},complete: function() {
							$(this).data('requestRunning', false);
						}
					  });        
					});
				});

				$('.editTeacher').click(function () {
					var teacherId = $(this).closest('tr').attr('id');
					//alert(teacherId);
					var currentRow = $(this).closest("tr");
					var name = currentRow.find("td:eq(1)").text();
					var email = currentRow.find("td:eq(2)").text();
					var status = currentRow.find("td:eq(4)").text();
					//var is_verified_unverified = jQuery.trim(status).substring(0, 4); 
					//alert(is_verified_unverified);
					$('#madalUserName').html(name);
					$('#modalUserEmail').html(email);

				   
					$('#teacheIds').val(teacherId);

					var school_id = schoolSessionId;
					var branch_id = schoolSessionBranchId;
				   // alert(" school_id : "+school_id);
					$('#editClassSectionData').html("");
					$.ajax({
						url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
						type: "GET",
						async: true,
						data: {"flag": "get_specific_teacher_class_section","branch_id": branch_id,"school_id": school_id, "teacher_id": teacherId},
						datatype: 'html',
						success: function (result) {
						  console.log(result);
							var decodedJson = jQuery.parseJSON(result);
							var responseMessage = decodedJson.response.response_message;
							var data = decodedJson.response.response_data;
							var html = "";
							var completeHtml = "";
							var counter = 0;
							$('#teacherIdNumb').val('');
							$.each(data, function (i, currProgram) {
								
								$('#teacherIdNumb').val(currProgram.teacher_id_no);
								if(currProgram.is_email_verified=='0'){
									$('#modalUserStatu').html("<span style='color:red;'>Unverified</span>");
								}
								
								if(currProgram.is_email_verified=='1'){
									$('#modalUserStatu').html("<span style='color:green;'>Verified</span>");
								}
								//alert(currProgram.is_email_verified);

								$('#teacherProfileImage').attr('src',currProgram.user_image);
								
								var html = '<div class="row"><div class="col-md-3"><div class="form-group"><input type="hidden" name="recordId[]" value="'+currProgram.id+'"><input type="text" class="form-control custom-input-box classInput" id="classInput' + counter + '" name="teacherClassName[]" value="' + currProgram.teacher_class + '"></div></div><div class="col-md-3"><div class="form-group"><input type="text" class="form-control custom-input-box sectionInput" id="sectionInput' + counter + '" name="teacherSectionName[]" value="' + currProgram.teacher_section + '"></div></div><div class="col-md-3"><div class="form-group"><input type="text"  class="form-control custom-input-box subjectInput" id="subjectInput' + counter + '" name="teacherSubjectName[]" value="' + currProgram.teacher_subject + '"></div></div></div>';
								completeHtml = completeHtml + html;
							  //  alert(currProgram.teacher_class);
								if(counter==0){
								  $('#modalUserSignedOn').html(currProgram.created_on);
								}
								counter++;
							});
							$('#editClassSectionData').html(completeHtml);
							$('#editTeacherData').modal('show');                 
						},complete: function() {
							$(this).data('requestRunning', false);
						}
					});
					$(".classInput").autocomplete({
						source: classJson
					});
					$(".sectionInput").autocomplete({
						source: sectionJson
					});
					$(".subjectInput").autocomplete({
						source: subjectJson
					});
					$("#teacherIdNumb").autocomplete({
						source: teacherIdNumList
					});
					
				});


				// Unverify Teacher End Here

			} else if(cityName == "inactiveTeacher"){
				alert('inactiveTeacher');
			} else if(cityName == "addTeacher"){
				alert('addTeacher');
			} 
		// All Tabs Condition End Here 
		
		
		
		
    }

    function openMessage(evt, cityName) {

        var i, tabcontentMessage, tablinks;
        tabcontentMessage = document.getElementsByClassName("tabcontentMessage");
        for (i = 0; i < tabcontentMessage.length; i++) {
            tabcontentMessage[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }

    /*    document.getElementById("defaultOpenMessage").click();*/

    function openPL(evt, cityName) {

        var i, tabcontentPL, tablinks;
        tabcontentPL = document.getElementsByClassName("tabcontentPL");
        for (i = 0; i < tabcontentPL.length; i++) {
            tabcontentPL[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    
		var school_id = schoolSessionId;
		var schoolBranchId = schoolSessionBranchId;
	
		if(cityName == "PLAll"){
			//alert('PLALL');
			
			$(".spn_hol").fadeIn('slow');
			
			$(".parentListSearch").on("keyup", function () {
				//alert('parent');
				var value = $(this).val().toLowerCase();
				$(".parentTable tr").filter(function () {
					$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
				});
			});

			
			
				// alert(school_id);
			$.ajax({
				url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
				type: "GET",
				async: true,
				data: {"flag": "get_school_parents", "school_id": school_id,"school_branch":schoolBranchId},
				datatype: 'html',
				success: function (result) {
					console.log("Get School Parent Query");
					console.log(result);
					var decodedJson = jQuery.parseJSON(result);
					var responseMessage = decodedJson.response.response_message;
					var responseStatus = decodedJson.response.response_status;
					var data = decodedJson.response.response_data;
					//console.log(data);
					
					if (responseStatus) {
						
						var allParentRow = "";

						var countAll = 1;
						var countUnverified = 1;
						var countVerfied = 1;
						var unverifiedParentData;
						var allParentData;
						var verifiedParentData;
						$.each(data, function (i, currProgram) {
							// alert(currProgram.profile_status);
							if (currProgram.profile_status == 0) {

								var allParentRow = "<tr id='' class='" + currProgram.parent_id + "'><td><img src='" + currProgram.profile_image + "' alt='' class='img-circle img-responsive' style='width:35px;height:35px;'></td><td>" + currProgram.parent_name + "</td><td><div class='multiple_elements'><a href='#' class='ole two' data-toggle='tooltip' data-placement='top' data-original-title='" + currProgram.child_name + "'>" + currProgram.total_childrens + "</a></div></td><td>" + currProgram.registration_date + "</td><td><input data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td>" + currProgram.parenting_role + "</td><td><a class='grey editParent'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> </td></tr>";

								unverifiedParentData = unverifiedParentData + allParentRow;

								countUnverified = countUnverified + 1;

								var allParentRowData = "<tr id='' class='" + currProgram.parent_id + "'><td><img src='" + currProgram.profile_image + "' alt='' class='img-circle img-responsive' style='width:35px;height:35px;' ></td><td>" + currProgram.parent_name + "</td><td><div class='multiple_elements'><a href='#' class='ole two' data-toggle='tooltip' data-placement='top' data-original-title='" + currProgram.child_name + "'>" + currProgram.total_childrens + "</a></div></td><td>" + currProgram.registration_date + "</td><td><input data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td>" + currProgram.parenting_role + "</td><td><a class='grey editParent'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> </td></tr>";
								allParentData = allParentData + allParentRowData;
								countAll = countAll + 1;
							} else {

								var allParentRow = "<tr id='' class='" + currProgram.parent_id + "'><td><img src='" + currProgram.profile_image + "' alt='' class='img-circle img-responsive' style='width:35px;height:35px;'></td><td>" + currProgram.parent_name + "</td><td><div class='multiple_elements'><a href='#' class='ole two' data-toggle='tooltip' data-placement='top' data-original-title='" + currProgram.child_name + "'>" + currProgram.total_childrens + "</a></div></td><td>" + currProgram.registration_date + "</td><td><input checked data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td>" + currProgram.parenting_role + "</td><td><a class='grey editParent'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> </td></tr>";
								verifiedParentData = verifiedParentData + allParentRow;
								countVerfied = countVerfied + 1;

								var allParentRowData = "<tr id='' class='" + currProgram.parent_id + "'><td><img src='" + currProgram.profile_image + "' alt='' class='img-circle img-responsive' style='width:35px;height:35px;'></td><td>" + currProgram.parent_name + "</td><td><div class='multiple_elements'><a href='#' class='ole two' data-toggle='tooltip' data-placement='top' data-original-title='" + currProgram.child_name + "'>" + currProgram.total_childrens + "</a></div></td><td>" + currProgram.registration_date + "</td><td><input checked data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td>" + currProgram.parenting_role + "</td><td> <a class='grey editParent'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> </td></tr>";
								allParentData = allParentData + allParentRowData;

								countAll = countAll + 1;
							}
						});

						$("#allParentRow").html(allParentData);
						//$("#allParentRowUnverified").html(unverifiedParentData);
						//$("#allParentRowVerified").html(verifiedParentData);
						
						
						/* $("#allParentRow").tooltip({
							selector: "[data-toggle='tooltip']",
							container: "body"
						}).popover({
								selector: "[data-toggle='popover']",
								container: "body",
								html: true
							}); */
							
						
						//$('#dp6').datepicker();
						$("[data-toggle='toggle']").bootstrapToggle('destroy');                 
						$("[data-toggle='toggle']").bootstrapToggle();
						
					}
					$(".spn_hol").fadeOut('slow');
				}
			});
			
			
			$('#allParentRow').on('click', '.editParent', function () {
				alert('editParent');
				var parentId = $(this).closest('tr').attr('class');
				$.ajax({
					url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
					type: "GET",
					async: true,
					data: {"flag": "get_parent_profile_data", "school_id": school_id, "parent_id": parentId},
					datatype: 'html',
					success: function (result) {
						console.log(result);
						var decodedJson = jQuery.parseJSON(result);
						var responseMessage = decodedJson.response.response_message;
						var data = decodedJson.response.response_data;
						var parentProfileData = data.profile_info;
						var parent_id = parentProfileData.parent_id;
						var parent_name = parentProfileData.parent_name;
						var parent_email = parentProfileData.parent_email;
						var parent_contact_no = parentProfileData.parent_contact_no;
						var total_childrens = parentProfileData.total_childrens;
						var childrens_id = parentProfileData.childrens_id;
						var profile_image = parentProfileData.profile_image;
						var profile_status = parentProfileData.profile_status;
						var registration_date = parentProfileData.registration_date;
						var parenting_role = parentProfileData.parenting_role;

						$('#parentProfileImage').attr('src', profile_image);
						$('#madalParentName').html(parent_name);
						$('#madalParentEmail').html(parent_email);
						$('#modalParentSignedOn').html(registration_date);
						$('#modalParentRelation').html(parenting_role);
						$('#modalParentContactNumber').html(parent_contact_no);
						if (profile_status == "0") {

							$('#modalParentStatus').html("<span style='color:red;'>Unverified</span>");

						}

						if (profile_status == "1") {

							$('#modalParentStatus').html("<span style='color:green;'>Verified</span>");

						}

						var childrenProfileData = data.childrens;
						/*
						 var class_id = child_classesArray.class_id;
						 var section_id = child_classesArray.section_id;
						 var class_name = child_classesArray.class_name;
						 var section_name = child_classesArray.section_name;*/

						var html = "";
						var completeHtml = '<div class="row"><div class="col-md-9" ><div class="panel panel-default">  <div class="panel-heading">Child Information<input type="hidden" name="parentId" id="parentId" value="' + parent_id + '"></div>  ';
						var counter = 0;
						$.each(childrenProfileData, function (i, currProgram) {

							var child_id = currProgram.child_id;
							var child_name = currProgram.child_name;
							var child_gender = currProgram.child_gender;
							var child_status = currProgram.child_status;
							var admission_number = currProgram.admission_number;
							/*  alert(child_id);
							 alert(child_name);
							 alert(child_gender);
							 alert(admission_number);*/
							var child_classesArray = currProgram.child_classes;

							$.each(child_classesArray, function (i, currChild) {
								var class_id = currChild.class_id;
								var section_id = currChild.section_id;
								var class_name = currChild.class_name;
								var section_name = currChild.section_name;

								var childStatus = '';

								if (child_status) {
									childStatus = '<a href="#" style="margin-top: -5px;" id="' + child_id + '"  onClick="toggleChildStatus(' + child_id + ');" class="btn btn-danger">Block</a>';
								} else {
									childStatus = '<a href="#" style="margin-top: -5px;" id="' + child_id + '" onClick="toggleChildStatus(' + child_id + ');" class="btn btn-primary"> Unblock </a>';
									;
								}
	 
								var html = '<br/><div class="col-md-12"><div class="panel panel-default">  <div class="panel-body"><div class="row"><div class="col-md-4" > <p><span><b>Name : </b></span> <span>' + child_name + '</span></p></div><div class="col-md-3" > <p><span><b>Gender. : </b></span> <span>' + child_gender + '</span></p></div><div class="col-md-5" > <div class="col-md-5" ><span><b>Admission No.: </b></span> </div><div class="col-md-7" ><span><input name="adminNo[]" placeholder="Admission No." class="form-control custom-input-box admsearch" style="margin-top: -10px;" value="'+ admission_number +'"></span></div></div></div><hr style="width: 104%;margin-left: -17px;margin-top:0px;"><div class="row"><div class="col-md-4"><div class="form-group"><label>Class</label><input type="text" class="form-control custom-input-box classInput" name="childClassName[]" value="' + class_name + '"></div></div><div class="col-md-4"><div class="form-group"><label>Section</label><input type="hidden" name="childIds[]" value="' + child_id + '"><input type="text" class="form-control custom-input-box sectionInput" name="childSectionName[]" value="' + section_name + '"></div></div><div class="col-md-4"><div class="form-group"><p>&nbsp;</p>' + childStatus + '</div></div></div></div>  </div> </div><div class="clearfix"></div>';
								completeHtml = completeHtml + html;
							});


							counter++;
						});
						completeHtml = completeHtml + " </div></div></div>";
						$('#editParentChildData').html(completeHtml);
						$(".admsearch").autocomplete({
							source: childAdmissionNumList
						});
						$('#editParentData').modal('show');
						$(".classInput").autocomplete({
							source: classJson
						});
						$(".sectionInput").autocomplete({
							source: sectionJson
						});
					}
				});
				

			});
			
			//$('.updateChildClassSection').click(function () {
			$('.updateChildClassSection').on('click', function () {
				alert('sdfs');
				var parentId = $('#parentId').val();

				//alert(teacherId);
				var classes = [];
				var sections = [];
				var childIds = [];
				var adminNo = [];

				//form classes data end
				$("input[name='adminNo[]']").map(function () {
					//alert($(this).val());
					adminNo.push($(this).val());
				}).get();
				console.log(adminNo);
				//form classes data end

				//form classes data end
				$("input[name='childClassName[]']").map(function () {
					//alert($(this).val());
					classes.push($(this).val());
				}).get();
				console.log(classes);
				//form classes data end


				//form sections data end
				$("input[name='childSectionName[]']").map(function () {
					//alert($(this).val());
					sections.push($(this).val());
				}).get();
				console.log(sections);
				//form classes data end

				//form subjects data end
				$("input[name='childIds[]']").map(function () {
					//alert($(this).val());
					childIds.push($(this).val());
				}).get();
				console.log(childIds);
				//form classes data end

				swal({
					title: "Are you sure?",
					text: "you want to modify this information?",
					type: "warning",
					showCancelButton: true,
					closeOnConfirm: false,
					confirmButtonText: "Yes, Modify!",
					confirmButtonColor: "#ec6c62"
				}, function () {
					//alert('vikash');
					$.ajax({
						url: "http://localhost/talking_classes_staging/mobile/children/handle",
						type: "GET",
						async: true,
						data: {
							"flag": "update_child_class_section",
							"parent_id": parentId,
							"child_class": classes,
							"child_section": sections,
							"childIds": childIds,
							"adminNo": adminNo
						},
						datatype: 'html',
						success: function (result) {
							//alert('succ');
							var decodedJson = jQuery.parseJSON(result);
							var responseMessage = decodedJson.response.response_message;
							console.log(result);
							if (responseMessage) {
								swal("", "Record Updated Successfully", "success");
							} else {
								swal("", "Issue with updating Information", "error");
							}

							//$('#editParentChildData').modal('hide');
						}
					});
				});
			});
				
			/* $('.updateChildClassSection').click(function () {

				var parentId = $('#parentId').val();

				//alert(teacherId);
				var classes = [];
				var sections = [];
				var childIds = [];
				var adminNo = [];

				//form classes data end
				$("input[name='adminNo[]']").map(function () {
					//alert($(this).val());
					adminNo.push($(this).val());
				}).get();
				console.log(adminNo);
				//form classes data end

				//form classes data end
				$("input[name='childClassName[]']").map(function () {
					//alert($(this).val());
					classes.push($(this).val());
				}).get();
				console.log(classes);
				//form classes data end


				//form sections data end
				$("input[name='childSectionName[]']").map(function () {
					//alert($(this).val());
					sections.push($(this).val());
				}).get();
				console.log(sections);
				//form classes data end

				//form subjects data end
				$("input[name='childIds[]']").map(function () {
					//alert($(this).val());
					childIds.push($(this).val());
				}).get();
				console.log(childIds);
				//form classes data end

				swal({
					title: "Are you sure?",
					text: "you want to modify this information?",
					type: "warning",
					showCancelButton: true,
					closeOnConfirm: false,
					confirmButtonText: "Yes, Modify!",
					confirmButtonColor: "#ec6c62"
				}, function () {
					//alert('vikash');
					$.ajax({
						url: "http://localhost/talking_classes_staging/mobile/children/handle",
						type: "GET",
						async: false,
						data: {
							"flag": "update_child_class_section",
							"parent_id": parentId,
							"child_class": classes,
							"child_section": sections,
							"childIds": childIds,
							"adminNo": adminNo
						},
						datatype: 'html',
						success: function (result) {
							//alert('succ');
							var decodedJson = jQuery.parseJSON(result);
							var responseMessage = decodedJson.response.response_message;
							console.log(result);
							if (responseMessage) {
								swal("", "Record Updated Successfully", "success");
							} else {
								swal("", "Issue with updating Information", "error");
							}

							//$('#editParentChildData').modal('hide');
						}
					});
				});
			}); */
			
		} else if(cityName == "PLUnverified"){
			alert('PLUnverified');
			$(".spn_hol").fadeIn('slow');
			
			// Unverified Parent List Start
				$(".parentListSearch").on("keyup", function () {
				//alert('parent');
				var value = $(this).val().toLowerCase();
				$(".parentTable tr").filter(function () {
					$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
				});
			});

			
			
				// alert(school_id);
			$.ajax({
				url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
				type: "GET",
				async: true,
				data: {"flag": "get_school_parents_unverified", "school_id": school_id,"school_branch":schoolBranchId},
				datatype: 'html',
				success: function (result) {
					console.log("Get School Parent get_school_parents_unverified Query");
					console.log(result);
					var decodedJson = jQuery.parseJSON(result);
					var responseMessage = decodedJson.response.response_message;
					var responseStatus = decodedJson.response.response_status;
					var data = decodedJson.response.response_data;
					//console.log(data);
					
					if (responseStatus) {
						
						var allParentRow = "";

						var countAll = 1;
						var countUnverified = 1;
						var countVerfied = 1;
						var unverifiedParentData;
						var allParentData;
						var verifiedParentData;
						$.each(data, function (i, currProgram) {
							// alert(currProgram.profile_status);
							if (currProgram.profile_status == 0) {

								var allParentRow = "<tr id='' class='" + currProgram.parent_id + "'><td><img src='" + currProgram.profile_image + "' alt='' class='img-circle img-responsive' style='width:35px;height:35px;'></td><td>" + currProgram.parent_name + "</td><td><div class='multiple_elements'><a href='#' class='ole two' data-toggle='tooltip' data-placement='top' data-original-title='" + currProgram.child_name + "'>" + currProgram.total_childrens + "</a></div></td><td>" + currProgram.registration_date + "</td><td><input data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td>" + currProgram.parenting_role + "</td><td><a class='grey editParent'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> </td></tr>";

								unverifiedParentData = unverifiedParentData + allParentRow;

								countUnverified = countUnverified + 1;

								/* var allParentRowData = "<tr id='' class='" + currProgram.parent_id + "'><td><img src='" + currProgram.profile_image + "' alt='' class='img-circle img-responsive' style='width:35px;height:35px;' ></td><td>" + currProgram.parent_name + "</td><td><div class='multiple_elements'><a href='#' class='ole two' data-toggle='tooltip' data-placement='top' data-original-title='" + currProgram.child_name + "'>" + currProgram.total_childrens + "</a></div></td><td>" + currProgram.registration_date + "</td><td><input data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td>" + currProgram.parenting_role + "</td><td><a class='grey editParent'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> </td></tr>";
								allParentData = allParentData + allParentRowData;
								countAll = countAll + 1; */
							} /* else {

								var allParentRow = "<tr id='' class='" + currProgram.parent_id + "'><td><img src='" + currProgram.profile_image + "' alt='' class='img-circle img-responsive' style='width:35px;height:35px;'></td><td>" + currProgram.parent_name + "</td><td><div class='multiple_elements'><a href='#' class='ole two' data-toggle='tooltip' data-placement='top' data-original-title='" + currProgram.child_name + "'>" + currProgram.total_childrens + "</a></div></td><td>" + currProgram.registration_date + "</td><td><input checked data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td>" + currProgram.parenting_role + "</td><td><a class='grey editParent'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> </td></tr>";
								verifiedParentData = verifiedParentData + allParentRow;
								countVerfied = countVerfied + 1;

								 var allParentRowData = "<tr id='' class='" + currProgram.parent_id + "'><td><img src='" + currProgram.profile_image + "' alt='' class='img-circle img-responsive' style='width:35px;height:35px;'></td><td>" + currProgram.parent_name + "</td><td><div class='multiple_elements'><a href='#' class='ole two' data-toggle='tooltip' data-placement='top' data-original-title='" + currProgram.child_name + "'>" + currProgram.total_childrens + "</a></div></td><td>" + currProgram.registration_date + "</td><td><input checked data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td>" + currProgram.parenting_role + "</td><td> <a class='grey editParent'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> </td></tr>";
								allParentData = allParentData + allParentRowData;

								countAll = countAll + 1; 
							} */
						});

						//$("#allParentRow").html(allParentData);
						$("#allParentRowUnverified").html(unverifiedParentData);
						//$("#allParentRowVerified").html(verifiedParentData);
						
						
						/* $("#allParentRow").tooltip({
							selector: "[data-toggle='tooltip']",
							container: "body"
						}).popover({
								selector: "[data-toggle='popover']",
								container: "body",
								html: true
							}); */
							
						
						//$('#dp6').datepicker();
						$("[data-toggle='toggle']").bootstrapToggle('destroy');                 
						$("[data-toggle='toggle']").bootstrapToggle();
						
						
					}
					$(".spn_hol").fadeOut('slow');
				}
			});
			
			
			$('#allParentRowUnverified').on('click', '.editParent', function () {
				var parentId = $(this).closest('tr').attr('class');
				$.ajax({
					url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
					type: "GET",
					async: true,
					data: {"flag": "get_parent_profile_data", "school_id": school_id, "parent_id": parentId},
					datatype: 'html',
					success: function (result) {
						console.log(result);
						var decodedJson = jQuery.parseJSON(result);
						var responseMessage = decodedJson.response.response_message;
						var data = decodedJson.response.response_data;
						var parentProfileData = data.profile_info;
						var parent_id = parentProfileData.parent_id;
						var parent_name = parentProfileData.parent_name;
						var parent_email = parentProfileData.parent_email;
						var parent_contact_no = parentProfileData.parent_contact_no;
						var total_childrens = parentProfileData.total_childrens;
						var childrens_id = parentProfileData.childrens_id;
						var profile_image = parentProfileData.profile_image;
						var profile_status = parentProfileData.profile_status;
						var registration_date = parentProfileData.registration_date;
						var parenting_role = parentProfileData.parenting_role;

						$('#parentProfileImage').attr('src', profile_image);
						$('#madalParentName').html(parent_name);
						$('#madalParentEmail').html(parent_email);
						$('#modalParentSignedOn').html(registration_date);
						$('#modalParentRelation').html(parenting_role);
						$('#modalParentContactNumber').html(parent_contact_no);
						if (profile_status == "0") {

							$('#modalParentStatus').html("<span style='color:red;'>Unverified</span>");

						}

						if (profile_status == "1") {

							$('#modalParentStatus').html("<span style='color:green;'>Verified</span>");

						}

						var childrenProfileData = data.childrens;
						/*
						 var class_id = child_classesArray.class_id;
						 var section_id = child_classesArray.section_id;
						 var class_name = child_classesArray.class_name;
						 var section_name = child_classesArray.section_name;*/

						var html = "";
						var completeHtml = '<div class="row"><div class="col-md-9" ><div class="panel panel-default">  <div class="panel-heading">Child Information<input type="hidden" name="parentId" id="parentId" value="' + parent_id + '"></div>  ';
						var counter = 0;
						$.each(childrenProfileData, function (i, currProgram) {

							var child_id = currProgram.child_id;
							var child_name = currProgram.child_name;
							var child_gender = currProgram.child_gender;
							var child_status = currProgram.child_status;
							var admission_number = currProgram.admission_number;
							/*  alert(child_id);
							 alert(child_name);
							 alert(child_gender);
							 alert(admission_number);*/
							var child_classesArray = currProgram.child_classes;

							$.each(child_classesArray, function (i, currChild) {
								var class_id = currChild.class_id;
								var section_id = currChild.section_id;
								var class_name = currChild.class_name;
								var section_name = currChild.section_name;

								var childStatus = '';

								if (child_status) {
									childStatus = '<a href="#" style="margin-top: -5px;" id="' + child_id + '"  onClick="toggleChildStatus(' + child_id + ');" class="btn btn-danger">Block</a>';
								} else {
									childStatus = '<a href="#" style="margin-top: -5px;" id="' + child_id + '" onClick="toggleChildStatus(' + child_id + ');" class="btn btn-primary"> Unblock </a>';
									;
								}
	 
								var html = '<br/><div class="col-md-12"><div class="panel panel-default">  <div class="panel-body"><div class="row"><div class="col-md-4" > <p><span><b>Name : </b></span> <span>' + child_name + '</span></p></div><div class="col-md-3" > <p><span><b>Gender. : </b></span> <span>' + child_gender + '</span></p></div><div class="col-md-5" > <div class="col-md-5" ><span><b>Admission No.: </b></span> </div><div class="col-md-7" ><span><input name="adminNo[]" placeholder="Admission No." class="form-control custom-input-box admsearch" style="margin-top: -10px;" value="'+ admission_number +'"></span></div></div></div><hr style="width: 104%;margin-left: -17px;margin-top:0px;"><div class="row"><div class="col-md-4"><div class="form-group"><label>Class</label><input type="text" class="form-control custom-input-box classInput" name="childClassName[]" value="' + class_name + '"></div></div><div class="col-md-4"><div class="form-group"><label>Section</label><input type="hidden" name="childIds[]" value="' + child_id + '"><input type="text" class="form-control custom-input-box sectionInput" name="childSectionName[]" value="' + section_name + '"></div></div><div class="col-md-4"><div class="form-group"><p>&nbsp;</p>' + childStatus + '</div></div></div></div>  </div> </div><div class="clearfix"></div>';
								completeHtml = completeHtml + html;
							});


							counter++;
						});
						completeHtml = completeHtml + " </div></div></div>";
						$('#editParentChildData').html(completeHtml);
						$(".admsearch").autocomplete({
							source: childAdmissionNumList
						});
						$('#editParentData').modal('show');
						$(".classInput").autocomplete({
							source: classJson
						});
						$(".sectionInput").autocomplete({
							source: sectionJson
						});
					}
				});
			});
			
			$('.updateChildClassSection').click(function () {

				var parentId = $('#parentId').val();

				//alert(teacherId);
				var classes = [];
				var sections = [];
				var childIds = [];
				var adminNo = [];

				//form classes data end
				$("input[name='adminNo[]']").map(function () {
					//alert($(this).val());
					adminNo.push($(this).val());
				}).get();
				console.log(adminNo);
				//form classes data end

				//form classes data end
				$("input[name='childClassName[]']").map(function () {
					//alert($(this).val());
					classes.push($(this).val());
				}).get();
				console.log(classes);
				//form classes data end


				//form sections data end
				$("input[name='childSectionName[]']").map(function () {
					//alert($(this).val());
					sections.push($(this).val());
				}).get();
				console.log(sections);
				//form classes data end

				//form subjects data end
				$("input[name='childIds[]']").map(function () {
					//alert($(this).val());
					childIds.push($(this).val());
				}).get();
				console.log(childIds);
				//form classes data end

				swal({
					title: "Are you sure?",
					text: "you want to modify this information?",
					type: "warning",
					showCancelButton: true,
					closeOnConfirm: false,
					confirmButtonText: "Yes, Modify!",
					confirmButtonColor: "#ec6c62"
				}, function () {
					//alert('vikash');
					$.ajax({
						url: "http://localhost/talking_classes_staging/mobile/children/handle",
						type: "GET",
						async: true,
						data: {
							"flag": "update_child_class_section",
							"parent_id": parentId,
							"child_class": classes,
							"child_section": sections,
							"childIds": childIds,
							"adminNo": adminNo
						},
						datatype: 'html',
						success: function (result) {
							//alert('succ');
							var decodedJson = jQuery.parseJSON(result);
							var responseMessage = decodedJson.response.response_message;
							console.log(result);
							if (responseMessage) {
								swal("", "Record Updated Successfully", "success");
							} else {
								swal("", "Issue with updating Information", "error");
							}

							//$('#editParentChildData').modal('hide');
						}
					});
				});
			});
				
			/* $('.updateChildClassSection').click(function () {

				var parentId = $('#parentId').val();

				//alert(teacherId);
				var classes = [];
				var sections = [];
				var childIds = [];
				var adminNo = [];

				//form classes data end
				$("input[name='adminNo[]']").map(function () {
					//alert($(this).val());
					adminNo.push($(this).val());
				}).get();
				console.log(adminNo);
				//form classes data end

				//form classes data end
				$("input[name='childClassName[]']").map(function () {
					//alert($(this).val());
					classes.push($(this).val());
				}).get();
				console.log(classes);
				//form classes data end


				//form sections data end
				$("input[name='childSectionName[]']").map(function () {
					//alert($(this).val());
					sections.push($(this).val());
				}).get();
				console.log(sections);
				//form classes data end

				//form subjects data end
				$("input[name='childIds[]']").map(function () {
					//alert($(this).val());
					childIds.push($(this).val());
				}).get();
				console.log(childIds);
				//form classes data end

				swal({
					title: "Are you sure?",
					text: "you want to modify this information?",
					type: "warning",
					showCancelButton: true,
					closeOnConfirm: false,
					confirmButtonText: "Yes, Modify!",
					confirmButtonColor: "#ec6c62"
				}, function () {
					//alert('vikash');
					$.ajax({
						url: "http://localhost/talking_classes_staging/mobile/children/handle",
						type: "GET",
						async: false,
						data: {
							"flag": "update_child_class_section",
							"parent_id": parentId,
							"child_class": classes,
							"child_section": sections,
							"childIds": childIds,
							"adminNo": adminNo
						},
						datatype: 'html',
						success: function (result) {
							//alert('succ');
							var decodedJson = jQuery.parseJSON(result);
							var responseMessage = decodedJson.response.response_message;
							console.log(result);
							if (responseMessage) {
								swal("", "Record Updated Successfully", "success");
							} else {
								swal("", "Issue with updating Information", "error");
							}

							//$('#editParentChildData').modal('hide');
						}
					});
				});
			 });*/
			
			// Unverified Parent List End		
			
		} else if(cityName == "PLVerified"){
			alert('PLVerified');
			
			$(".spn_hol").fadeIn('slow');
			// Verified Parent List Start
			
				// Unverified Parent List Start
				$(".parentListSearch").on("keyup", function () {
				//alert('parent');
				var value = $(this).val().toLowerCase();
				$(".parentTable tr").filter(function () {
					$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
				});
			});

			
			
				// alert(school_id);
			$.ajax({
				url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
				type: "GET",
				async: true,
				data: {"flag": "get_school_parents_verified", "school_id": school_id,"school_branch":schoolBranchId},
				datatype: 'html',
				success: function (result) {
					console.log("Get School Parent get_school_parents_verified Query");
					console.log(result);
					var decodedJson = jQuery.parseJSON(result);
					var responseMessage = decodedJson.response.response_message;
					var responseStatus = decodedJson.response.response_status;
					var data = decodedJson.response.response_data;
					//console.log(data);
					
					if (responseStatus) {
						
						var allParentRow = "";

						var countAll = 1;
						var countUnverified = 1;
						var countVerfied = 1;
						var unverifiedParentData;
						var allParentData;
						var verifiedParentData;
						$.each(data, function (i, currProgram) {
							// alert(currProgram.profile_status);
							if (currProgram.profile_status == 1) {
								
								var allParentRow = "<tr id='' class='" + currProgram.parent_id + "'><td><img src='" + currProgram.profile_image + "' alt='' class='img-circle img-responsive' style='width:35px;height:35px;'></td><td>" + currProgram.parent_name + "</td><td><div class='multiple_elements'><a href='#' class='ole two' data-toggle='tooltip' data-placement='top' data-original-title='" + currProgram.child_name + "'>" + currProgram.total_childrens + "</a></div></td><td>" + currProgram.registration_date + "</td><td><input checked data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td>" + currProgram.parenting_role + "</td><td><a class='grey editParent'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> </td></tr>";
								verifiedParentData = verifiedParentData + allParentRow;
								countVerfied = countVerfied + 1;

								 var allParentRowData = "<tr id='' class='" + currProgram.parent_id + "'><td><img src='" + currProgram.profile_image + "' alt='' class='img-circle img-responsive' style='width:35px;height:35px;'></td><td>" + currProgram.parent_name + "</td><td><div class='multiple_elements'><a href='#' class='ole two' data-toggle='tooltip' data-placement='top' data-original-title='" + currProgram.child_name + "'>" + currProgram.total_childrens + "</a></div></td><td>" + currProgram.registration_date + "</td><td><input checked data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td>" + currProgram.parenting_role + "</td><td> <a class='grey editParent'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> </td></tr>";
								allParentData = allParentData + allParentRowData;

								countAll = countAll + 1; 
							} 
						});

						//$("#allParentRow").html(allParentData);
						// $("#allParentRowUnverified").html(unverifiedParentData);
						$("#allParentRowVerified").html(verifiedParentData);
						
						
						/* $("#allParentRow").tooltip({
							selector: "[data-toggle='tooltip']",
							container: "body"
						}).popover({
								selector: "[data-toggle='popover']",
								container: "body",
								html: true
							}); */
							
						
						//$('#dp6').datepicker();
						$("[data-toggle='toggle']").bootstrapToggle('destroy');                 
						$("[data-toggle='toggle']").bootstrapToggle();
						
						
					}
					$(".spn_hol").fadeOut('slow');
				}
			});
			
			
			$('#allParentRowVerified').on('click', '.editParent', function () {
				var parentId = $(this).closest('tr').attr('class');
				$.ajax({
					url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
					type: "GET",
					async: true,
					data: {"flag": "get_parent_profile_data", "school_id": school_id, "parent_id": parentId},
					datatype: 'html',
					success: function (result) {
						console.log(result);
						var decodedJson = jQuery.parseJSON(result);
						var responseMessage = decodedJson.response.response_message;
						var data = decodedJson.response.response_data;
						var parentProfileData = data.profile_info;
						var parent_id = parentProfileData.parent_id;
						var parent_name = parentProfileData.parent_name;
						var parent_email = parentProfileData.parent_email;
						var parent_contact_no = parentProfileData.parent_contact_no;
						var total_childrens = parentProfileData.total_childrens;
						var childrens_id = parentProfileData.childrens_id;
						var profile_image = parentProfileData.profile_image;
						var profile_status = parentProfileData.profile_status;
						var registration_date = parentProfileData.registration_date;
						var parenting_role = parentProfileData.parenting_role;

						$('#parentProfileImage').attr('src', profile_image);
						$('#madalParentName').html(parent_name);
						$('#madalParentEmail').html(parent_email);
						$('#modalParentSignedOn').html(registration_date);
						$('#modalParentRelation').html(parenting_role);
						$('#modalParentContactNumber').html(parent_contact_no);
						if (profile_status == "0") {

							$('#modalParentStatus').html("<span style='color:red;'>Unverified</span>");

						}

						if (profile_status == "1") {

							$('#modalParentStatus').html("<span style='color:green;'>Verified</span>");

						}

						var childrenProfileData = data.childrens;
						/*
						 var class_id = child_classesArray.class_id;
						 var section_id = child_classesArray.section_id;
						 var class_name = child_classesArray.class_name;
						 var section_name = child_classesArray.section_name;*/

						var html = "";
						var completeHtml = '<div class="row"><div class="col-md-9" ><div class="panel panel-default">  <div class="panel-heading">Child Information<input type="hidden" name="parentId" id="parentId" value="' + parent_id + '"></div>  ';
						var counter = 0;
						$.each(childrenProfileData, function (i, currProgram) {

							var child_id = currProgram.child_id;
							var child_name = currProgram.child_name;
							var child_gender = currProgram.child_gender;
							var child_status = currProgram.child_status;
							var admission_number = currProgram.admission_number;
							/*  alert(child_id);
							 alert(child_name);
							 alert(child_gender);
							 alert(admission_number);*/
							var child_classesArray = currProgram.child_classes;

							$.each(child_classesArray, function (i, currChild) {
								var class_id = currChild.class_id;
								var section_id = currChild.section_id;
								var class_name = currChild.class_name;
								var section_name = currChild.section_name;

								var childStatus = '';

								if (child_status) {
									childStatus = '<a href="#" style="margin-top: -5px;" id="' + child_id + '"  onClick="toggleChildStatus(' + child_id + ');" class="btn btn-danger">Block</a>';
								} else {
									childStatus = '<a href="#" style="margin-top: -5px;" id="' + child_id + '" onClick="toggleChildStatus(' + child_id + ');" class="btn btn-primary"> Unblock </a>';
									;
								}
	 
								var html = '<br/><div class="col-md-12"><div class="panel panel-default">  <div class="panel-body"><div class="row"><div class="col-md-4" > <p><span><b>Name : </b></span> <span>' + child_name + '</span></p></div><div class="col-md-3" > <p><span><b>Gender. : </b></span> <span>' + child_gender + '</span></p></div><div class="col-md-5" > <div class="col-md-5" ><span><b>Admission No.: </b></span> </div><div class="col-md-7" ><span><input name="adminNo[]" placeholder="Admission No." class="form-control custom-input-box admsearch" style="margin-top: -10px;" value="'+ admission_number +'"></span></div></div></div><hr style="width: 104%;margin-left: -17px;margin-top:0px;"><div class="row"><div class="col-md-4"><div class="form-group"><label>Class</label><input type="text" class="form-control custom-input-box classInput" name="childClassName[]" value="' + class_name + '"></div></div><div class="col-md-4"><div class="form-group"><label>Section</label><input type="hidden" name="childIds[]" value="' + child_id + '"><input type="text" class="form-control custom-input-box sectionInput" name="childSectionName[]" value="' + section_name + '"></div></div><div class="col-md-4"><div class="form-group"><p>&nbsp;</p>' + childStatus + '</div></div></div></div>  </div> </div><div class="clearfix"></div>';
								completeHtml = completeHtml + html;
							});


							counter++;
						});
						completeHtml = completeHtml + " </div></div></div>";
						$('#editParentChildData').html(completeHtml);
						$(".admsearch").autocomplete({
							source: childAdmissionNumList
						});
						$('#editParentData').modal('show');
						$(".classInput").autocomplete({
							source: classJson
						});
						$(".sectionInput").autocomplete({
							source: sectionJson
						});
					}
				});
			});
			
			$('.updateChildClassSection').click(function () {

				var parentId = $('#parentId').val();

				//alert(teacherId);
				var classes = [];
				var sections = [];
				var childIds = [];
				var adminNo = [];

				//form classes data end
				$("input[name='adminNo[]']").map(function () {
					//alert($(this).val());
					adminNo.push($(this).val());
				}).get();
				console.log(adminNo);
				//form classes data end

				//form classes data end
				$("input[name='childClassName[]']").map(function () {
					//alert($(this).val());
					classes.push($(this).val());
				}).get();
				console.log(classes);
				//form classes data end


				//form sections data end
				$("input[name='childSectionName[]']").map(function () {
					//alert($(this).val());
					sections.push($(this).val());
				}).get();
				console.log(sections);
				//form classes data end

				//form subjects data end
				$("input[name='childIds[]']").map(function () {
					//alert($(this).val());
					childIds.push($(this).val());
				}).get();
				console.log(childIds);
				//form classes data end

				swal({
					title: "Are you sure?",
					text: "you want to modify this information?",
					type: "warning",
					showCancelButton: true,
					closeOnConfirm: false,
					confirmButtonText: "Yes, Modify!",
					confirmButtonColor: "#ec6c62"
				}, function () {
					//alert('vikash');
					$.ajax({
						url: "http://localhost/talking_classes_staging/mobile/children/handle",
						type: "GET",
						async: true,
						data: {
							"flag": "update_child_class_section",
							"parent_id": parentId,
							"child_class": classes,
							"child_section": sections,
							"childIds": childIds,
							"adminNo": adminNo
						},
						datatype: 'html',
						success: function (result) {
							//alert('succ');
							var decodedJson = jQuery.parseJSON(result);
							var responseMessage = decodedJson.response.response_message;
							console.log(result);
							if (responseMessage) {
								swal("", "Record Updated Successfully", "success");
							} else {
								swal("", "Issue with updating Information", "error");
							}

							//$('#editParentChildData').modal('hide');
						}
					});
				});
			});
			
			// Verified Parent List End
			
		} else if(cityName == "AddParent"){
			//alert('AddParent');
		}
	
	}


    function openRP(evt, cityName) {
        var i, tabcontentRP, tablinks;
        tabcontentRP = document.getElementsByClassName("tabcontentRP");
        for (i = 0; i < tabcontentRP.length; i++) {
            tabcontentRP[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
		
		
		// Review post click query
		var sid = schoolSessionId;
		var branid = schoolSessionBranchId;
		
		if(cityName == "AllPost"){
			$(".spn_hol").fadeIn('slow');
			
			$.ajax({
				url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
				type: "GET",
				async: true,
				data: {"flag": "get_post", "school_id": sid, "branch_id": branid},
				datatype: 'html',
				success: function (result) {
					//alert('succ');
					//console.log("Get Post Data")
					//console.log(result);
					var decodedJson = jQuery.parseJSON(result);
					var responseMessage = decodedJson.response.response_message;
					var responseStatus = decodedJson.response.response_status;
					var reviewPostdata = decodedJson.response.response_data;

					if (responseStatus) {
						//swal("", "Record Updated Successfully", "success");
						var reviewPostContBlank = "";
						var reviewPostdataLenth = reviewPostdata.length;
						// alert(reviewPostdataLenth);
						$.each(reviewPostdata, function (i, currPostData) {
							
							var postStatus = '';

							if (currPostData.status == "1") {
								postStatus = '<button id="' + currPostData.is_admin_post + '-' + currPostData.id + '" class="btn btn-danger pull-right postStatustoggle blc">Block</button>';
							} else {
								postStatus = '<button id="' + currPostData.is_admin_post + '-' + currPostData.id + '" class="btn btn-default pull-right postStatustoggle ublc">Unblock</button>';
							}
							

							var parentClasses = "";

							if (currPostData.is_child == "1") {
								parentClasses = 'parentClass';
							}

							var teacherClasses = "";
							if (currPostData.is_teacher == "1") {
								teacherClasses = 'teacherClass';
							}

							var str = currPostData.post_content;
							//alert(str);
							//alert();
							var newStr = str.unquoted();
							var trimmedString = newStr.substring(0,35);
							//alert(trimmedString);
							/*var	str1 = $(str).text();

							 if(str1.length > 10) str1 = str1.substring(0,20);	*/

							var post_images = "";

							if (currPostData.post_image != "") {
								var post_images = '<img src="' + currPostData.post_image + '" class="reviewPostImg" />';
							}
							// alert(post_images);
							var reviewPostCont = "";

							if (i == 0) {
								reviewPostCont = '<div class="row">';
							}

							if ((i % 4) == 0) {
								reviewPostCont = reviewPostCont + '</div><div class="row">';
							}

							reviewPostCont = reviewPostCont + '<div id="' + currPostData.id + '" class="col-md-3 content1"><div class="panel panel-default"><div class="panel-body"><div class="row" style="border-bottom: 1px solid #e1d9d9"><div class="col-md-4"><span style="border:1px solid #555 !important;border-radius:45% !important;padding:6px;" class="categoryTitleClass">' + currPostData.category_name + '</span></div><div class="col-md-8"><p><span class="' + parentClasses + ' ' + teacherClasses + '" ><b>' + currPostData.name + '</b></span></p></div></div><div class="row"><div class="col-md-12"><p class="paddingImgPtag">' + post_images + '</p><div>' + trimmedString + '......<div class="clearfix"></div></div></div></div></div><div class="panel-footer"><section><button id="' + currPostData.is_admin_post + '-' + currPostData.id + '" class="btn btn-primary viewReviewPost">View</button>' + postStatus + '</section></div></div></div>';
							if ((i + 1) == reviewPostdataLenth) {
								reviewPostCont = reviewPostCont + '</div>';
							}

							reviewPostContBlank = reviewPostContBlank + reviewPostCont;

						});

						$('#reviewvPostContentDiv').html(reviewPostContBlank);
						
					} else {
						//swal("", "Issue with updating Information", "error");
					}
					$(".spn_hol").fadeOut('slow');
					//$('#editParentChildData').modal('hide');
				}
			});
			
			//$('.viewReviewPost').click(function () {
				$('#reviewvPostContentDiv').on('click', '.viewReviewPost', function () {
				//alert('viewReviewPost');
				var user_post;
				var post_data = $(this).attr('id');
				var res = post_data.split("-");


				var admin_post = res[0];
				var post_ids = res[1];
				//alert(post_ids);
				// alert(admin_post);
				if (admin_post == "true") {
					admin_post = true;
					user_post = false;
					// alert(user_post);

				} else {
					//alert("admin post false");
					user_post = true;
					admin_post = false;
					// alert(user_post);
					//alert("user post true");
				}

				$.ajax({
					url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
					type: "GET",
					async: true,
					data: {
						"flag": "view_post_details",
						"admin_post": admin_post,
						"user_post": user_post,
						"post_id": post_ids
					},
					datatype: 'html',
					success: function (result) {
						console.log(result);
						var decodedJson = jQuery.parseJSON(result);
						var responseMessage = decodedJson.response.response_message;
						var responseStatus = decodedJson.response.response_status;
						var reviewPostdata = decodedJson.response.response_data;

						$('.categoryTitleClassDetails').html("");
						$('.viewDetailsName').html("");
						$('#viewDetailsContent').html("");

						$('#viewDetailsImg').html("");


						$('.categoryTitleClassDetails').html(reviewPostdata.category_name);
						$('.viewDetailsName').html('<b>' + reviewPostdata.name + '</b>');
						$('#viewDetailsContent').html(reviewPostdata.post_content);
						if (reviewPostdata.post_image != "") {
							$('#viewDetailsImg').html('<img src="' + reviewPostdata.post_image + '" style="width: 260px;" class="reviewPostImg">');
						}
						
						$('#viewReviewPostClick').modal('show');
	
					},complete: function() {
						$(this).data('requestRunning', false);
					}
				});
			});
			
			//$('.postStatustoggle').click(function () {
				$('#reviewvPostContentDiv').on('click', '.postStatustoggle', function () {
				//alert('as');
				var $this = $(this);
				
				var user_post;
				var post_data = $(this).attr('id');
				var res = post_data.split("-");


				var admin_post = res[0];
				var post_ids = res[1];
				//alert(post_ids);
				// alert(admin_post);
				if (admin_post == "true") {
					admin_post = true;
					user_post = false;
					//alert(user_post);

				} else {
					//alert("admin post false");
					user_post = true;
					admin_post = false;
					//alert(user_post);
					//alert("user post true");
				}

				$.ajax({
					url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
					type: "GET",
					async: true,
					data: {
						"flag": "toggle_post_status",
						"admin_post": admin_post,
						"user_post": user_post,
						"post_id": post_ids
					},
					datatype: 'html',
					success: function (result) {
						console.log(result);
						
						//alert(post_ids);
							 
							if($this.hasClass('blc')){
								$this.removeClass();
								$this.addClass('btn btn-default pull-right postStatustoggle ublc');
								$this.text('Unblock');         
							} else {
								$this.removeClass();
								$this.addClass('btn btn-danger pull-right postStatustoggle blc');
								$this.text('Block');
							}
							
						
					},complete: function() {
						$(this).data('requestRunning', false);
					}
				});

			});
			
		}
		if(cityName == "blockedReviewPost"){
			//alert(cityName);
			
			$(".spn_hol").fadeIn('slow');
			
			$.ajax({
				url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
				type: "GET",
				async: true,
				data: {"flag": "get_block_post", "school_id": sid, "branch_id": branid},
				datatype: 'html',
				success: function (result) {
					//alert('succ');
					//console.log("Get Post Data")
					//console.log(result);
					var decodedJson = jQuery.parseJSON(result);
					var responseMessage = decodedJson.response.response_message;
					var responseStatus = decodedJson.response.response_status;
					var reviewPostdata = decodedJson.response.response_data;

					if (responseStatus) {
						//swal("", "Record Updated Successfully", "success");
						var reviewPostContBlank = "";
						var reviewPostdataLenth = reviewPostdata.length;
						// alert(reviewPostdataLenth);
						$.each(reviewPostdata, function (i, currPostData) {
							
							var postStatus = '';

							if (currPostData.status == "1") {
								postStatus = '<button id="' + currPostData.is_admin_post + '-' + currPostData.id + '" class="btn btn-danger pull-right postStatustoggleBlock blc">Block</button>';
							} else {
								postStatus = '<button id="' + currPostData.is_admin_post + '-' + currPostData.id + '" class="btn btn-default pull-right postStatustoggleBlock ublc">Unblock</button>';
							}
							

							var parentClasses = "";

							if (currPostData.is_child == "1") {
								parentClasses = 'parentClass';
							}

							var teacherClasses = "";
							if (currPostData.is_teacher == "1") {
								teacherClasses = 'teacherClass';
							}

							var str = currPostData.post_content;
							//alert(str);
							//alert();
							var newStr = str.unquoted();
							var trimmedString = newStr.substring(0,45);
							//alert(trimmedString);
							/*var	str1 = $(str).text();

							 if(str1.length > 10) str1 = str1.substring(0,20);	*/

							var post_images = "";

							if (currPostData.post_image != "") {
								var post_images = '<img src="' + currPostData.post_image + '" class="reviewPostImg" />';
							}
							// alert(post_images);
							var reviewPostCont = "";

							if (i == 0) {
								reviewPostCont = '<div class="row">';
							}

							if ((i % 4) == 0) {
								reviewPostCont = reviewPostCont + '</div><div class="row">';
							}

							reviewPostCont = reviewPostCont + '<div id="' + currPostData.id + '" class="col-md-3 content1"><div class="panel panel-default"><div class="panel-body"><div class="row" style="border-bottom: 1px solid #e1d9d9"><div class="col-md-4"><span style="border:1px solid #555 !important;border-radius:45% !important;padding:6px;" class="categoryTitleClass">' + currPostData.category_name + '</span></div><div class="col-md-8"><p><span class="' + parentClasses + ' ' + teacherClasses + '" ><b>' + currPostData.name + '</b></span></p></div></div><div class="row"><div class="col-md-12"><p class="paddingImgPtag">' + post_images + '</p><div>' + trimmedString + '......<div class="clearfix"></div></div></div></div></div><div class="panel-footer"><section><button id="' + currPostData.is_admin_post + '-' + currPostData.id + '" class="btn btn-primary viewReviewPostBlock">View</button>' + postStatus + '</section></div></div></div>';
							if ((i + 1) == reviewPostdataLenth) {
								reviewPostCont = reviewPostCont + '</div>';
							}

							reviewPostContBlank = reviewPostContBlank + reviewPostCont;

						});

						$('#reviewvPostContentDivBlock').html(reviewPostContBlank);
						
					} else {
						//swal("", "Issue with updating Information", "error");
					}
					$(".spn_hol").fadeOut('slow');
					//$('#editParentChildData').modal('hide');
				}
			});
			
				
				
			$('#reviewvPostContentDivBlock').on('click', '.viewReviewPostBlock', function () {
				//alert('viewReviewPost');
				var user_post;
				var post_data = $(this).attr('id');
				var res = post_data.split("-");


				var admin_post = res[0];
				var post_ids = res[1];
				//alert(post_ids);
				// alert(admin_post);
				if (admin_post == "true") {
					admin_post = true;
					user_post = false;
					// alert(user_post);

				} else {
					//alert("admin post false");
					user_post = true;
					admin_post = false;
					// alert(user_post);
					//alert("user post true");
				}

				$.ajax({
					url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
					type: "GET",
					async: true,
					data: {
						"flag": "view_post_details",
						"admin_post": admin_post,
						"user_post": user_post,
						"post_id": post_ids
					},
					datatype: 'html',
					success: function (result) {
						console.log(result);
						var decodedJson = jQuery.parseJSON(result);
						var responseMessage = decodedJson.response.response_message;
						var responseStatus = decodedJson.response.response_status;
						var reviewPostdata = decodedJson.response.response_data;

						$('.categoryTitleClassDetails').html("");
						$('.viewDetailsName').html("");
						$('#viewDetailsContent').html("");

						$('#viewDetailsImg').html("");


						$('.categoryTitleClassDetails').html(reviewPostdata.category_name);
						$('.viewDetailsName').html('<b>' + reviewPostdata.name + '</b>');
						$('#viewDetailsContent').html(reviewPostdata.post_content);
						if (reviewPostdata.post_image != "") {
							$('#viewDetailsImg').html('<img src="' + reviewPostdata.post_image + '" style="width: 260px;" class="reviewPostImg">');
						}
						$('#viewReviewPostClick').modal('show');
					},complete: function() {
						$(this).data('requestRunning', false);
					}
				});
				//

				
			});
			
		//$('.postStatustoggle').click(function () {
				$('#reviewvPostContentDivBlock').on('click', '.postStatustoggleBlock', function () {
				//alert('as');
				var $this = $(this);
				
				var user_post;
				var post_data = $(this).attr('id');
				var res = post_data.split("-");


				var admin_post = res[0];
				var post_ids = res[1];
				//alert(post_ids);
				// alert(admin_post);
				if (admin_post == "true") {
					admin_post = true;
					user_post = false;
					//alert(user_post);

				} else {
					//alert("admin post false");
					user_post = true;
					admin_post = false;
					//alert(user_post);
					//alert("user post true");
				}

				$.ajax({
					url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
					type: "GET",
					async: true,
					data: {
						"flag": "toggle_post_status",
						"admin_post": admin_post,
						"user_post": user_post,
						"post_id": post_ids
					},
					datatype: 'html',
					success: function (result) {
						console.log(result);
						
						//alert(post_ids);
							 
							if($this.hasClass('blc')){
								$this.removeClass();
								$this.addClass('btn btn-default pull-right postStatustoggle');
								$this.text('Unblock');         
							} else {
								$this.removeClass();
								$this.addClass('btn btn-danger pull-right postStatustoggle');
								$this.text('Block');
							}
							
						
					},complete: function() {
						$(this).data('requestRunning', false);
					}
				});

			});
		
				
		}
			
			
		// Review post click query
		
		
    }

    

    function openGallery(evt, cityName) {
        var i, tabcontentGallery, tablinks;
        tabcontentGallery = document.getElementsByClassName("tabcontentGallery");
        for (i = 0; i < tabcontentGallery.length; i++) {
            tabcontentGallery[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }

    document.getElementById("defaultOpenGallery").click();



    $(document).on('change','.select-post-category',function(){

        postCategory = $(".select-post-category option:selected").val();
        //alert(postCategory);
        $(".postview_category").html($(".select-post-category option:selected").text());

    });
    $(document).on('change', '#select_updatepost_category', function () {

        updatePostCategory = $("#select_updatepost_category option:selected").val();
        //alert(postCategory);
        $(".updatepost_postview_category").html($("#select_updatepost_category option:selected").text());

    });

    $(document).on('click','.album-thumb-image',function(){
            //alert($(this).attr("albumId"))
            $(".album-container").hide();
            $(".album-items-container").show();
            $(".item-container-album-name").html("Album Name : "+$(this).attr("albumName"));
            $(".add-album-item-button").attr("albumid",$(this).attr('albumId'));
    });
    $(document).on('click','.back-to-album',function(){
            $(".album-container").show();
            $(".album-items-conatiner").hide();
    });
</script>
<script>

    // Character Count Ellipsis
    function EllipsisChar(text, size) {
        var len = text.length;
        if (len >= size) {
            // if text length is equal to or more than given size then add ...
            text = text.substring(0, size) + "...";
        }
        else {
            // if text length is less then do something
        }
        return text;
    }
    ;
</script>
<script>
    function chatApiCall(mUrl, id) {

        $('#allContactList > li').removeClass('active');
        $("#" + id).addClass('active');

        // alert(mUrl);

        $.ajax({
            url: mUrl,
            type: "GET",
            async: false,
            //  data: {"flag": "get_school_parents", "school_id": school_id},
            datatype: 'html',
            success: function (result) {
                console.log(result);
                //chat_display_data
                //display_name
                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var responseStatus = decodedJson.response.response_status;
                var data = decodedJson.response.response_data;
                if (responseMessage) {

                    $(".message-input").show();
                    $(".contact-profile").show();
                    var chatDisplayData = data.chat_display_data;
                    var displayPicture = chatDisplayData.display_picture;
                    var display_name = chatDisplayData.display_name;
                    friendIds = chatDisplayData.friend_id;
                    isGroupStatus = chatDisplayData.is_group;
                    chatGroupIds = chatDisplayData.group_id;

                    var chatConversation = data.chat_conversation_data;
                    $('#chatMessageCommunication').html('');
                    $('#clickmessageProfileName').html(display_name);
                    $('#clickmessageProfileSrc').attr('src', displayPicture);

                    $.each(chatConversation, function (i, chatConversationData) {

                        var message_body = chatConversationData.message_body
                        var is_me = chatConversationData.is_me;
                        var user_name = chatConversationData.user_name;
                        var file_url = chatConversationData.file_url;
                        var message_date = chatConversationData.message_date;
                        var message_time = chatConversationData.message_time;


                        if (is_me) {

                            var chatMessage = '<li class="replies"><img src="' + userProfileImage + '" alt="" /><p>' + message_body + '</p></li>';
                        } else {
                            var chatMessage = '<li class="sent"><img src="' + displayPicture + '" alt="" /><p>' + message_body + '</p></li>';
                        }

                        $('#chatMessageCommunication').append(chatMessage);

                    });
                    $(".messages").animate({scrollTop: $(document).height()}, "fast");

                }

            }
        });


    }

    function newMessage() {

// change this user id when calling real data
        var userTemporaryId = '867';
        message = $(".message-input input").val();
        if ($.trim(message) == '') {
            return false;
        }
        if (isGroupStatus == "true") {

            var urlSentUserOneToOne = 'http://localhost/talking_classes_staging/mobile/messages/manage?flag=new_message&user_id=' + userTemporaryId + '&friend_id=' + friendIds + '&message_text=' + message + '&is_text=true&is_pdf=false&is_image=false&content_url=na&is_group=true&group_id=' + chatGroupIds;

            $.ajax({
                url: urlSentUserOneToOne,
                type: "GET",
                async: false,
                // data: {"flag": "get_school_parents", "school_id": school_id},
                datatype: 'html',
                success: function (result) {
                    //alert('response success');
                    var decodedJson = jQuery.parseJSON(result);
                    var responseMessage = decodedJson.response.response_message;
                    if (responseMessage) {
                        $('<li class="replies"><img src="' + userProfileImage + '" alt="" /><p>' + message + '</p></li>').appendTo($('.messages ul'));
                        $('.message-input input').val();
                        $('.contact.active .preview').html('<span>You: </span>' + message);
                        $(".messages").animate({scrollTop: $(document).height()}, "fast");
                    }

                }
            });

        } else {

            var urlSentUserOneToOne = 'http://localhost/talking_classes_staging/mobile/messages/manage?flag=new_message&user_id=' + userTemporaryId + '&friend_id=' + friendIds + '&message_text=' + message + '&is_text=true&is_pdf=false&is_image=false&content_url=na&is_group=false&group_id=' + chatGroupIds;

            $.ajax({
                url: urlSentUserOneToOne,
                type: "GET",
                async: false,
                // data: {"flag": "get_school_parents", "school_id": school_id},
                datatype: 'html',
                success: function (result) {
                    var decodedJson = jQuery.parseJSON(result);
                    var responseMessage = decodedJson.response.response_message;
                    if (responseMessage) {
                        $('<li class="replies"><img src="' + userProfileImage + '" alt="" /><p>' + message + '</p></li>').appendTo($('.messages ul'));
                        $('.message-input input').val();
                        $('.contact.active .preview').html('<span>You: </span>' + message);
                        $(".messages").animate({scrollTop: $(document).height()}, "fast");
                    }

                }
            });
        }

    }
    ;

    $('.submit').click(function () {
        newMessage();
    });

    $(window).on('keydown', function (e) {
        if (e.which == 13) {
            newMessage();
            return false;
        }
    });
    //# sourceURL=pen.js
</script>

<!--<script src="js/vtteacher.js"></script>-->
<!--Teacher Javascript Start Here-->
<script>
    function getPosts() {
        $.ajax({
            url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
            type: "GET",
            async: false,
            data: {"flag": "get_specific_admin_post", "user_id": <?php  echo $_SESSION["userId"] ?>},
            datatype: 'jsonp',
            success: function (result) {
                //console.log(result);
                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var data = decodedJson.response.response_data;
                $(".postslist").html('');
                $.each(data, function (i, currProgram) {
                    var imageUrl = currProgram.post_isimage ? "" : "No Image";
                    var pdfUrl = currProgram.post_ispdf ? "" : "No Pdf";
                    $(".postslist").append("<tr >" +
                        "<td class='tableitems'><div style='padding:10px;'>" + EllipsisChar(currProgram.post_content, 40) + "</div></td>" +
                        "<td class='tableitems'>" + currProgram.post_category + "</td>" +
                        "<td class='tableitems'>" + currProgram.post_for + "</td>" +
                        "<td class='tableitems'>" + currProgram.post_date + "</td>" +
                        "<td class='tableitems'>" + imageUrl + "</td>" +
                        "<td class='tableitems'>" + pdfUrl + "</td>" +
                        "<td class='tableitems'><a class='grey editPost' postcategory='" + currProgram.post_category + "' postcontent='" + currProgram.post_content + "' postfor='" + currProgram.post_for + "' imageurl= '" + imageUrl + "' pdfurl = '" + pdfUrl + "' dataid='" + currProgram.post_id + "'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> || <a class='grey deletePost' onClick='removePost(" + currProgram.post_id + ")' href='#'><i class='fa fa-trash'></i></a></td>" +
                        "</tr>");
                });
            }
        });
    }

    function removePost(postId) {

        swal({
            title: "Are you sure?",
            text: "You want to remove this post",
            type: "warning",
            showCancelButton: true,
            closeOnConfirm: true,
            closeOnCancel: true,
            confirmButtonText: "Ok",
            confirmButtonColor: "#ec6c62"
        }, function () {
            $.ajax({
                url: "http://localhost/talking_classes_staging/schooladmin/schools/manage?flag=remove_admin_post",
                type: "GET",
                async: true,
                data: {"post_id": postId},
                datatype: 'html',
                success: function (result) {
                    var decodedJson = jQuery.parseJSON(result);
                    var responseMessage = decodedJson.response.response_message;
                    var responseStatus = decodedJson.response.response_status;
                    if (responseStatus === true) {
                       // alert("Post removed Successfully!");
                        getPosts();
                    } else {
                        alert("Error while removing post. Try again");
                    }
                }
            });
        });
    }

    var updatePostId;
    var updatePostCategory;
    var updatePostContent;
    var updatePostImage;
    var updatePostPdf;
    var updatePostFor;
    $(document).on('click', '.editPost', function () {
        $("#editPostData").modal("show");
        updatePostId = $(this).attr("dataid");
        updatePostContent = $(this).attr("postcontent");
        updatePostImage = $(this).attr("imageUrl");
        updatePostPdf = $(this).attr("pdfurl");
        updatePostFor = $(this).attr("postfor");
        updatePostCategory = $(this).attr("postcategory");

        $("#updatepost_content_text").html(updatePostContent);
        $(".updatepost_postview_content").html(updatePostContent);
        $("#select_updatepost_category option").each(function () {
            if ($(this).html() == updatePostCategory) {
                $(this).attr("selected", "selected");
                return;
            }
        });

        /* $("#select_updatepost_category").find("option[text=" + updatePostCategory + "]").attr("selected", true);*/
        //alert(updatePostId+" ,"+updatePostContent+" ,"+updatePostImage+" ,"+updatePostPdf+" ,"+updatePostFor);
    });

    $(document).ready(function () {
        var school_id = schoolSessionId;
        var schoolBranchId = schoolSessionBranchId;
		//alert(schoolBranchId);
        // alert(school_id);
 
    });
    function toggleChildStatus(chilIds) {
        alert(chilIds);
        swal({
            title: "Are you sure?",
            text: "You want to block this child?",
            type: "warning",
            showCancelButton: true,
            closeOnConfirm: false,
            confirmButtonText: "Yes, Block it!",
            confirmButtonColor: "#ec6c62"
        }, function () {
            $.ajax({
                url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
                type: "GET",
                async: false,
                data: {"flag": "toggle_child_status", "child_id": chilIds},
                datatype: 'html',
                success: function (result) {
                    //alert('succ');
                    swal("", "Record Updated Successfully", "success");

                   // $('.' + parentId).hide(1000);
                    $('#editParentChildData').modal('hide');
                }
            });
        });
    }
    $.ajax({
        url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
        type: "GET",
        async: false,
        data: {"flag": "get_specific_admin_post", "user_id": <?php  echo $_SESSION["userId"] ?>},
        datatype: 'jsonp',
        success: function (result) {
            //console.log(result);
            var decodedJson = jQuery.parseJSON(result);
            var responseMessage = decodedJson.response.response_message;
            var data = decodedJson.response.response_data;
            $.each(data, function (i, currProgram) {
                var imageUrl = currProgram.post_isimage ? "" : "No Image";
                var pdfUrl = currProgram.post_ispdf ? "" : "No Pdf";
                $(".postslist").append("<tr >" +
                    "<td class='tableitems'><div style='padding:10px;'>" + EllipsisChar(currProgram.post_content, 40) + "</div></td>" +
                    "<td class='tableitems'>" + currProgram.post_category + "</td>" +
                    "<td class='tableitems'>" + currProgram.post_for + "</td>" +
                    "<td class='tableitems'>" + currProgram.post_date + "</td>" +
                    "<td class='tableitems'>" + imageUrl + "</td>" +
                    "<td class='tableitems'>" + pdfUrl + "</td>" +
                    "<td class='tableitems'><a class='grey editPost'  postcategory='" + currProgram.post_category + "' postcontent='" + currProgram.post_content + "' postfor='" + currProgram.post_for + "' imageurl= '" + imageUrl + "' pdfurl = '" + pdfUrl + "' dataid='" + currProgram.post_id + "'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> || <a class='grey deletePost' onClick='removePost(" + currProgram.post_id + ")' href='#'><i class='fa fa-trash'></i></a></td>" +
                    "</tr>");
            });
        }
    });
</script>
<script>
    /********************** Review Post Script**************************/
    $(document).ready(function () {
        //  teacherClass 
        //  

        $('#teacherSearchInput').keyup(function () {

            // Search text
            var text = $(this).val().toLowerCase();

            // Hide all content class element
            $('.content1').hide();

            /********** Category Search Start ********/
            var categorySearchInput = $('#categorySearchInput').val();
            //alert(categorySearchInput);

            if (categorySearchInput != "") {

                $('.content1 .categoryTitleClass').each(function () {

                    if ($(this).text().toLowerCase().indexOf("" + categorySearchInput + "") != -1) {
                        $(this).closest('.content1').show();
                    }
                });

            }


            /********** Category Search End ************/

            /********** Parent Search Start *********/
            var parentSearchInput = $('#parentSearchInput').val();
            //alert(parentSearchInput);

            if (parentSearchInput != "") {
                $('.content1 .parentClass').each(function () {

                    if ($(this).text().toLowerCase().indexOf("" + parentSearchInput + "") != -1) {
                        $(this).closest('.content1').show();
                    }
                });
            }


            /********** Parent Search End *********/


            // Search 
            $('.content1 .teacherClass').each(function () {

                if ($(this).text().toLowerCase().indexOf("" + text + "") != -1) {
                    $(this).closest('.content1').show();
                }
            });
        });

        $('#parentSearchInput').keyup(function () {

            // Search text
            var text = $(this).val().toLowerCase();

            // Hide all content class element
            $('.content1').hide();

            /********** Category Search Start ********/
            var categorySearchInput = $('#categorySearchInput').val();
            //alert(categorySearchInput);

            if (categorySearchInput != "") {

                $('.content1 .categoryTitleClass').each(function () {

                    if ($(this).text().toLowerCase().indexOf("" + categorySearchInput + "") != -1) {
                        $(this).closest('.content1').show();
                    }
                });

            }

            /********** Category Search End ************/

            /********** Teacher Search Start *********/
            var teacherSearchInput = $('#teacherSearchInput').val();

            if (teacherSearchInput != "") {

                $('.content1 .teacherClass').each(function () {

                    if ($(this).text().toLowerCase().indexOf("" + teacherSearchInput + "") != -1) {
                        $(this).closest('.content1').show();
                    }
                });

            }

            /********** Teacher Search End *********/

            // Search  
            $('.content1 .parentClass').each(function () {

                if ($(this).text().toLowerCase().indexOf("" + text + "") != -1) {
                    $(this).closest('.content1').show();
                }
            });
        });

        $('#categorySearchInput').keyup(function () {

            // Search text
            var text = $(this).val().toLowerCase();

            // Hide all content class element
            $('.content1').hide();

            /********** Teacher Search Start *********/
            var teacherSearchInput = $('#teacherSearchInput').val();

            if (teacherSearchInput != "") {

                $('.content1 .teacherClass').each(function () {

                    if ($(this).text().toLowerCase().indexOf("" + teacherSearchInput + "") != -1) {
                        $(this).closest('.content1').show();
                    }
                });

            }

            /********** Teacher Search End *********/

            /********** Parent Search Start *********/
            var parentSearchInput = $('#parentSearchInput').val();
            //alert(parentSearchInput);

            if (parentSearchInput != "") {
                $('.content1 .parentClass').each(function () {

                    if ($(this).text().toLowerCase().indexOf("" + parentSearchInput + "") != -1) {
                        $(this).closest('.content1').show();
                    }
                });
            }

            /********** Parent Search End *********/

            // Search 
            $('.content1 .categoryTitleClass').each(function () {

                if ($(this).text().toLowerCase().indexOf("" + text + "") != -1) {
                    $(this).closest('.content1').show();
                }
            });
        });
		
		

       $('.adminList').on('click', '.viewUserDetailsClick', function() {
            var ids = $(this).attr('id');
           //alert(ids);
            $('#clickSchoolUserId').val(ids);
            $('#schoolUserImages').val('');
			$('#schoolUserImagePreview').css('background-image', 'url("")');
            $.ajax({
                url: "http://localhost/talking_classes_staging/schooladmin/schools/manage?flag=get_school_user_profile&user_id="+ids,
                type: "POST",
                async: false,
                data: {"user_id": ids},
                datatype: 'html',
                success: function (result) {
                    console.log(result);
                    var decodedJson = jQuery.parseJSON(result);
                    var responseMessage = decodedJson.response.response_message;
                    var responseStatus = decodedJson.response.response_status;
                    var userdatas = decodedJson.response.response_data;
                    if (responseStatus) {

                        var schoolUserFirstName = $('#schoolUserFirstName').val(userdatas.user_firstname);
                        var schoolUserLastName = $('#schoolUserLastName').val(userdatas.user_lastname);
                        var schoolUserDesignation = $('#schoolUserDesignation').val(userdatas.user_designation);
                        var schoolUserNewPassword = $('#schoolUserNewPassword').val(userdatas.user_password);
                     //   var schoolUserImages = $('#schoolUserImages').val(userdatas.schoolUserImages);
                        var schoolUserMobile = $('#schoolUserMobile').val(userdatas.user_contactno);

                        $('#schoolUserImagePreview').css('background-image', 'url(' + userdatas.user_image+"?"+$.now() + ')');
                    }
                }
            });

            $('#viewSchoolUserDetails').modal('show');
          
             
            //schoolUserMobile schoolUserLogo  schoolUserImages schoolUserNewPassword schoolUserDesignation   schoolUserLastName schoolUserFirstName
            

        });


        $('#schooUserProfileUpdateClick').click(function () {
            //alert('editProfileUpdateClick"');
            var clickSchoolUserId = $('#clickSchoolUserId').val();
            var schoolUserFirstName = $('#schoolUserFirstName').val();
            var schoolUserLastName = $('#schoolUserLastName').val();
            var schoolUserDesignation = $('#schoolUserDesignation').val();
            var schoolUserNewPassword = $('#schoolUserNewPassword').val();
            var schoolUserMobile = $('#schoolUserMobile').val();
            var schoolUserImages = $('#schoolUserImages').val();

            $.ajax({
                url: "http://localhost/talking_classes_staging/schooladmin/schools/manage?flag=update_school_user_profile",
                type: "post",
                async: false,
                data: {
                    "user_id": clickSchoolUserId,
                    "firstName": schoolUserFirstName,
                    "lastName": schoolUserLastName,
                    "userDesignation": schoolUserDesignation,
                    "newPassword": schoolUserNewPassword,
                    "userMobile": schoolUserMobile,
                    "userImages": schoolUserImages
                },
                datatype: 'html',
                success: function (result) {
                    console.log(result);
                    var decodedJson = jQuery.parseJSON(result);
                    var responseMessage = decodedJson.response.response_message;
                    var responseStatus = decodedJson.response.response_status;
                    var responseUserData = decodedJson.response.response_data;
            
                    if (responseStatus) {
                       
                        
                         /*$( "adminUser_"+responseUserData.id).replaceWith( '<tr id="adminUser_'+ responseUserData.id +'"> <td ><img src="'+responseUserData.user_image+'" alt="" style="width: 40px;" /></td> <td>'+ responseUserData.user_firstname +" "+ responseUserData.user_firstname +'</td> <td>'+ responseUserData.user_email +'</td> <td>'+ responseUserData.user_contactno +'</td> <td>'+ responseUserData.created_date +'</td> <td><a class="grey viewUserDetailsClick" id="'+ responseUserData.id +'" href="#"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td> </tr>' );*/
                         $( "#adminUser_"+responseUserData.id).remove();
                         $( ".adminList").prepend('<tr id="adminUser_'+ responseUserData.id +'"> <td ><img src="'+responseUserData.user_image+"?"+$.now()+'" alt="" style="width: 40px;" /></td> <td>'+ responseUserData.user_firstname +" "+ responseUserData.user_lastname +'</td> <td>'+ responseUserData.user_email +'</td> <td>'+ responseUserData.user_designation +'</td> <td>'+ responseUserData.created_date +'</td> <td><a class="grey viewUserDetailsClick" id="'+ responseUserData.id +'" href="#"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td> </tr>');
                         swal("", "Your Information Updated Successfully", "success");
                       
                    } else {
                        swal("", "Issue with updating Information", "error");
                    }
                }
            });
        });


    });

    /********************** Review Post Script**************************/
</script>
<!--Teacher Javascript End Here-->
<script>
    var schoolBaseImage = "";
    $(document).ready(function () {

        function readSchoolURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#imagePreview').css('background-image', 'url(' + e.target.result + ')');
                    $('#imagePreview').hide();
                    $('#imagePreview').fadeIn(650);
                    //alert(e.target.result);

                    $('#schoolHiddenImage').val(e.target.result);
                    schoolBaseImage = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imageUpload").change(function () {

            readSchoolURL(this);
        });

        function readProfileURL(input) {
			//alert('vikash');
            if (input.files && input.files[0]) {
				//alert('kashyap');
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#imagePreview1').css('background-image', 'url(' + e.target.result + ')');
                    $('#imagePreview1').hide();
                    $('#imagePreview1').fadeIn(650);
                    //alert(e.target.result);
                    $('#userImages').val(e.target.result);
                    schoolBaseImage = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imageUpload1").change(function () {

            readProfileURL(this);
        });




    function readSchoolProfileURL(input) {
		//alert('xx');
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#schoolUserImagePreview').css('background-image', 'url(' + e.target.result + ')');
                    $('#schoolUserImagePreview').hide();
                    $('#schoolUserImagePreview').fadeIn(650);
                    //alert(e.target.result);
                    $('#schoolUserImages').val(e.target.result);
                    schoolBaseImage = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }  

        $("#schoolUserLogo").change(function () {
			//alert('sss');
            readSchoolProfileURL(this);
        });

    });
</script>
<script>
    $(document).on('click', '.updatePostInformation', function () {
        updatePostInformation();
    });

    function updatePostInformation() {
        $.ajax({
            url: "http://localhost/talking_classes_staging/schooladmin/schools/manage?flag=update_post_information&post_id=" + updatePostId + "&post_category=" + $("#select_updatepost_category option:selected").val() + "&post_content=" + updatePostContent,
            type: "GET",
            async: true,
            data: {"user_id": <?php echo $userIds; ?>},
            datatype: 'html',
            success: function (result) {
                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var responseStatus = decodedJson.response.response_status;
                var userdatas = decodedJson.response.response_data;
                if(responseStatus) {$("#editPostData").modal("hide"); getPosts();}
            }
        });
    }

    $(document).ready(function () {
        $.ajax({
            url: "http://localhost/talking_classes_staging/schooladmin/schools/manage?flag=get_school_user_profile&user_id=" +<?php echo $userIds; ?>,
            type: "post",
            async: false,
            data: {"user_id": <?php echo $userIds; ?>},
            datatype: 'html',
            success: function (result) {
                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var responseStatus = decodedJson.response.response_status;
                var userdatas = decodedJson.response.response_data;
                if (responseStatus) {
                    var firstName = $('#firstName').val(userdatas.user_firstname);
                    var lastName = $('#lastName').val(userdatas.user_lastname);
                    var userDesignation = $('#userDesignation').val(userdatas.user_designation);
                    var newPassword = $('#newPassword').val(userdatas.user_password);
                    var userMobile = $('#userMobile').val(userdatas.user_contactno);
                    $('#imagePreview1').css('background-image', 'url(' + userdatas.user_image + ')');
                    $('#profile-img').attr('src', userdatas.user_image);
                    $("#userProfileImage").attr('src',userdatas.user_image);

                }
            }
        });
        $('#editProfileClick').click(function () {


            $('#editProfile').modal('show');
        });


        $('#editProfileUpdateClick').click(function () {
            //alert('editProfileUpdateClick"');
            var firstName = $('#firstName').val();
            var lastName = $('#lastName').val();
            var userDesignation = $('#userDesignation').val();
            var newPassword = $('#newPassword').val();
            var userMobile = $('#userMobile').val();
            var userImages = $('#userImages').val();

            $.ajax({
                url: "http://localhost/talking_classes_staging/schooladmin/schools/manage?flag=update_school_user_profile",
                type: "post",
                async: false,
                data: {
                    "user_id": userSessionId,
                    "firstName": firstName,
                    "lastName": lastName,
                    "userDesignation": userDesignation,
                    "newPassword": newPassword,
                    "userMobile": userMobile,
                    "userImages": userImages
                },
                datatype: 'html',
                success: function (result) {
                    // console.log(result);
                    var decodedJson = jQuery.parseJSON(result);
                    var responseMessage = decodedJson.response.response_message;
                    var responseStatus = decodedJson.response.response_status;
                    var userdatas = decodedJson.response.response_data;
                    if (responseStatus) {

                        $('#guestUsername').text(firstName + " " + lastName);
                        swal("", "Your Information Updated Successfully", "success");
                        check(userProfileImage)
                            .on("error", function (e) {
                                //console.log(e.type, this.src)
                                $('#userProfileImage').attr('src', defaultImage);
                            })
                            .on("load", function (e) {
                                $('#userProfileImage').attr('src', userProfileImage);
                            })
                    } else {
                        swal("", "Issue with updating Information", "error");
                    }
                }
            });
        });
    });
</script>
<script>
    $(document).on('click','.btnCreateAlbum',function(){
        if($("#album_name").val() === "") {
            $(".albumnameerror").show()
            return false;
        }else {
            $(".albumnameerror").hide();
            createNewAlbum($("#album_name").val());
        }
    });
    $(document).on('keyup',"#album_name",function(){
        if($(this).val() === "") {
            $(".albumnameerror").show()
        }else {
            $(".albumnameerror").hide()
        }
    });
    $(document).on('keyup', '#updatepost_content_text', function () {
        $(".updatepost_postview_content").html($('#updatepost_content_text').val().replace(/\n/gi, '<br />'));
        updatePostContent = $('#updatepost_content_text').val().replace(/\n/gi, '<br />');
    });
    $(document).ready(function () {
        $(".edit_postcontent").keyup(function () {
            $(".postview_content").html($('.edit_postcontent').val().replace(/\n/gi, '<br />'));
            postContent = $('.edit_postcontent').val().replace(/\n/gi, '<br />');
        });
        $('.postparam').change(function () {
            if ($(this).val() === "school") {
                postFor = "school";
                $(".classparam-container").hide();
                $(".searchparam-container").hide();
                $(".teacherparam-container").hide();
                $(".parentparam-container").hide();
            } else if ($(this).val() === "class") {
                postFor = "class";
                $(".classparam-container").show();
                $(".searchparam-container").hide();
                $(".teacherparam-container").hide();
                $(".parentparam-container").hide();
            } else if ($(this).val() === "custom") {
                postFor = "custom";
                $(".classparam-container").hide();
                $(".searchparam-container").show();
                $(".teacherparam-container").hide();
                $(".parentparam-container").hide();
            } else if ($(this).val() === "teacher") {
                postFor = "teacher";
                $(".classparam-container").hide();
                $(".searchparam-container").hide();
                $(".teacherparam-container").show();
                $(".parentparam-container").hide();
            } else if ($(this).val() === "parent") {
                postFor = "parent";
                $(".classparam-container").hide();
                $(".searchparam-container").hide();
                $(".teacherparam-container").hide();
                $(".parentparam-container").show();
            }
        });
        $(".post-preview-selectclass").change(function () {
            postForClass = $(this).val();
        });
        $(".post-preview-sections").change(function () {
            postForSection = $(this).val();
        });
        $(".teacherpostparam").change(function () {
            if ($(this).val() === "allteacher") {
                postSubFor = "allteacher";
                $(".teachernameparam-container").hide();
            } else if ($(this).val() === "selectedteacher") {
                postSubFor = "selectedteached";
                $(".teachernameparam-container").show();
            }
        });
        $(".parentpostparam").change(function () {
            if ($(this).val() === "allparent") {
                postSubFor = "allparent";
                $(".parentnameparam-container").hide();
            } else if ($(this).val() === "selectedparent") {
                postSubFor = "selectparent";
                $(".parentnameparam-container").show();
            }
        });
        $('.postfiletype').change(function () {
            if ($(this).val() === "nofile") {
                postIsImage = false;
                postIsPdf = false;
                $(".postimagecontainer").hide();
                $(".uploadimagecontainer").hide();
                $(".uploadpdfcontainer").hide();
            } else if ($(this).val() === "image") {
                postIsImage = true;
                postIsPdf = false;
                $('.postthumb_image').attr('src', "images/logothumb.png");
                $(".postimagecontainer").show();
                $(".uploadimagecontainer").show();
                $(".uploadpdfcontainer").hide();
            } else if ($(this).val() === "pdf") {
                postIsImage = false;
                postIsPdf = true;
                $('.postthumb_image').attr('src', "images/pdfthumbnail.png");
                $(".postimagecontainer").show();
                $(".uploadimagecontainer").hide();
                $(".uploadpdfcontainer").show();
            }
        });

        function readPostImageURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#imagePreview1').css('background-image', 'url(' + e.target.result + ')');
                    $('#imagePreview1').hide();
                    $('#imagePreview1').fadeIn(650);
                    //alert(e.target.result);
                    $('.postthumb_image').attr('src',e.target.result);
                   // schoolBaseImage = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        $(".filepostimage").change(function () {
            //alert('chnage');
            readPostImageURL(this);
        });
        $(".filepostpdf").change(function () {
            readURL(this, false);
        });
        $(".btnAct").click(function () {
            $("div").removeClass("btnActive");
            $(this).find("div").addClass("btnActive");
        });
        $(".btnActiveNBClick").click(function () {
            $("div").removeClass("btnActiveNB");
            $(this).find("div").addClass("btnActiveNB");
        });
        $(".btnActiveVTClick").click(function () {
            $("div").removeClass("btnActiveVT");
            $(this).find("div").addClass("btnActiveVT");
        });
        $(".btnActiveMessageClick").click(function () {
            $("div").removeClass("btnActiveMessage");
            $(this).find("div").addClass("btnActiveMessage");
        });
        $(".btnActivePLClick").click(function () {
            $("div").removeClass("btnActivePL");
            $(this).find("div").addClass("btnActivePL");
        });
        $(".btnActiveRPClick").click(function () {
            $("div").removeClass("btnActiveRP");
            $(this).find("div").addClass("btnActiveRP");
        });
        $(".btnActiveGalleryClick").click(function () {
            $("div").removeClass("btnActiveGallery");
            $(this).find("div").addClass("btnActiveGallery");
            $("#addNewGallery").modal("show");
        });
        $(".post-noticeboard").click(function () {

            $.ajax({
                url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
                type: "GET",
                async: false,
                data: {
                    "flag": "new_post",
                    "posted_by": "<?php echo $_SESSION['userId']; ?>",
                    "post_category": $(".select-post-category option:selected").val(),
                    "post_content": postContent,
                    "post_for": postFor,
                    "is_image": postIsImage,
                    "is_pdf": postIsPdf,
                    "class": postForClass,
                    "section": postForSection,
                    "post_for_sub": postSubFor,
                    "post_for_value": postForValue
                },
                datatype: 'jsonp',
                success: function (result) {
                    var decodedJson = jQuery.parseJSON(result);
                    var responseMessage = decodedJson.response.response_message;
                    var data = decodedJson.response.response_data;


                    swal({
                            title: " ",
                            text: "Posted Successfully",
                            type: "success",
                            showCancelButton: false,
                            confirmButtonClass: "btn-primary",
                            confirmButtonText: "Ok",
                            closeOnConfirm: true
                        },
                        function () {
                            $(".edit_postcontent").val("");
                            getPosts();
                            //  alert("Tushar Singh");
                            //swal("Deleted!", "Your imaginary file has been deleted.", "success");
                        });
                }
            });
        });
    });
    $(document).ready(function(){
        $.ajax({
            url: "http://localhost/talking_classes_staging/mobile/app/data/get/postcategories",
            type: "GET",
            async: false,
            dataType: "html",
            success: function (result) {
                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var data = decodedJson.response.response_data;
                var parentsArray = [];
                $.each(data, function (i, currProgram) {
                    if(i===0) {
                        $(".postview_category").html(currProgram.item_name);
                    }
                    $('.select-post-category').append($('<option>', {
                        value: currProgram.item_id,
                        text: currProgram.item_name
                    }));
                    $("#select_updatepost_category").append($('<option>', {
                        value: currProgram.item_id,
                        text: currProgram.item_name
                    }));
                });
            },error: function (error) {
                console.log("Category Error : "+JSON.stringify(error));
                //alert(JSON.stringify(error));
            }
        });
    });
</script>

<script src="js/owl.carousel.js"></script>
<script src="js/jquery.fitvids.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/jquery.parallax-1.1.3.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/jquery.ajaxchimp.min.js"></script>
<script src="js/jquery.ajaxchimp.langs.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/waypoints.min.js"></script>
<script src="js/jquery.counterup.min.js"></script>
<script src="js/bootstrap-toggle.js"></script>
<script src="js/script.js"></script>
<script src="js/jquery.imageuploader.js"></script>
<script>
        (function(){
            var options = {schoolid : <?php echo $schoolId;?>,branchid : <?php echo $schoolBranchId; ?>};
            $('.js-uploader__box').uploader(options);
        }());
</script>
</body>
</html>