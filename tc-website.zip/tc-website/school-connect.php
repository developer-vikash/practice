<!DOCTYPE html>
<html lang="en">
<!--
	Bent - Bootstrap Landing Page Template by Dcrazed
	Site: https://dcrazed.com/bent-app-landing-page-template/
	Free for personal and commercial use under GNU GPL 3.0 license.
-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Talking Classes | Let's get Talking Classes...</title>
    <!-- Google Font -->
    <link href='https://fonts.googleapis.com/css?family=Raleway:500,600,700,800,900,400,300' rel='stylesheet'
          type='text/css'>

    <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,900,300italic,400italic'
          rel='stylesheet' type='text/css'>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Owl Carousel Assets -->
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">


    <!-- Pixeden Icon Font -->
    <link rel="stylesheet" href="css/Pe-icon-7-stroke.css">

    <!-- Font Awesome -->
    <link href="css/font-awesome.min.css" rel="stylesheet">


    <!-- PrettyPhoto -->
    <link href="css/prettyPhoto.css" rel="stylesheet">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>

    <!-- Style -->
    <link href="css/style.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <!-- Responsive CSS -->
    <link href="css/responsive.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<style>
	
.homeloginbox {
    height: 370px;
    width: 90%;
    margin: 0px auto;
    border-radius: 10px;
    padding: 1px;
    float: none !important;
}

.login_title {
    font-family: verdana;
    border-bottom: 1px solid #21AFC7;
    font-size: 24px;
    margin: 0 auto;
    width: 100%;
    color: #000;
    text-shadow: 0 1px 1px #000000;
    padding: 14px 0px 14px 0px;
}

.login_box {

    padding-bottom: 10px;
    width: 90%;
    border-bottom: 2px solid #21AFC7;
    margin: 2px auto 0;
    height: 1px;
    color: #000000;
    font-weight: bold;

}
	</style>
</head>

<body>
<!-- PRELOADER -->
<div class="spn_hol">
    <div class="spinner">
        <div class="bounce1"></div>
        <div class="bounce2"></div>
        <div class="bounce3"></div>
    </div>
</div>

<!-- END PRELOADER -->

<!-- =========================
    START ABOUT US SECTION
============================== -->
<section class="about parallax home-parallax page" id="HOME">
    <h2></h2>
    <div class="section_overlay">
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                            data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">
                        <img src="images/logo-transparent.png" alt="Logo">
                    </a>
                </div>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <!-- NAV -->
                        <li><a href="#HOME">HOME</a></li>
                        <li><a href="school-connect.php">SCHOOL ZONE </a></li>
                        <li><a href="#ABOUT">ABOUT </a></li>
                        <li><a href="#FEATURES">FEATURES</a></li>
                        <li><a href="#SCREENS">SCREENS</a></li>
                        <li><a href="#DOWNLOAD">DOWNLOAD </a></li>
                        <li><a href="#CONTACT">CONTACT </a></li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
            <!-- /.container- -->
        </nav>

        <div class="container home-container" style="margin-top: 50px;">
            <div class="row">
                <div class="col-md-3">
				</div>
                <div class="col-md-6" style=" border: 1px solid #21AFC7;">
                    <div class="logo text-center">
                        <!-- LOGO -->
                        <img width="180" src="images/logo-transparent.png" alt="">
						<div class="login_box"></div>
						<div id="Loginpanel">

							<div class="homeloginbox">
								<div class="login_title" align="left">Login</div>
					
								<form role="form" action="contact.php" style="margin-top:10px;">
									<div class="row">
										<div class="col-md-8">
											<input class="form-control form-group" id="userName"  name ="userName" placeholder="User Email" type="text">
											<input class="form-control form-group" id="userPassword" name="userPassword" placeholder="User Password" type="password">
										</div>


										<div class="col-md-4  center-block">
											
											<button type="button" style="height:81px;" class="btn btn-default submit-btn form_submit">Login</button>
											
										</div>
									</div>
								</form>
							
							</div>
						</div>
                    </div>
					
                </div>
				<div class="col-md-3">
				</div>
            </div>
           
    
        </div>
    </div>
</section>

<!-- END HEADER SECTION -->



<!-- =========================
     START CONTCT FORM AREA
============================== -->


<!-- =========================
     Start Subscription Form 
============================== -->


<section class="subscribe parallax subscribe-parallax" data-stellar-background-ratio="0.6"
         data-stellar-vertical-offset="20" id="SCHOOL_ZONE">
    <div class="section_overlay wow lightSpeedIn">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">

                    <!-- Start Subscribe Section Title -->
                    <div class="section_title">
                        <h2>ARE YOU A School ? LET US KNOW YOUR THOUGHTS</h2>
                        <p>Want to hear more from us. Enter your email address below and never miss and news and updated
                            from Talking Classes</p>
                    </div>
                    <!-- End Subscribe Section Title -->
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row  wow lightSpeedIn">
                <div class="col-md-6 col-md-offset-3">
                    <!-- SUBSCRIPTION SUCCESSFUL OR ERROR MESSAGES -->
                    <div class="subscription-success"></div>
                    <div class="subscription-error"></div>
                    <!-- Check this topic on how to add email subscription list, http://kb.mailchimp.com/lists/signup-forms/host-your-own-signup-forms -->
                    <form id="mc-form" action="#" method="POST" class="subscribe_form">
                        <input type="hidden" name="u" value="6908378c60c82103f3d7e8f1c">
                        <input type="hidden" name="id" value="8c5074025d">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="email" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="Your Name"
                                           value="">
                                </div>
                                <div class="col-md-6">
                                    <input type="email" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="Designation"
                                           value="">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="email" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="School Name"
                                           value="">
                                </div>
                                <div class="col-md-6">
                                    <select autocapitalize="off" autocorrect="off" name="MERGE0"
                                            class="required form-control" id="mce-EMAIL">
                                        <option value="0">Select Country</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="email" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="City Name"
                                           value="">
                                </div>
                                <div class="col-md-6">
                                    <input type="email" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="Branch Name"
                                           value="">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="email" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="School Email"
                                           value="">
                                </div>
                                <div class="col-md-6">
                                    <input type="email" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="School Phone"
                                           value="">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <input type="email" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL"
                                           placeholder="School Website" value="">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <input type="email" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="Your Message"
                                           value="">
                                </div>
                            </div>
                        </div>
                        <!-- SUBSCRIBE BUTTON -->
                        <button type="submit" class="btn btn-default subs-btn">Submit</button>
                    </form>


                </div>
            </div>
        </div>
    </div>
</section>

<!-- END SUBSCRIPBE FORM -->


<!-- =========================
     FOOTER 
============================== -->

<section class="copyright">
    <h2></h2>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="copy_right_text">
                    <!-- COPYRIGHT TEXT -->
                    <p>Copyright &copy; 2018. All Rights Reserved.</p>
                    <p><a href="#">Talking Classes</a></p>
                </div>

            </div>

            <div class="col-md-6">
                <div class="scroll_top">
                    <a href="#HOME"><i class="fa fa-angle-up"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- END FOOTER -->


<!-- =========================
     SCRIPTS 
============================== -->


<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/jquery.fitvids.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/jquery.parallax-1.1.3.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/jquery.ajaxchimp.min.js"></script>
<script src="js/jquery.ajaxchimp.langs.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/waypoints.min.js"></script>
<script src="js/jquery.counterup.min.js"></script>
<script src="js/script.js"></script>


</body>
</html>