
    $(document).ready(function () {
        $(".teacherListSearch").on("keyup", function () {
            //alert('Teacher');
            var value = $(this).val().toLowerCase();
            $(".teacherTable tr").filter(function () {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });

        var school_id = schoolSessionId;
		var branch_id = schoolSessionBranchId;
       // alert(school_id);
		var teacherIdNumList = [];
		 $.ajax({
            url: "http://52.90.39.26/talking_classes/schooladmin/schools/manage",
            type: "GET",
            async: false,
            data: {"flag": "get_teacher_unique_id_no", "school_id": school_id, "branch_id":branch_id},
            datatype: 'html',
            success: function (result) {
                alert(result);
                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var responseStatus = decodedJson.response.response_status;
                var teacherIdNumbRespData = decodedJson.response.response_data;
				if(responseStatus){
					$.each(teacherIdNumbRespData, function (i, currProgram) {
						if(currProgram.teacher_id_no != null){
							teacherIdNumList.push(currProgram.teacher_id_no);
						}else{
							alert('vikash kashyap');
						}
						
					});
				}
			}
		 }); 
		alert(teacherIdNumList);
        $.ajax({
            url: "http://52.90.39.26/talking_classes/schooladmin/schools/manage",
            type: "GET",
            async: false,
            data: {"flag": "school_teachers", "school_id": school_id, "branch_id":branch_id},
            datatype: 'html',
            success: function (result) {
                console.log("Get Teacher Query");
                console.log(result);
                var decodedJson = jQuery.parseJSON(result);
                var responseMessage = decodedJson.response.response_message;
                var responseStatus = decodedJson.response.response_status;
                var data = decodedJson.response.response_data;
                if(responseStatus){
                //console.log(data);
                var allTeacherRow = "";

                var countAll = 1;
                var countUnverified = 1;
                var countVerfied = 1;
                var unverifiedData;
                var allData;
                var verifiedData;
                $.each(data, function (i, currProgram) {
                    if (currProgram.is_verified == 0) {

                        var allTeacherRow = "<tr id='" + currProgram.teacher_id + "' class=''><td><img src='"+ currProgram.user_image +"' alt='' class='img-circle img-responsive' style='width:35px;height:35px;'></td><td>" + currProgram.user_firstname + ' ' + currProgram.user_lastname + "</td><td>" + currProgram.user_email + "</td><td>" + currProgram.user_contactno + "</td><td><input data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td><a class='grey editTeacher'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> || <a class='grey deleteTeacher' href='#'><i class='fa fa-trash'></i></a></td></tr>";

                        unverifiedData = unverifiedData + allTeacherRow;

                        countUnverified = countUnverified + 1;

                        var allTeacherRowData = "<tr id='" + currProgram.teacher_id + "' class=''><td><img src='"+ currProgram.user_image +"' alt='' class='img-circle img-responsive' style='width:35px;height:35px;' ></td><td>" + currProgram.user_firstname + ' ' + currProgram.user_lastname + "</td><td>" + currProgram.user_email + "</td><td>" + currProgram.user_contactno + "</td><td><input data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td><a class='grey editTeacher'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> || <a class='grey deleteTeacher' href='#'><i class='fa fa-trash'></i></a></td></tr>";
                        allData = allData + allTeacherRowData;
                        countAll = countAll + 1;
                    } else {

                        var allTeacherRow = "<tr id='" + currProgram.teacher_id + "' class=''><td><img src='"+ currProgram.user_image +"' alt='' class='img-circle img-responsive' style='width:35px;height:35px;'></td><td>" + currProgram.user_firstname + ' ' + currProgram.user_lastname + "</td><td>" + currProgram.user_email + "</td><td>" + currProgram.user_contactno + "</td><td><input checked data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td><a class='grey editTeacher'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> || <a class='grey deleteTeacher' href='#'><i class='fa fa-trash'></i></a></td></tr>";
                        verifiedData = verifiedData + allTeacherRow;
                        countVerfied = countVerfied + 1;

                        var allTeacherRowData = "<tr id='" + currProgram.teacher_id + "' class=''><td><img src='"+ currProgram.user_image +"' alt='' class='img-circle img-responsive' style='width:35px;height:35px;'></td><td>" + currProgram.user_firstname + ' ' + currProgram.user_lastname + "</td><td>" + currProgram.user_email + "</td><td>" + currProgram.user_contactno + "</td><td><input checked data-toggle='toggle' data-on='Verified' data-off='Unverified' data-onstyle='success' data-offstyle='danger' type='checkbox' class='toggleStatus'></td><td> <a class='grey editTeacher'  href='#' ><i class='fa fa-pencil-square-o' aria-hidden='true'></i></a> || <a class='grey deleteTeacher' href='#'><i class='fa fa-trash'></i></a></td></tr>";
                        allData = allData + allTeacherRowData;

                        countAll = countAll + 1;
                    }

                });

                $("#allTeacherRow").append(allData);
                $("#allTeacherRowVerified").append(verifiedData);
                $("#allTeacherRowUnverified").append(unverifiedData);
                }                

            }
        });

        $('.removeTeacherFromSchool').click(function () {
            var teacherId = $('#teacheIds').val();
          
            swal({
              title: "Are you sure?", 
              text: "You want to delete this Teacher?", 
              type: "warning",
              showCancelButton: true,
              closeOnConfirm: false,
              confirmButtonText: "Yes, delete it!",
              confirmButtonColor: ""
            }, function() {
                $.ajax({
                url: "http://52.90.39.26/talking_classes/schooladmin/schools/manage",
                type: "GET",
                async: false,
                data: {"flag": "inactive_teacher_status", "teacher_id": teacherId},
                datatype: 'html',
                success: function (result) {
                    //alert('succ');
                    swal("", "Record Deleted Successfully", "success");

                    $('.' + teacherId).hide(1000);
                    $('#editTeacherData').modal('hide');
                }
              });             
            });
        });

        $('.deleteTeacher').click(function () {
            var teacherId = $(this).closest('tr').attr('class');

            swal({
              title: "Are you sure?", 
              text: "You want to delete this teacher?", 
              type: "warning",
              showCancelButton: true,
              closeOnConfirm: false,
              confirmButtonText: "Yes, delete it!",
              confirmButtonColor: ""
            }, function() {
                $.ajax({
                url: "http://52.90.39.26/talking_classes/schooladmin/schools/manage",
                type: "GET",
                async: false,
                data: {"flag": "inactive_teacher_status", "teacher_id": teacherId},
                datatype: 'html',
                success: function (result) {
                    //alert('succ');
                    swal("", "Record Deleted Successfully", "success");

                    $('.' + teacherId).hide(1000);

                }
              });             
            });
        });

        
      
        $('.updateClassSectionInfo').click(function () {
            var teacherId = $('#teacheIds').val();
            var teacherIdNumb = $('#teacherIdNumb').val();
            //alert(teacherId);
            var classes = [];
            var sections = [];
            var subjects = [];
            var recordId = [];
            
             //form classes data end
            $("input[name='teacherClassName[]']").map(function(){
               //alert($(this).val());
               classes.push($(this).val()); 
             }).get();
            console.log(classes);
            //form classes data end
            

            //form sections data end
            $("input[name='teacherSectionName[]']").map(function(){
               //alert($(this).val());
               sections.push($(this).val()); 
             }).get();
            console.log(sections);
            //form classes data end

            //form subjects data end
            $("input[name='teacherSubjectName[]']").map(function(){
               //alert($(this).val());
               subjects.push($(this).val()); 
             }).get();
            console.log(subjects);
            //form classes data end

            //form subjects data end
            $("input[name='recordId[]']").map(function(){
               //alert($(this).val());
               recordId.push($(this).val()); 
             }).get();
            console.log(recordId);
            //form classes data end
                      
            swal({
              title: "Are you sure?", 
              text: "You want to modify this teacher information?", 
              type: "warning",
              showCancelButton: true,
              closeOnConfirm: false,
              confirmButtonText: "Yes, Modify!",
              confirmButtonColor: ""
            }, function() {
                  //alert('vikash');
                $.ajax({
                url: "http://52.90.39.26/talking_classes/mobile/teacher/manage",
                type: "GET",
                async: false,
                data: {"flag": "update_class_section", "teacher_id": teacherId,"teacherIdNumb":teacherIdNumb,"teacher_class":classes,"teacher_section":sections,"teacher_subject":subjects,"recordId":recordId},
                datatype: 'html',
                success: function (result) {
                    //alert('succ');
                    var decodedJson = jQuery.parseJSON(result);
                    var responseMessage = decodedJson.response.response_message;
                    console.log(result);
                    if(responseMessage){
                      swal("", "Record Updated Successfully", "success");
                    }else{
                      swal("", "Issue with updating Information", "error");
                    }
                    
                    //$('#editTeacherData').modal('hide');
                }
              });        
            });
        });

        $('.editTeacher').click(function () {
            var teacherId = $(this).closest('tr').attr('id');
            //alert(teacherId);
            var currentRow = $(this).closest("tr");
            var name = currentRow.find("td:eq(1)").text();
            var email = currentRow.find("td:eq(2)").text();
            var status = currentRow.find("td:eq(4)").text();
            //var is_verified_unverified = jQuery.trim(status).substring(0, 4); 
			//alert(is_verified_unverified);
            $('#madalUserName').html(name);
            $('#modalUserEmail').html(email);

           
            $('#teacheIds').val(teacherId);

            var school_id = schoolSessionId;
			var branch_id = schoolSessionBranchId;
           // alert(" school_id : "+school_id);
            $('#editClassSectionData').html("");
            $.ajax({
                url: "http://52.90.39.26/talking_classes/schooladmin/schools/manage",
                type: "GET",
                async: false,
                data: {"flag": "get_specific_teacher_class_section","branch_id": branch_id,"school_id": school_id, "teacher_id": teacherId},
                datatype: 'html',
                success: function (result) {
                  console.log(result);
                    var decodedJson = jQuery.parseJSON(result);
                    var responseMessage = decodedJson.response.response_message;
                    var data = decodedJson.response.response_data;
                    var html = "";
                    var completeHtml = "";
                    var counter = 0;
					$('#teacherIdNumb').val('');
                    $.each(data, function (i, currProgram) {
						
						$('#teacherIdNumb').val(currProgram.teacher_id_no);
						if(currProgram.is_email_verified=='0'){
							$('#modalUserStatu').html("<span style='color:red;'>Unverified</span>");
						}
						
						if(currProgram.is_email_verified=='1'){
							$('#modalUserStatu').html("<span style='color:green;'>Verified</span>");
						}
						//alert(currProgram.is_email_verified);

                        $('#teacherProfileImage').attr('src',currProgram.user_image);
						
                        var html = '<div class="row"><div class="col-md-3"><div class="form-group"><input type="hidden" name="recordId[]" value="'+currProgram.id+'"><input type="text" class="form-control custom-input-box classInput" id="classInput' + counter + '" name="teacherClassName[]" value="' + currProgram.teacher_class + '"></div></div><div class="col-md-3"><div class="form-group"><input type="text" class="form-control custom-input-box sectionInput" id="sectionInput' + counter + '" name="teacherSectionName[]" value="' + currProgram.teacher_section + '"></div></div><div class="col-md-3"><div class="form-group"><input type="text"  class="form-control custom-input-box subjectInput" id="subjectInput' + counter + '" name="teacherSubjectName[]" value="' + currProgram.teacher_subject + '"></div></div></div>';
                        completeHtml = completeHtml + html;
                      //  alert(currProgram.teacher_class);
                        if(counter==0){
                          $('#modalUserSignedOn').html(currProgram.created_on);
                        }
                        counter++;
                    });
                    $('#editClassSectionData').html(completeHtml);
                    $('#editTeacherData').modal('show');                 
                }
            });
            $(".classInput").autocomplete({
                source: classJson
            });
            $(".sectionInput").autocomplete({
                source: sectionJson
            });
            $(".subjectInput").autocomplete({
                source: subjectJson
            });
			$("#teacherIdNumb").autocomplete({
                source: teacherIdNumList
            });
			
        });
    });