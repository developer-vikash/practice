<?php session_start();  ?>
<?php
if(isset($_SESSION['userId']) && !empty($_SESSION['userId'])){
        header('Location:school-account.php');
        exit;
}
?>
<!DOCTYPE html>
<html lang="en">
    <!--
    Bent - Bootstrap Landing Page Template by Dcrazed
    Site: https://dcrazed.com/bent-app-landing-page-template/
    Free for personal and commercial use under GNU GPL 3.0 license.
    -->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Talking Classes | School Zone.</title>
        <!-- Google Font -->
        <link href='https://fonts.googleapis.com/css?family=Raleway:500,600,700,800,900,400,300' rel='stylesheet'
            type='text/css'>
            <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,900,300italic,400italic'
                rel='stylesheet' type='text/css'>
                <!-- Bootstrap -->
                <link href="css/bootstrap.min.css" rel="stylesheet">
                <!-- Owl Carousel Assets -->
                <link href="css/owl.carousel.css" rel="stylesheet">
                <link href="css/owl.theme.css" rel="stylesheet">
                <!-- Pixeden Icon Font -->
                <link rel="stylesheet" href="css/Pe-icon-7-stroke.css">
                <!-- Font Awesome -->
                <link href="css/font-awesome.min.css" rel="stylesheet">
                <!-- PrettyPhoto -->
                <link href="css/prettyPhoto.css" rel="stylesheet">
                <!-- Favicon -->
                <link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
                <!-- Style -->
                <link href="css/style.css" rel="stylesheet">
                <link href="css/animate.css" rel="stylesheet">
                <!-- Responsive CSS -->
                <link href="css/responsive.css" rel="stylesheet">
                
				<link href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.css' rel='stylesheet'
            type='text/css'>
                <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
                <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
                <!--[if lt IE 9]>
                <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
                <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
                <![endif]-->
                <style type="text/css">
                .full-width {
                width: 100%;
                }
                .custom-button {
                background-color: #f39c12;
                }
                .custom-button:hover {
                background-color: #db8c0e;
                }
                .custom-button1 {
                background-color: #3b4e5f !important;
                border-color: #3b4e5f !important;
                }
                .custom-button1:hover {
					background-color: #2b4e2f;
					border-color: #2b4e2f;
                }
				.custom-button2 {
                background-color: #4C99CC;
                border-color: #4C99CC;
                }
                .custom-button2:hover {
                background-color: #3C89BC;
                }
                </style>
				
				<style>
				.demo{ background: #f2f2f2;padding:30px; }
.pricingTable{
    padding-bottom: 30px;
    margin: 0 15px;
    background: #fff;
    text-align: center;
    border-radius: 15px;
    overflow: hidden;
}
.pricingTable:hover{ box-shadow: 0 0 10px rgba(195, 67, 67, 0.3) inset,0 0 20px -5px rgba(0,0,0,0.8); }
.pricingTable .pricingTable-header{
    padding: 5px 15px 30px;
    background: #66ce04;
    -webkit-clip-path: polygon(50% 100%, 100% 60%, 100% 0, 0 0, 0 60%);
    clip-path: polygon(50% 100%, 100% 60%, 100% 0, 0 0, 0 60%);
    position: relative;
}
.pricingTable .pricingTable-header:before{
    content: "";
    width: 400px;
    height: 400px;
    border-radius: 50%;
    position: absolute;
    right: -50%;
    top: -130%;
    background: repeating-radial-gradient(rgba(255,255,255,0.05), rgba(255,255,255,0.2) 20%);
    transition: all 0.5s ease 0s;
}
.pricingTable:hover .pricingTable-header:before{ right: 50%; }
.pricingTable .title{
    font-size: 37px;
    color: #fff;
    margin: 0;
}
.pricingTable .price-value{
    display: block;
    font-size: 23px;
    color: #000;
   /* margin: 0 0 20px 0; */
    transition: all 0.3s ease 0s;
}
.pricingTable .pricing-content{
    padding: 13px 25px 0;
    margin: 0;
    list-style: none;
}
.pricingTable .pricing-content li{
    font-size: 18px;
    color: #909090;
    line-height: 40px;
    letter-spacing: 1px;
    text-transform: capitalize;
    border-bottom: 2px solid rgba(0,0,0,0.15);
    margin-bottom: 10px;
    position: relative;
}
.pricingTable .pricing-content li:last-child{ border-bottom: none; }
.pricingTable .pricing-content li i{ color: #66ce04; }
.pricingTable .pricingTable-signup{
    display: block;
    padding: 10px 0;
    margin: 0 25px;
    border-radius: 10px;
    background: #66ce04;
    font-size: 20px;
    color: #fff;
    letter-spacing: 1px;
    text-transform: uppercase;
    overflow: hidden;
    position: relative;
    transition: all 0.3s ease 0s;
}
.pricingTable .pricingTable-signup:hover{
    letter-spacing: 2px;
    box-shadow: 0 0 10px rgba(0,0,0,0.7) , 0 0 0 7px rgba(255,255,255,0.5) inset;
}
.pricingTable .pricingTable-signup:before{
    content: "";
    width: 230px;
    height: 230px;
    border-radius: 50%;
    background: repeating-radial-gradient(rgba(255,255,255,0.05), rgba(255,255,255,0.2) 20%);
    position: absolute;
    top: -180%;
    right: -40%;
    transition: all 0.8s ease 0s;
}
.pricingTable .pricingTable-signup:hover:before{ right: 40%; }
.pricingTable.blue .pricingTable-header,
.pricingTable.blue .pricingTable-signup{ background: #15b8f3; }
.pricingTable.blue .pricing-content li i{ color: #15b8f3; }
.pricingTable.pink .pricingTable-header,
.pricingTable.pink .pricingTable-signup{ background: #f03c79; }
.pricingTable.pink .pricing-content li i{ color: #f03c79; }
@media only screen and (max-width: 990px){
    .pricingTable{ margin-bottom: 30px; }
}
@media only screen and (max-width: 479px){
    .pricingTable{ margin: 0; }
    .pricingTable .pricing-content li{ font-size: 15px; }
}
				</style>
				
				<style>
				.custom-input-box{
					background-color:#e5e8e8;
					border:1px solid #ccd1d1;
					border-radius:3px;
					padding:20px;
				}
				</style>
				<style>
					.login_title {
						font-family: verdana;
						border-bottom: 1px solid #21AFC7;
						font-size: 24px;
						margin: -5px 0px 5px 0px;
						width: 25%;
						color: #21AFC7;
						text-shadow: 0 1px 1px #000000;
						padding: 0px 0px 6px 0px;
					}
				</style>
            </head>
            <body>
                <!-- PRELOADER -->
                <div class="spn_hol">
                    <div class="spinner">
                        <div class="bounce1"></div>
                        <div class="bounce2"></div>
                        <div class="bounce3"></div>
                    </div>
                </div>
                <!-- END PRELOADER -->
                <!-- =========================
                START ABOUT US SECTION
                ============================== -->
                <section class="header parallax home-parallax page" id="HOME" style="background:none;">
                    <h2></h2>
                    <div class="section_overlay">
                        <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
                            <div class="container">
                                <!-- Brand and toggle get grouped for better mobile display -->
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                    data-target="#bs-example-navbar-collapse-1">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    </button>
                                    <a class="navbar-brand" href="#">
                                        <img src="images/logo-transparent.png" alt="Logo">
                                    </a>
                                </div>
                                <!-- Collect the nav links, forms, and other content for toggling -->
                                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                  <!--  <ul class="nav navbar-nav navbar-right">
                                  
                                        <li><a href="#HOME">HOME</a></li>
                                        <li><a href="#SCHOOL_ZONE">SCHOOL ZONE </a></li>
                                        <li><a href="#ABOUT">ABOUT </a></li>
                                        <li><a href="#FEATURES">FEATURES</a></li>
                                        <li><a href="#SCREENS">SCREENS</a></li>
                                        <li><a href="#DOWNLOAD">DOWNLOAD </a></li>
                                        <li><a href="#CONTACT">CONTACT </a></li>
                                    </ul>-->
                                </div>
                                <!-- /.navbar-collapse -->
                            </div>
                            <!-- /.container- -->
                        </nav>
                        <div class="container home-container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="logo text-center" style="padding-top: 40px;padding-bottom: 10px;margin-top:50px;">
                                        <!-- LOGO -->
                                        <img width="180" src="images/logo-transparent.png" alt="">
                                        <center><hr width="80%" style="border:1px solid  #4C99CC ;" /></center>
                                    </div>
                                </div>
                            </div>
							
                            <div class="row">
                                <div class="col-md-4 col-md-offset-4 col-sm-4">
								
                                    <div class="home_text">
									<div class="login_title" align="left">Login</div>
                                        <!-- TITLE AND DESC -->
										<form id="loginForm">
                                        <div>
                                            <div>
                                                <input type="text" id="userEmail" name="userEmail" class="form-control custom-input-box" placeholder="Email Id" />
                                            </div>
                                            <div style="margin-top:10px;">
                                                <input type="password" id="userPassword" name="userPassword" class="form-control custom-input-box" placeholder="Password" />
                                            </div>
                                        </div>
                                        <div style="padding-top: 10px;"><center><h5>Forgot password ? <a href="#">Click here to reset</a></h5></center></div>
                                        <div style="padding-top: 10px;">
                                            <div style="display: inline-block;vertical-align: middle;width: 100%;" >
                                                <input type="button" class="btn home-btn custom-button full-width" id="submiLogin" value="Login" />
                                            </div>
                                        </div>
										</form>
                                    </div>
                                </div>
                            </div>
							<center><hr width="30%" style="border:1px solid  #4C99CC;" /></center>
                            <div class="row">
                                <div class="col-md-4 col-md-offset-4 col-sm-4">
                                    <div><h4 style="font-size:15px;"><div style="font-size: 1em;display: inline-block;vertical-align: middle;line-height: 20px;">Not a member? then please&nbsp;&nbsp;</div><div style="display: inline-block;vertical-align: middle;line-height: 20px;"><a href="register-school.php" target="_blank" class="btn home-btn custom-button1">Register</a></div></h4></div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 col-md-offset-4 col-sm-4">
                                    <div><!--<input type="button" data-toggle="modal" data-target="#myModal" class="btn home-btn custom-button2 full-width" value="View Plans & Pricing" />-->
									<!---<input type="button" class="btn home-btn custom-button2 full-width" value="View Plans & Pricing" />--></div>
                                    <div><h4><div style="font-size: 2em;color:red;display: inline-block;vertical-align: middle;line-height: 20px;padding-top:20px;">*</div><div  style="display: inline-block;vertical-align: middle;line-height: 20px;">&nbsp;&nbsp;30 days free trial.</div></h4></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- END HEADER SECTION -->
            </div>
        </div>
    </div>
</div>
</section>


<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Membership Plans</h4>
        </div>
        <div class="modal-body">
          <p></p>
		  
		  <div class="demo">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6">
                <div class="pricingTable">
                    <div class="pricingTable-header">
                        <h3 class="title">For 1 Year</h3>
                        <div class="price-value">Rs. 18000 /-</div>
                    </div>
                    <ul class="pricing-content">
                        <li><i class="fa fa-check"></i> 50GB Disk Space</li>
                        <li><i class="fa fa-times"></i> 50 Email Accounts</li>
                    </ul>
                    <a href="#" class="pricingTable-signup">Subscribe Now</a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="pricingTable blue">
                    <div class="pricingTable-header">
                        <h3 class="title">For 2 Year</h3>
                        <div class="price-value">Rs. 34000 /-</div>
                    </div>
                    <ul class="pricing-content">
                        <li><i class="fa fa-check"></i> 60GB Disk Space</li>
                        <li><i class="fa fa-check"></i> 60 Email Accounts</li>
                    </ul>
                    <a href="#" class="pricingTable-signup">Subscribe Now</a>
                </div>
            </div>
        </div>
		<br/>
		<div class="row">
            
            <div class="col-md-4 col-sm-6">
                <div class="pricingTable blue">
                    <div class="pricingTable-header">
						<h3 class="title">For 3 Year</h3>
                        <div class="price-value">Rs. 48600 /-</div>
                    </div>
                    <ul class="pricing-content">
                        <li><i class="fa fa-check"></i> 60GB Disk Space</li>
                        <li><i class="fa fa-check"></i> 60 Email Accounts</li>
                    </ul>
                    <a href="#" class="pricingTable-signup">Subscribe Now</a>
                </div>
            </div>
			<div class="col-md-4 col-sm-6">
                <div class="pricingTable">
                    <div class="pricingTable-header">
                        <h3 class="title">For 5 Year</h3>
                        <div class="price-value">Rs. 80000 /- </div>
                    </div>
                    <ul class="pricing-content">
                        <li><i class="fa fa-check"></i> 50GB Disk Space</li>
                        <li><i class="fa fa-times"></i> 50 Email Accounts</li>
                    </ul>
                    <a href="#" class="pricingTable-signup">Subscribe Now</a>
                </div>
            </div>
        </div>
		
    </div>
</div>
		  
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  

<!-- =========================
     START CONTCT FORM AREA
============================== -->

<section class="subscribe parallax subscribe-parallax" data-stellar-background-ratio="0.6"
         data-stellar-vertical-offset="20" id="SCHOOL_ZONE">
    <div class="section_overlay wow lightSpeedIn">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">

                    <!-- Start Subscribe Section Title -->
                    <div class="section_title">
                        <h2>Contact Form For Schools</h2>
                    </div>
                    <!-- End Subscribe Section Title -->
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row  wow lightSpeedIn">
                <div class="col-md-6 col-md-offset-3">
                    <!-- SUBSCRIPTION SUCCESSFUL OR ERROR MESSAGES -->
                    <div class="subscription-success"></div>
                    <div class="subscription-error"></div>
                    <!-- Check this topic on how to add email subscription list, http://kb.mailchimp.com/lists/signup-forms/host-your-own-signup-forms -->
                    <form id="mc-form" action="#" method="POST" class="subscribe_form">
                        <input type="hidden" name="u" value="6908378c60c82103f3d7e8f1c">
                        <input type="hidden" name="id" value="8c5074025d">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="text" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="Your Name"
                                           value="" required>
                                </div>
                                <div class="col-md-6">
                                    <input type="text" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="Designation"
                                           value="" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="text" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="School Name"
                                           value="" required>
                                </div>
                                <div class="col-md-6">
                                    <select autocapitalize="off" autocorrect="off" name="MERGE0"
                                            class="required form-control" id="mce-EMAIL">
                                        <option value="0">Select Country</option>
                                        <option value="India">India</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="text" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="City Name"
                                           value="" required>
                                </div>
                                <div class="col-md-6">
                                    <input type="text" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="Branch Name"
                                           value="" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="email" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="School Email"
                                           value="" required>
                                </div>
                                <div class="col-md-6">
                                    <input type="text" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="School Contact No."
                                           value="" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <input type="text" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL"
                                           placeholder="School Website" value="" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <input type="text" autocapitalize="off" autocorrect="off" name="MERGE0"
                                           class="required email form-control" id="mce-EMAIL" placeholder="Your Message"
                                           value="" required>
                                </div>
                            </div>
                        </div>
                        <!-- SUBSCRIBE BUTTON -->
                        <button type="submit" class="btn btn-default subs-btn">Submit</button>
                    </form>


                </div>
            </div>
        </div>
    </div>
</section>
<!-- END CONTACT -->
<!-- END CONTACT -->
<!-- =========================
FOOTER
============================== -->
<section class="copyright">
<h2></h2>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="copy_right_text">
                <!-- COPYRIGHT TEXT -->
                <p>Copyright &copy; 2018. All Rights Reserved.</p>
                <p><a href="#">Talking Classes</a></p>
            </div>
        </div>
        <div class="col-md-6">
            <div class="scroll_top">
                <a href="#HOME"><i class="fa fa-angle-up"></i></a>
            </div>
        </div>
    </div>
</div>
</section>
<!-- END FOOTER -->
<!-- =========================
SCRIPTS
============================== -->
<script src="js/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.js"></script>
<script>
$(document).ready(function(){
	$("#submiLogin").click(function(){
		
		var userEmail = $('#userEmail').val();
		var userPassword = $('#userPassword').val();
		
		$.ajax({
			url: "http://localhost/talking_classes_staging/schooladmin/schools/manage",
			type: "GET",
			async: false,
			data: {"flag":"school_login","userEmail":userEmail,"userPassword":userPassword},
			datatype : 'html',
			success: function(result){
				var decodedJson = jQuery.parseJSON(result);
						
				console.log(result);
				var decodedJson = jQuery.parseJSON(result);
				var responseMessage = decodedJson.response.response_message;
				if(decodedJson.response.response_status){
					
					var lastName = "";
					if(decodedJson.response.response_data.last_name!=null){
						 lastName = decodedJson.response.response_data.last_name;
					}
					var user_id = decodedJson.response.response_data.user_id;
					var email_id = decodedJson.response.response_data.email_id;
					var user_role = decodedJson.response.response_data.user_role;
                    var name = decodedJson.response.response_data.first_name+" "+lastName;
                    var school_id = decodedJson.response.response_data.school_id;
                    var school_branch = decodedJson.response.response_data.school_branch;
                    var contact_no = decodedJson.response.response_data.contact_no;
                    var gender = decodedJson.response.response_data.gender;
                    var age = decodedJson.response.response_data.age;
                    var is_main_admin = decodedJson.response.response_data.is_main_admin;
                    var city_id = decodedJson.response.response_data.city_id;
                    var city_name = decodedJson.response.response_data.city_name;
                    var city_state = decodedJson.response.response_data.city_state;
                    var state_name = decodedJson.response.response_data.state_name;
                    //alert(name);
					$.ajax({
						url: "set-login-session.php",
						type: "POST",
						async: false,
						data: {"user_id":user_id,"email_id":email_id,"user_role":user_role,"user_name":name,"school_id":school_id,"school_branch":school_branch,"is_main_admin":is_main_admin,"city_id":city_id,"city_name":city_name,"city_state":city_state,"state_name":state_name},
						datatype : 'html',
						success: function(result){
							//alert(result);
                            //swal("",result, "error");
                            //$("#userEmail").val(result);    
							if($.trim(result)==="success"){
								// Redirect to home page
                            //    swal("",response_statuslt+" Fund Here", "error");
                            window.location.href = "http://localhost/tc-website/school-account.php";
                           // location.href = "http://www.talkingclasses.com/school-account.php";
								//window.open(
								  //'http://www.talkingclasses.com/school-account.php'
                                //  'http:///school-account.php',
								 // '_blank' // <- This is what makes it open in a new window.
                                //);
							}else{
								swal("", "Some thing wrong", "error");
							}
						}
					});
				}else{
					swal("", responseMessage, "error");
				}
		}});
	});
});
</script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/jquery.fitvids.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/jquery.parallax-1.1.3.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/jquery.ajaxchimp.min.js"></script>
<script src="js/jquery.ajaxchimp.langs.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/waypoints.min.js"></script>
<script src="js/jquery.counterup.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>