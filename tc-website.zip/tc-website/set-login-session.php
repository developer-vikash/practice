<?php 
session_start();
if(isset($_POST['user_id'])){
	$_SESSION['userId']=$_POST['user_id'];
	$_SESSION['emailId']=$_POST['email_id'];
	$_SESSION['userRole']=$_POST['user_role'];
	$_SESSION['userName']=$_POST['user_name'];
	$_SESSION['schoolId']=$_POST['school_id'];
	$_SESSION['schoolBranch']=$_POST['school_branch'];
	$_SESSION['isMainAdmin']=$_POST['is_main_admin'];
	$_SESSION['cityId']=$_POST['city_id'];
	$_SESSION['cityName']=$_POST['city_name'];
	$_SESSION['cityState']=$_POST['city_state'];
	$_SESSION['stateName']=$_POST['state_name'];
	echo "success";
}
 ?>  